# Frontend Admin Boilerplate

This repository uses:

-   Vue 3
-   TypeScript
-   Vite
-   Pinia

<br/>

## Registering Global Components

All global components are registered in `./src/global-components.ts`

1. import componentName from '@/path/componentName.vue'
2. register `app.component('ComponentName', componentName)`

<br/>

## How to Use Icons

Icons are already setup for auto import in `vite.config.ts`, no need to manually import them.

Icons sets available readily available in this boilerplate are:

-   Element Plus
    -   https://element-plus.org/en-US/component/icon.html
    -   prefix: `ep`
-   Weather Icons
    -   https://erikflowers.github.io/weather-icons/
    -   prefix: `wi`
-   Tabler Icons:
    -   https://tabler.io/icons
    -   prefix: `tabler`

_To add more icon sets_

1. https://github.com/iconify/icon-sets/blob/HEAD/collections.md
2. Run `npm i -D @iconify-json/[icon set prefix]`
3. Add icon prefix in `vite.config.ts`
    ```
        ...
        IconsResolver({
            prefix: false,
            enabledCollections: ['ep', 'tabler', '<new icon prefix>']
        })
    ```

To use an icon `{collection-prefix}-{icon}`

Example:

```
    <el-icon>
        <tabler-menu2/>
        <tabler-menu2/>
    </el-icon>
```

<br/>

# Environment Setup

### I. Setup Local Environment

-   IMPORTANT: Disable **Vetur**, and enable **Volar** extension

```
nvm use 18
```

```
npm install
```

<br/>

### II. Build for FAT

```
npm run build:fat
```

<br/>

### III. Build for UAT

```
npm run build:uat
```

<br/>

### IV. Build for PROD

```
npm run build
```

<br/>

# Deployment Guideline

-   Server configuration for router mode `history`
-   https://router.vuejs.org/zh/guide/essentials/history-mode.html#%E6%9C%8D%E5%8A%A1%E5%99%A8%E9%85%8D%E7%BD%AE%E7%A4%BA%E4%BE%8B
-   注意：以下示例假定你正在从根目录提供服务。如果你部署到子目录，你应该使用Vue CLI 的 publicPath 配置和相关的路由器的 base 属性。你还需要调整下面的例子，以使用子目录而不是根目录（例如，将RewriteBase/ 替换为 RewriteBase/name-of-your-subfolder/）。

    ### nginx

    ```
        location / {
            try_files $uri $uri/ /index.html;
        }
    ```

    ### Apache

    ```
    <IfModule mod_negotiation.c>
        Options -MultiViews
    </IfModule>

    <IfModule mod_rewrite.c>
        RewriteEngine On
        RewriteBase /
        RewriteRule ^index\.html$ - [L]
        RewriteCond %{REQUEST_FILENAME} !-f
        RewriteCond %{REQUEST_FILENAME} !-d
        RewriteRule . /index.html [L]
    </IfModule>
    ```

      <br/>

# Coding Standards and Guidelines

-   Variable names should be in `camelCase`
-   Component file names should be in `PascalCase`
-   Shared components or utils should be placed in the top level directory `src/components`, `src/composables`, `src/utils`, etc.

    ```
    src/components
        ├── HelloWorld.vue
        ├── AnotherComponent.vue
        ├── Dialogs
            ├── index.vue
            ├── component-script.ts
    ```

-   When using `<script setup>` syntax, always define the component's `name`
    -   https://github.com/chenxch/unplugin-vue-setup-extend-plus
    ```
    <script setup lang="ts" name="HelloWorld">
        ...
    </script>
    ```
    or
    ```
    <script setup>
       defineOptions({
           name: 'HelloWorld',
           ...
       })
    </script>
    ```
-   When using regular `<script>` syntax, always define the component's name
    ```
    export default {
        name: 'HelloWorld',
        ...
    }
    ```
-   Add code comments as necessary for maintainability.
-   Split code to isolate functions accordingly. Coupled functions and variables should be divided into its relevant directory as much as possible.
    ```
    ├──src/views
        ├── users
        │   ├── components  // 用于user领域的非路由Vue组件。
        │   │   ├── UserFormModal.vue
        │   │   ├── UserForm.vue
        │   │   └── ...
        │   ├── types  // 用于存放与user领域相关的TS类型定义和JS结构。
        │   │   ├── user.types.ts // user相关TypeScript类型的示例文件。
        │   │   ├── user.enums.ts  // user相关枚举的示例文件。
        │   │   └── ...
        │   ├── services  // 用于API调用和其他TypeScript文件的目录。
        │   │   ├── user.api.ts // 与user领域相关的API调用。
        │   │   ├── user.service.ts // 与user领域相关的更复杂的操作或业务逻辑。
        │   │   ├── user.options.ts // datatable/plugin options
        │   │   └── ...
        │   ├── index.vue // user领域的主页面或入口。
        │   ├── Details.vue // user的一个子页面，例如详细信息页面。
        │   └── README.md // 本文件包含user领域的文档，包括变更记录、相关需求票据、错误报告和使用指南。
    ```
-   Do not oversimplify or excessively split components and functions. Always prioritize maintainability.
-   When creating reusable shared components, documentation should be provided
    ```
    src/components
        ├── Dialogs
            ├── index.vue
            ├── component-script.ts
            └── README.md
    ```
-   Use `type` by default until you need a specific feature of interfaces, like 'extends'. `interface` should generally be used when declaration merging is necessary.
