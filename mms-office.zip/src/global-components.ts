import { App } from 'vue'
import BasicContainer from '@/components/BasicContainer.vue'
import svgIcon from '@/components/SvgIcon.vue'

export default function registerGlobalComponents(app: App<Element>): void {
	app.component('BasicContainer', BasicContainer)

	/**
	 * Global components 全局组件
	 *
	 * Register global components below this line 请在此行以下注册全局组件
	 *
	 * app.component('ComponentName', component)
	 *
	 */

	app.component('svg-icon', svgIcon)
}
