<template>
	<el-config-provider :locale="locale" :message="commonStore.messageConfig">
		<!-- :value-on-clear="null"
		:empty-values="[undefined, null]" -->
		<router-view />
	</el-config-provider>
</template>

<script setup lang="ts">
import zhCn from 'element-plus/es/locale/lang/zh-cn'
import en from 'element-plus/es/locale/lang/en'

const commonStore = useCommonStore()

const locale = computed(() => (commonStore.language === 'zhCn' ? zhCn : en))

// onMounted(() => {
// 	commonStore.fetchPlatforms()
// })
</script>
