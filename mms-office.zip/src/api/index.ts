export const getList = (
	currentPage: number,
	pageSize: number,
	formQuery: Record<any, unknown>,
	mockData: unknown[] = []
) => {
	const payload = {
		currentPage,
		pageSize,
		...toRaw(formQuery)
	}

	console.log('@/api/index.ts getList() ---> Form payload --->', payload)

	/**
	 *
	 * Call interface here
	 *
	 * return {
	 *      page: {
	 *          total: list.length
	 *      },
	 *      result: []
	 * }
	 *
	 */
	return new Promise((resolve) => {
		setTimeout(() => {
			const list = mockData
			resolve({
				page: {
					total: list.length
				},
				records: list.slice((currentPage - 1) * pageSize, currentPage * pageSize)
			})
		}, 100)
	})
}
