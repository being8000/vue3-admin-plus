/**
 * http://10.32.3.160:8085/doc.html#/default/%E7%BB%9F%E8%AE%A1%E9%A1%B5%E9%9D%A2%E6%8E%A5%E5%8F%A3/statistics
 * 统计页面接口
 * Vouncher-management/voucher-statistics
 *
 */

import { service } from '@/utils/request'

const moduleName = '/report'
export const report = {
	// 统计接口
	statistics(data = {}) {
		return service.post(`${moduleName}/statistics`, data)
	},
	// 详情列表查询接口
	list(data = {}) {
		return service.post(`${moduleName}/list`, data)
	},
	// 导出excel接口
	excelDownload(data = {}) {
		return service({
			url: `${moduleName}/excel/download`,
			method: 'post',
			data,
			timeout: 1000 * 60 * 30,
			responseType: 'blob'
		})
	},
	// 名称模糊匹配返回优惠分名称列表
	voucherList(params = {}) {
		return service.get(`${moduleName}/voucher/list`, {
			params
		})
	},
	// 名称模糊匹配返回活动名称列表
	activityList(params = {}) {
		return service.get(`${moduleName}/activity/list`, {
			params
		})
	}
}
