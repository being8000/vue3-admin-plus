import { createApp } from 'vue'
import App from './App.vue'
import registerGlobalComponents from './global-components'
import setupPlugins from './plugins'
import initData from './init-data'
import { loadOMS } from '@digiplus/digi-iframyee'

import '@/styles/index.scss'
import 'virtual:uno.css'

const app = createApp(App)

setupPlugins(app)
registerGlobalComponents(app)
initData()

loadOMS()

app.mount('#app')
