const AuthRoutes = {
	path: '/',
	name: 'auth',
	component: () => import('@/layout/AuthLayout.vue'),
	meta: {
		requiresAuth: false
	},
	redirect: {
		name: 'login'
	},
	hidden: true,
	children: [
		{
			name: 'login',
			path: '/auth/login',
			component: () => import('@/views/auth/Login.vue')
		},
		{
			path: '/404',
			name: 'NotFound404',
			component: () => import('@/components/ErrorPage/NotFound404.vue')
		},
		{
			path: '403',
			name: 'Unauthorized403',
			component: () => import('@/components/ErrorPage/Unauthorized403.vue')
		}
	]
}

export default AuthRoutes
