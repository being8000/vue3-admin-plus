import { createRouter, createWebHistory } from 'vue-router'
import MainRoutes from './MainRoutes'
import AuthRoutes from './AuthRoutes'
import { getToken } from '@digiplus/digi-iframyee'

const DEFAULT_TITLE = import.meta.env.VITE_TITLE || 'Marketing System'

export const router = createRouter({
	history: createWebHistory(),
	routes: [
		{
			path: '/:pathMatch(.*)*',
			redirect: {
				name: 'NotFound404'
			}
		},
		MainRoutes,
		AuthRoutes
	]
})

/**
 *
 * TODO: Setup auto-routing according to the folder structure and match router paths from API
 *
 **/

router.beforeEach(async (to, _from, next) => {
	// set page title
	document.title = to.meta.title ? [to.meta.title, DEFAULT_TITLE].join(' | ') : DEFAULT_TITLE
	// redirect to login page if not logged in and trying to access a restricted page
	try {
		const publicPages = ['/auth/login']
		const authRequired = !publicPages.includes(to.path)
		const token: any = import.meta.env.MODE != 'production' ? 'test_token' : getToken()

		if (to.matched.some((record) => record.meta.requiresAuth)) {
			if (authRequired && !token) {
				setItem('returnUrl', to.fullPath)
				next({ name: 'Unauthorized403' })
			} else {
				next()
			}
		} else if (!authRequired && token) {
			next({ name: 'main', replace: true })
		} else {
			next()
		}
	} catch (e) {
		console.log('router >> index.ts error', e)
	}
})

export default router
