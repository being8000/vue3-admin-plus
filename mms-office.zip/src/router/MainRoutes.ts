import { RouteMeta, RouteRecordRaw } from 'vue-router'
import { FunctionalComponent } from 'vue'

// import Home from '~icons/tabler/Home'

import eventManagement from './modules/event-management'
import voucherManagement from './modules/voucher-management'

/**
	活动系统
	- 活动列表
	- 活动详情
	- 活动详情-短信编辑
	- 活动详情-人群包上传
	- 提案列表

	优惠系统
	- 优惠金列表
	- 优惠金创建
	- 优惠金数据

 */

export interface CustomRouteMeta extends RouteMeta {
	title?: string
	requiresAuth?: boolean
	isHeader?: boolean
	icon?: FunctionalComponent
	showTag?: boolean
	tagKey?: string
	hideBreadcrumb?: boolean
	// You can add more meta properties here based on your needs
}

export interface AppRouteRecordRaw extends Omit<RouteRecordRaw, 'meta' | 'children' | 'name'> {
	meta: CustomRouteMeta
	name: string
	children?: AppRouteRecordRaw[]
	hidden?: boolean
}

export const routes = {
	path: '/',
	name: 'main',
	meta: {
		requiresAuth: true
	},
	redirect: {
		name: 'Events'
	},
	hidden: true,
	component: () => import('@/layout/MainLayout.vue'),
	children: [
		// {
		// 	name: 'dashboard',
		// 	path: '/dashboard',
		// 	component: () => import('@/views/Dashboard.vue'),
		// 	meta: {
		// 		title: 'Dashboard',
		// 		icon: Home
		// 	}
		// },
		eventManagement,
		voucherManagement
	]
}

export default routes
