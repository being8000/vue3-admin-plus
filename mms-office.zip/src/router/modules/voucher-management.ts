import IconTablerTimeLineEventText from '~icons/tabler/timeline-event-text'
import ReceiptTax from '~icons/tabler/receipt-tax'
import ChartDots3 from '~icons/tabler/chart-dots-3'

export default {
	name: 'voucherSystem',
	path: '/voucher-system',
	redirect: { name: 'Vouchers' },
	meta: {
		title: 'Voucher Management',
		icon: IconTablerTimeLineEventText,
		isHeader: true
	},
	children: [
		{
			// name: 'Vouchers',
			// path: 'vouchers',
			// component: () => import('@/layout/PageLayout.vue'),
			// redirect: { name: 'VoucherList' },
			// meta: {
			// 	title: 'Vouchers',
			// 	icon: ReceiptTax
			// },
			name: 'Vouchers',
			path: 'vouchers',
			component: () => import('@/views/voucher-management/vouchers/Index.vue'),
			meta: {
				title: 'Vouchers',
				icon: ReceiptTax
			}
			// children: [
			// 	{
			// 		name: 'VoucherList',
			// 		path: '',
			// 		component: () => import('@/views/voucher-management/vouchers/Index.vue'),
			// 		meta: {
			// 			title: 'Vouchers',
			// 			hideBreadcrumb: true
			// 		},
			// 		hidden: true
			// 	},
			// 	{
			// 		name: 'VoucherCreate',
			// 		path: 'create',
			// 		component: () => import('@/views/voucher-management/vouchers/View.vue'),
			// 		hidden: true,
			// 		meta: {
			// 			title: 'Create Voucher',
			// 			hidden: true,
			// 			back: true
			// 		}
			// 	},
			// 	{
			// 		name: 'VoucherView',
			// 		path: 'view/:id',
			// 		component: () => import('@/views/voucher-management/vouchers/View.vue'),
			// 		hidden: true,
			// 		meta: {
			// 			title: 'View Voucher',
			// 			hidden: true,
			// 			back: true,
			// 			showTag: true
			// 		}
			// 	}
			// ]
		},
		{
			name: 'VoucherStatistics',
			path: 'voucher-statistics',
			component: () => import('@/views/voucher-management/voucher-statistics/Index.vue'),
			meta: {
				title: 'Voucher Statistics',
				icon: ChartDots3
			}
		}
	]
}
