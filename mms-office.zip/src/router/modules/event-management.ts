import IconTablerTimeLineEventText from '~icons/tabler/timeline-event-text'
import CalendarEvent from '~icons/tabler/calendar-event'
import License from '~icons/tabler/license'

export default {
	name: 'eventManagement',
	path: '/event-management',
	redirect: { name: 'Events' },
	meta: {
		title: 'Event Management',
		icon: IconTablerTimeLineEventText,
		isHeader: true
	},
	children: [
		{
			name: 'Events',
			path: 'events',
			component: () => import('@/views/event-management/events/Index.vue'),
			meta: {
				title: 'Events',
				icon: CalendarEvent
			}
		},
		{
			name: 'Proposals',
			path: 'proposals',
			component: () => import('@/views/event-management/proposals/Index.vue'),
			meta: {
				title: 'Proposals',
				icon: License
			}
		}
	]
}
