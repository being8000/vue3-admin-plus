<template>
	<el-sub-menu
		v-if="route.children && route.children.length"
		:index="route.name?.toString() || ''">
		<template #title>
			<el-icon size="20"><component :is="route.meta?.icon" /></el-icon>
			<span v-if="route.meta?.title">{{ $t(route.meta?.title) }}</span>
		</template>
		<menu-item
			v-for="childRoute in route.children"
			:key="childRoute.name"
			:index="childRoute.name"
			:route="childRoute"
			v-bind:navigateTo
			v-bind:isRouteActive />
	</el-sub-menu>
	<el-menu-item
		v-else
		:index="route.name"
		@click="navigateTo(route)"
		:class="{ 'is-active': isRouteActive(route) }">
		<el-icon size="20"><component :is="route.meta?.icon" /></el-icon>
		<template #title v-if="route.meta?.title">
			{{ $t(route.meta.title) }}
		</template>
	</el-menu-item>
</template>

<script lang="ts" setup name="MenuItem">
import { AppRouteRecordRaw } from '@/router/MainRoutes'
import MenuItem from './MenuItem.vue'

defineProps<{
	route: AppRouteRecordRaw
	index: string | unknown
	navigateTo: (route: AppRouteRecordRaw) => void
	isRouteActive: (route: AppRouteRecordRaw) => boolean
}>()
</script>
