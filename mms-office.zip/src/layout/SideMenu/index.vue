<template>
	<el-menu
		:default-active="activePath"
		:router="true"
		mode="vertical"
		class="side-menu"
		:collapse="commonStore.isCollapse">
		<div class="menu-header">
			<img class="menu-logo" src="@/assets/icon.png" alt="Digiplus Logo" />
			<h5 class="title">DigiPlus</h5>
			<span class="app-name">{{ APP_TITLE }}</span>
		</div>

		<el-scrollbar wrap-class="scrollbar-wrapper">
			<template v-for="route in topLevelRoutes">
				<span class="menu-group-title" v-if="route.meta?.isHeader">
					{{ $t(route.meta.title as string) }}
				</span>
				<template v-if="route.children && route.children.length">
					<menu-item
						v-for="(childRoute, crIndex) in route.children"
						:key="`childRoute-${crIndex}`"
						:index="childRoute.name"
						:route="childRoute"
						v-bind:navigateTo
						v-bind:isRouteActive />
				</template>

				<!-- If no children, render regular menu item -->
				<el-menu-item
					v-else
					:index="route.name"
					@click="navigateTo(route)"
					:class="{ 'is-active': isRouteActive(route) }">
					<el-icon size="20"><component :is="route.meta?.icon" /></el-icon>
					<template #title v-if="route.meta?.title">
						{{ $t(route.meta.title) }}
					</template>
				</el-menu-item>
			</template>
		</el-scrollbar>
	</el-menu>
</template>

<script lang="ts" setup name="SideMenu">
import { useCommonStore } from '@/stores'
import MenuItem from './MenuItem.vue'
import { AppRouteRecordRaw } from '@/router/MainRoutes'
import { RouteRecordRaw } from 'vue-router'

const APP_TITLE = import.meta.env.VITE_APP_TITLE
const commonStore = useCommonStore()
const router = useRouter()
const route = useRoute()

const filterRoutes = (routes: AppRouteRecordRaw[]) => {
	const filteredRoutes: AppRouteRecordRaw[] = []

	routes.forEach((route) => {
		if (!route.meta || !route.hidden) {
			if (route.children) {
				route = {
					...route,
					children: filterRoutes(route.children)
				}
			}
			filteredRoutes.push(route)
		} else if (route.children) {
			// Promote visible children to top level if parent is hidden
			filteredRoutes.push(
				...filterRoutes(route.children.filter((child) => !child.meta || !child.hidden))
			)
		}
	})

	return filteredRoutes
}

const navigateTo = (route: RouteRecordRaw | AppRouteRecordRaw) => {
	router.push({ name: route.name })
}

const topLevelRoutes = computed(() => {
	const allRoutes = filterRoutes(
		router.getRoutes().find((item) => item.name === 'main')?.children as AppRouteRecordRaw[]
	)
	const childPaths = new Set(allRoutes.flatMap((r) => r.children?.map((child) => child.name)))
	console.log(childPaths)
	return allRoutes.filter((r) => !childPaths.has(r.name))
})

const activePath = computed(() => {
	let activeRoute = route as any
	for (let i = route.matched.length - 1; i >= 0; i--) {
		const topRoutes = topLevelRoutes.value
		if (topRoutes.find((r) => r.name === route.matched[i].name)) {
			activeRoute = route.matched[i]
			break
		}
	}

	return activeRoute.name
})

const isRouteActive = (r: AppRouteRecordRaw) => route.matched.some((m) => m.name === r.name)
</script>

<style lang="scss">
.side-menu.el-menu {
	--menu-header-height: 150px;
	--menu-header-padding: 20px;

	.menu-header {
		min-height: 100px;
		height: var(--menu-header-height);
		width: 100%;
		display: flex;
		align-items: center;
		justify-content: center;
		padding-top: var(--menu-header-padding);
		padding-bottom: var(--menu-header-padding);
		flex-direction: column;

		.menu-logo {
			height: 80px;
		}

		.title {
			font-size: 1.3rem;
			font-weight: 900;
			margin-top: 10px;
			margin-bottom: 0;
			text-wrap: nowrap;
		}

		.app-name {
			font-size: 0.9rem;
			font-weight: 500;
			margin-top: 0;
			text-wrap: nowrap;
		}
	}

	.menu-items {
		flex: 1;
	}

	&.el-menu--collapse {
		width: 63px;

		.title,
		span {
			display: none;
		}
		.menu-logo {
			height: 40px;
		}

		~ .el-sub-menu > .el-sub-menu__title > span {
			height: 0;
			width: 0;
			overflow: hidden;
			visibility: hidden;
			display: inline-block;
		}

		.el-sub-menu > .el-sub-menu__title .el-sub-menu__icon-arrow {
			display: none;
		}
	}

	.el-scrollbar {
		height: calc(100% - calc(var(--menu-header-height) + var(--menu-header-padding) * 2));
		width: inherit;
	}

	&:not(.el-menu--collapse) {
		.el-menu-item {
			width: 230px;
		}

		min-height: 400px;
		// .group-menu {
		.menu-group-title {
			visibility: visible;
		}
		// }
	}

	.el-menu-item,
	.el-sub-menu__title {
		&.is-active {
			.el-icon svg {
				color: var(--el-menu-active-color);
			}
		}

		.el-icon {
			svg {
				color: var(--el-menu-text-color);
			}
		}
	}

	// .group-menu {
	.menu-group-title {
		visibility: hidden;
		display: block;
		padding: 12px 16px;
		margin-top: 16px;
		font-size: 0.7rem;
		font-weight: 500;
		text-transform: uppercase;
		text-wrap: nowrap;
		color: var(--el-menu-text-color);
		opacity: 0.7;
	}
	// }

	:global(.el-menu-item),
	:global(.el-sub-menu .el-sub-menu__title) {
		hyphens: auto;
		overflow-wrap: normal;
		overflow: hidden;
		white-space: nowrap;
		text-overflow: ellipsis;
		word-break: normal;
		word-wrap: break-word;
		font-size: 0.875rem;
		font-weight: 400;
		letter-spacing: 0.009375em;
		line-height: 1.5rem;
		text-transform: none;
		font-size: 0.875rem;

		&.is-active {
			.el-icon svg {
				color: var(--el-menu-active-color);
			}
		}

		.el-icon {
			svg {
				color: var(--el-text-color-regular);
			}
		}
	}
}
</style>
