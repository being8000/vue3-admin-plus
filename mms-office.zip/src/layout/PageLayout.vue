<template>
	<page-header />

	<section>
		<router-view />
	</section>
</template>

<script lang="ts" setup name="PageLayout">
import PageHeader from '@/components/PageHeader.vue'
</script>
