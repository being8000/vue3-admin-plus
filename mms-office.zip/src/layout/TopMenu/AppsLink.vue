<template>
	<el-row class="app-list">
		<el-col :span="12" v-for="(item, i) in appsLink" :key="i">
			<router-link :to="item.href" custom v-slot="{ navigate }">
				<div @click="navigate" class="app-list-item">
					<el-avatar
						:src="item.avatar"
						:size="45"
						shape="square"
						fit="contain"></el-avatar>

					<div>
						<h3 class="text-primary font-weight-semibold app-list-item-title">
							{{ item.title }}
						</h3>

						<p class="text-subtitle-2 app-list-item-subtitle">{{ item.subtext }}</p>
					</div>
				</div>
			</router-link>
		</el-col>
	</el-row>
</template>

<script setup lang="ts">
import img4 from '@/assets/icon-dd-date.svg'
import img6 from '@/assets/icon-dd-lifebuoy.svg'
import img8 from '@/assets/icon-dd-application.svg'
import gamePlus from '@/assets/tongits.png'
import bingoPlus from '@/assets/bp.png'
import arenaPlus from '@/assets/ap.png'

type appsLinkType = {
	avatar: string
	title: string
	subtext: string
	href: string
}
const appsLink: appsLinkType[] = [
	{
		avatar: gamePlus,
		title: 'GamePlus Store',
		subtext: 'This app description',
		href: '/apps/chats'
	},
	{
		avatar: img4,
		title: 'GamePlus Legal',
		subtext: 'This app description',
		href: '/apps/calendar'
	},
	{
		avatar: bingoPlus,
		title: 'BingoPlus Store',
		subtext: 'This app description',
		href: '/apps/contacts'
	},
	{
		avatar: img8,
		title: 'BingoPlus Legal',
		subtext: 'This app description',
		href: '/pages/account-settings'
	},
	{
		avatar: arenaPlus,
		title: 'ArenaPlus Store',
		subtext: 'This app description',
		href: '/apps/email'
	},
	{
		avatar: img6,
		title: 'ArenaPlus Legal',
		subtext: 'This app description',
		href: '/apps/notes'
	}
]
</script>

<style lang="scss" scoped>
:deep(.el-avatar) {
	background: var(--el-fill-color);
	padding: 3px;
}

.app-list {
	padding: 12px;

	&-item {
		display: flex;
		align-items: center;
		gap: 12px;
		padding: 8px;
		border-radius: 8px;

		&:hover {
			background: var(--el-fill-color);
		}

		&-title,
		&-subtitle {
			margin: 0;
		}
	}
}

.text-primary {
	color: var(--el-menu-text-color);
}
</style>
