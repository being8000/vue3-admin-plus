<template>
	<el-menu
		class="top-menu"
		mode="horizontal"
		:ellipsis="false"
		menu-trigger="click"
		close-on-click-outside
		@select="handleSelect">
		<el-button @click="commonStore.toggleMenu" index="0" text>
			<el-icon style="vertical-align: middle" :size="20">
				<icon-tabler-menu2 />
			</el-icon>
		</el-button>

		<el-breadcrumb :separator-icon="ArrowRight" class="lg:block hidden">
			<el-breadcrumb-item :to="{ path: '/' }" class="home-breadcrumb">
				<el-icon :size="16"><icon-tabler-home-filled /></el-icon>
			</el-breadcrumb-item>
			<el-breadcrumb-item
				v-for="(crumb, index) in breadcrumbs"
				:key="index"
				:to="index < breadcrumbs.length - 1 ? crumb.to : undefined">
				{{ $t(crumb.title as string) }}
			</el-breadcrumb-item>
		</el-breadcrumb>

		<el-tag v-if="!IS_PROD">
			{{ APP_MODE }}
		</el-tag>

		<div class="flex-grow" />

		<!-- TODO - OMS SDK bridge v2 - get shortcuts
		<el-dropdown trigger="click" placement="bottom-start">
			<el-button text :icon="IconTablerGrid">
				Products
				<el-icon :size="16" class="pl-1">
					<icon-ep-arrow-down />
				</el-icon>
			</el-button>
			<template #dropdown>
				<el-row style="width: 500px">
					<el-col :span="24" class="py-0">
						<AppsLink />
					</el-col>
				</el-row>
			</template>
		</el-dropdown> -->

		<el-button round @click="commonStore.toggleLanguage" style="padding: 0 5px">
			<el-avatar :size="22" :src="langImage"></el-avatar>
		</el-button>

		<el-switch
			v-model="isDark"
			inline-prompt
			size="large"
			:active-action-icon="TablerMoonFilled"
			:inactive-action-icon="TablerSunFilled"
			:active-icon="TablerSunFilled"
			:inactive-icon="TablerMoonFilled"
			style="
				--el-switch-on-color: var(--el-color-primary);
				--el-switch-off-color: var(--el-text-color-disabled);
			" />

		<!-- TODO - OMS SDK bridge v2 - do logout, get user data
			<user-settings />
		-->
	</el-menu>
</template>

<script lang="ts" setup>
import { useCommonStore } from '@/stores'
import zhCnImage from '@/assets/lang/zh-cn.svg?url'
import enImage from '@/assets/lang/en.svg?url'
import TablerMoonFilled from '~icons/tabler/moon-filled'
import TablerSunFilled from '~icons/tabler/sun-filled'
import { ArrowRight } from '@element-plus/icons-vue'
import { useDark } from '@vueuse/core'
// import UserSettings from './UserSettings.vue'

const APP_MODE = import.meta.env.MODE.toUpperCase()
const IS_PROD = import.meta.env.PROD

const commonStore = useCommonStore()
const route = useRoute()

const handleSelect = (key: string, keyPath: string[]) => {
	console.log(key, keyPath)
}

const isDark = useDark({ initialValue: 'light' })

const langImage = computed(() => {
	try {
		return commonStore.language == 'en' ? enImage : zhCnImage
	} catch (e) {
		return '' // Return a default image or empty string if not found
	}
})

const breadcrumbs = computed(() => {
	console.log(route.matched, 'matched')
	const matchedRoutes = route.matched.filter(
		(route) => route.meta && route.meta.title && !route.meta.hideBreadcrumb
	)
	return matchedRoutes.map((route) => ({
		title: route.meta.title,
		to: route.path
	}))
})
</script>

<style lang="scss" scoped>
.top-menu {
	display: flex;
	align-items: center;
	padding: 0 24px;
	gap: 20px;

	.el-menu--popup {
		border-radius: var(--el-popover-border-radius) !important;
	}
}
</style>
