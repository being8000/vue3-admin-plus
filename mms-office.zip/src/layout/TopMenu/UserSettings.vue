<template>
	<el-sub-menu index="2" popper-class="user-settings-dropdown">
		<template #title>
			<el-avatar :src="defaultAvatar">U</el-avatar>
			<span style="margin-left: 10px">{{ loginName }}</span>
		</template>
		<div class="profile-dropdown-container px-6 py-2">
			<!------------------ DROPDOWN HEADER ------------------->

			<h2 class="my-3 font-normal">Hello, good day!</h2>
			<div class="user-card mt-1">
				<el-avatar :src="defaultAvatar" :size="60"></el-avatar>
				<div style="display: flex; flex-direction: column">
					<span class="user-name">{{ loginName }}</span>
					<span>Super Admin</span>
					<span>@ username</span>
				</div>
			</div>

			<el-divider />

			<!------------------ SETTINGS LIST------------------->

			<div class="settings-list">
				<el-button class="settings-item" plain text>
					<div class="settings-card">
						<el-avatar :src="img1" :size="48" shape="square"></el-avatar>
						<div class="settings-label">
							<span class="settings-card-title">Security Settings</span>
							<span class="settings-card-desc">Change password</span>
						</div>
					</div>
				</el-button>

				<el-button class="settings-item" plain text>
					<div class="settings-card">
						<el-avatar :src="img2" :size="48" shape="square"></el-avatar>
						<div class="settings-label">
							<span class="settings-card-title">Setting #2</span>
							<span class="settings-card-desc">Give a short description</span>
						</div>
					</div>
				</el-button>

				<el-button class="settings-item" plain text>
					<div class="settings-card">
						<el-avatar :src="img3" :size="48" shape="square"></el-avatar>
						<div class="settings-label">
							<span class="settings-card-title">Setting #3</span>
							<span class="settings-card-desc">Give a short description</span>
						</div>
					</div>
				</el-button>
			</div>

			<el-button
				class="logout-btn"
				type="primary"
				plain
				size="large"
				@click="userStore.logout()">
				Logout
			</el-button>
		</div>
	</el-sub-menu>
</template>

<script lang="ts" setup name="UserSettings">
import { useUserStore } from '@/stores'
import defaultAvatar from '@/assets/default-avatar.gif'
import img1 from '@/assets/icon-dd-lifebuoy.svg'
import img2 from '@/assets/icon-dd-date.svg'
import img3 from '@/assets/icon-dd-application.svg'

const userStore = useUserStore()

const loginName = computed(() => {
	return userStore.user.name
})
</script>

<style lang="scss" scoped>
.el-divider {
	margin: 12px 0 0;
}

:global(.user-settings-dropdown .el-menu--popup) {
	border-radius: var(--el-popover-border-radius);
}

.settings-list {
	display: flex;
	flex-direction: column;
	margin-bottom: 12px;
}

.settings-item {
	height: 80px;
	display: flex;
	justify-content: flex-start;
	margin: 0;
	color: var(--el-color-secondary);

	&:hover {
		.settings-card-title {
			color: var(--el-color-primary);
		}
	}

	.settings-card {
		display: flex;
		gap: 12px;
		align-items: center;

		.settings-label {
			display: flex;
			flex-direction: column;
			align-items: flex-start;
			gap: 4px;
		}

		&-title {
			font-size: 0.875rem;
			font-weight: 700;
			line-height: 1.2rem;
			letter-spacing: 0.0125em;
			// transition: color ease-in-out 200ms;
		}

		&-desc {
			font-size: 0.8rem;
			color: var(--el-text-color-regular);
		}

		.el-avatar {
			background-color: #f1f1f1;
			padding: 8px;
		}
	}
}

.profile-dropdown-container {
	display: flex;
	flex-direction: column;
	gap: 12px;
	width: 260px;

	.user-card {
		display: flex;
		gap: 12px;
		align-items: center;
	}

	.user-name {
		font-size: 1rem;
		font-weight: 600;
		line-height: 1.2rem;
		letter-spacing: 0.0125em;
	}

	span {
		line-height: 1rem;
	}

	.logout-btn {
		align-self: stretch;
	}
}
</style>
