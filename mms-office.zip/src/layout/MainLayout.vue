<template>
	<div class="main-layout">
		<el-container>
			<SideMenu />

			<el-container class="content-container">
				<TopMenu />

				<el-main>
					<router-view :key="route.fullPath" #="{ Component }">
						<!-- TODO: <keep-alive :include="commonStore.tagsKeep"> -->
						<!-- <keep-alive> -->
						<component :is="Component" />
						<!-- </keep-alive> -->
					</router-view>
				</el-main>
			</el-container>
		</el-container>
	</div>
</template>

<script setup lang="ts" name="MainLayout">
import SideMenu from '@/layout/SideMenu/index.vue'
import TopMenu from '@/layout/TopMenu/index.vue'

const route = useRoute()
</script>

<style scoped>
.el-container.content-container {
	flex-direction: column;

	/* left: 63px;
	position: relative; */
}

.el-footer {
	background-color: var(--el-content-background-color);
	font-size: 0.8em;
	display: flex;
	align-items: center;
	color: var(--el-text-color-disabled);
}
</style>
