export default {
	Login: '登录',
	Username: '用户名',
	Password: '密码',
	Dashboard: '仪表板',
	'VXE Table Demo': 'VXE Table 演示',
	Refresh: '刷新',
	Marketing: '营销',
	'Event Management': '活动系统',
	Events: '活动列表',
	Proposals: '提案列表',
	'Voucher Management': '优惠系统',
	// Vouchers: '优惠金列表',
	'Voucher Statistics': '优惠金数据',
	Vouchers: '优惠金',
	'Create Voucher': '创建优惠金',

	'Total Amount': '总金额',
	'Claimed Amount': '已领取金额',
	'Claimed Ratio': '领取比例',
	'Used Amount': '已使用金额',
	'Used Ratio': '使用比例',
	'Expired Amount': '已过期金额',

	Confirm: '确认',
	Cancel: '取消',
	ConfirmMessage: '您确定要{type}此记录吗？',
	'Please confirm': '请确认',
	'Start Time': '开始时间',
	'End Time': '结束时间',
	All: '全部',
	View: '查看',
	Edit: '编辑',
	Create: '创建',

	bet: '投注',
	rebate: '返水',
	turnover: '流水',
	voucherType: '{0}优惠分',

	'Voucher Type': '优惠分类型',
	Type: '类型',

	'Return to homepage': '返回首页',
	'Go back to previous page': '返回上一页',

	// Are you sure you want to {type} this record?

	/**
	 *
	 * VXE-table
	 * To translate the table
	 * it is configured to only translate keys prefixed with `table.`
	 * Check ./src/plugins/vxe-table.ts for configuration
	 *
	 */

	Required: '{field}不能为空',

	table: {
		Search: '查询',
		Reset: '重置',
		InputPrefix: '请输入{field}',
		Required: '{field}不能为空',
		Approve: '批准',
		Reject: '拒绝',
		View: '查看',
		Resume: '恢复',
		Suspend: '停止',
		Upload: '上传',
		Edit: '编辑',

		Name: '名字',
		Sex: '性别',
		Address: '地址',
		Nickname: '昵称',
		Role: '角色',
		Reviewer: '审查人',
		UpdatedAt: '更新时间',
		Auditor: '审核人',

		/** Event Management >> Proposals */

		Event: '活动',
		Product: '产品',
		VoucherName: '优惠金名称',
		EventName: '活动名称',
		Types: '类型',
		VoucherType: '优惠金类型',
		Account: '账户',
		CreatedBy: '创建者',
		CreateTime: '创建时间',
		AuditTime: '审计时间',
		Amount: '金额',
		Status: '状态',

		Operations: '操作',

		/** Voucher Management */
		// TODO: Translate the following keys

		DistributionTime: '发放时间',
		ReceptionTime: '领取时间',
		SettlementTime: '结算时间',
		ExpirationTime: '过期时间',
		BillNumber: '账单号',
		VoucherStatus: '优惠分状态',
		VoucherDistributionStatus: '优惠分发放状态',

		/** Event Management */

		GameScope: '游戏范围',
		GamePlatform: '平台',
		GameType: '种类',
		GameName: '名称',
		ID: 'ID',
		UpdatedBy: '更新者',
		UpdateTime: '更新时间',
		EventStatus: '活动状态',
		AuditStatus: '审计状态'
	},

	Deduplication: '是否去重',
	DeduplicationInfo: '判断逻辑同一用户是否可重复发放'
}
