export default {
	Login: 'Login',
	Username: 'Username',
	Password: 'Password',
	Dashboard: 'Dashboard',
	'VXE Table Demo': 'VXE Table Demo',
	Refresh: 'Refresh',
	Marketing: 'Marketing',
	'Event Management': 'Event Management',
	Events: 'Events',
	Proposals: 'Proposals',
	'Voucher Management': 'Voucher Management',
	Vouchers: 'Vouchers',
	'Voucher Statistics': 'Voucher Statistics',
	'Create Voucher': 'Create Voucher',

	'Total Amount': 'Total Amount',
	'Claimed Amount': 'Claimed Amount',
	'Claimed Ratio': 'Claimed Ratio',
	'Used Amount': 'Used Amount',
	'Used Ratio': 'Used Ratio',
	'Expired Amount': 'Expired Amount',

	Confirm: 'Confirm',
	Cancel: 'Cancel',
	ConfirmMessage: 'Are you sure you want to {type} this record?',
	ConfirmMessageAll: 'Are you sure you want to {type} all records?',
	'Please confirm': 'Please confirm',
	'Start Time': 'Start Time',
	'End Time': 'End Time',
	All: 'All',
	View: 'View',
	Edit: 'Edit',
	Create: 'Create',

	bet: 'Bet',
	rebate: 'Rebate',
	turnover: 'Turnover',
	voucherType: '{0} Voucher',

	'Voucher Type': 'Type',
	Type: 'Type',

	'Return to homepage': 'Return to homepage',
	'Go back to previous page': 'Go back to previous page',

	/**
	 *
	 * VXE-table
	 * To translate the table
	 * it is configured to only translate keys prefixed with `table.`
	 * Check ./src/plugins/vxe-table.ts for configuration
	 *
	 */

	// InputPrefix: 'Please input {field}',
	Required: 'Required',

	table: {
		Search: 'Search',
		Reset: 'Reset',
		InputPrefix: 'Please input {field}',
		Required: 'Required',
		Approve: 'Approve',
		Reject: 'Reject',
		View: 'View',
		Resume: 'Resume',
		Suspend: 'Suspend',
		Upload: 'Upload',
		Edit: 'Edit',

		Name: 'Name',
		Sex: 'Sex',
		Address: 'Address',
		Nickname: 'Nickname',
		Role: 'Role',
		Reviewer: 'Reviewer',
		UpdatedAt: 'Updated At',
		Auditor: 'Auditor',

		/** Event Management >> Proposals */

		Event: 'Event',
		Product: 'Product',
		VoucherName: 'Voucher Name',
		EventName: 'Event Name',
		Types: 'Types',
		VoucherType: 'Voucher Type',
		Account: 'Account',
		CreatedBy: 'Created By',
		CreateTime: 'Create Time',
		AuditTime: 'Audit Time',
		Amount: 'Amount',
		Status: 'Status',

		Operations: 'Operations',

		/** Voucher Management */

		DistributionTime: 'Distribution Time',
		ReceptionTime: 'Reception Time',
		SettlementTime: 'Settlement Time',
		ExpirationTime: 'Expiry Time',
		BillNumber: 'Bill No.',
		VoucherStatus: 'Voucher Status',
		VoucherDistributionStatus: 'Distribution Status',

		/** Event Management */

		GameScope: 'Game Scope',
		GamePlatform: 'Platform',
		GameType: 'Type',
		GameName: 'Name',
		ID: 'ID',
		UpdateBy: 'Updated By',
		UpdateTime: 'Update Time',
		EventStatus: 'Event Status',
		AuditStatus: 'Audit Status'
	},

	Deduplication: 'Deduplication',
	DeduplicationInfo: 'Determine logically whether the same user can be issued repeatedly'
}
