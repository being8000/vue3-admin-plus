import { createI18n } from 'vue-i18n'
import elementEnLocale from 'element-plus/es/locale/lang/en'
import elementZhLocale from 'element-plus/es/locale/lang/zh-cn'
import vxeZhCN from 'vxe-table/lib/locale/lang/zh-CN'
import vxeEnUS from 'vxe-table/lib/locale/lang/en-US'

import enLocale from './en'
import zhLocale from './zh-cn'
export const messages = {
	en: {
		...enLocale,
		...elementEnLocale,
		...vxeEnUS
	},
	zhCn: {
		...zhLocale,
		...elementZhLocale,
		...vxeZhCN
	}
}

export const i18n = createI18n({
	legacy: false, // set to `true` if you want to use Vue 2 i18n features
	locale: getItem('language') || 'zhCn',
	fallbackLocal: 'en',
	globalInjection: true,
	messages
})

export default i18n
