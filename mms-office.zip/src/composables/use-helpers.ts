import { FormInstance } from 'element-plus'
import { startCase, toLower } from 'lodash'

export const mapEnumToOptions = <T extends number | string>(
	enumObj: {
		[key: string]: T
	},
	options?: {
		encloseValue?: boolean
		labelKey?: string
	},
	textTransform: boolean = true,
	showValue: boolean = false
): Array<{ value: T; label: string }> => {
	return (
		Object.entries(enumObj)
			// Apply filter without destructuring in parameters
			.filter(([key, _value]) => {
				// Exclude numeric keys to avoid processing reverse-mapped numeric enum values
				return isNaN(Number(key))
			})
			.map(([key, value]) => {
				const label = textTransform ? startCase(toLower(key)) : key
				return {
					value,
					label: showValue
						? value.toString()
						: options?.encloseValue
							? `${label} (${value})`
							: label
				}
			})
	)
}

/**
 * Form Helpers
 *
 */

export const handleClearValidate = (fields: string | string[], formRef?: FormInstance) => {
	if (!formRef) return
	formRef.clearValidate(fields)
}

export const cleanQuery = (formQuery: Record<any, any>) => {
	return omitBy(formQuery, (value, key) => isNil(value) || endsWith(key, '_temp'))
}
