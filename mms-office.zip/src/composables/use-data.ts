import { report } from '@/api/report'

export function useReportVoucherOptions() {
	const options = reactive<{
		data: LabelValue[]
		loading: boolean
	}>({
		data: [],
		loading: false
	})

	const fetchOptions = (query: string) => {
		options.loading = true
		report
			.voucherList({ voucherName: query })
			.then((res: any) => {
				options.data = (res.result || []).map(({ voucherId, voucherName }: any) => {
					return {
						label: voucherName,
						value: voucherId
					}
				})
			})
			.finally(() => {
				options.loading = false
			})
	}
	return {
		options,
		fetchVouchers: fetchOptions
	}
}
export function useActivityOptions() {
	const options = reactive<{
		data: LabelValue[]
		loading: boolean
	}>({
		data: [],
		loading: false
	})

	const fetchOptions = (query: string) => {
		options.loading = true
		report
			.activityList({ activityName: query })
			.then((res: any) => {
				options.data = (res.result || []).map(({ activityId, activityName }: any) => {
					return {
						label: activityName,
						value: activityId
					}
				})
			})
			.finally(() => {
				options.loading = false
			})
	}
	return {
		options,
		fetchActivity: fetchOptions
	}
}
