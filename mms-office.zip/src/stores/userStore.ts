import router from '@/router'

export const useUserStore = defineStore('user', {
	state: () => ({
		user: getItem('user'),
		returnUrl: null
	}),
	actions: {
		async login(payload: Record<any, any>) {
			try {
				console.log(payload)

				// const user = await request.post(`/user`, payload)

				/*
					TODO: Implement login logic
				*/

				this.user = {
					name: 'Chris',
					token: '1234567'
				}

				setItem('user', this.user)
			} catch (e) {
				console.log(e)
			}
		},
		logout() {
			try {
				this.user = null

				deleteItem('user')

				router.push({ name: 'login', replace: true })
			} catch (e) {
				console.log(e)
			}
		}
	}
})
