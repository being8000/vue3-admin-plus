import { ActivityDetails } from '@/views/event-management/events/types'
import { useToggle } from '@vueuse/core'
import { GamePlatform, Product } from '~/types'

type SelectionList = {
	value: any
	label: any
}

export const useCommonStore = defineStore('common', {
	state: () => ({
		theme: useToggle(false),
		language: getItem('language') || 'zhCn',
		messageConfig: {
			max: 3
		},
		isCollapse: false,
		isFullScreen: false,
		isMenu: true,
		isSearch: false,
		isRefresh: true,
		isMacOs: false,
		platforms: [] as SelectionList[],
		activityList: [] as SelectionList[],
		products: mapEnumToOptions(Product, { encloseValue: true })
		// isLock:
	}),
	actions: {
		toggleLanguage() {
			this.language = this.language === 'zhCn' ? 'en' : 'zhCn'
			setItem('language', this.language)
		},
		toggleMenu() {
			this.isCollapse = !this.isCollapse
		},
		async fetchPlatforms() {
			const { result }: { result?: GamePlatform[] } = await service.post(
				'/getPlatformListFromSeamless'
			)

			this.platforms = result
				? result.map((platform) => {
						return {
							value: platform.platformId,
							label: platform.platformName
						}
					})
				: []
		},
		async fetchActivity() {
			const { result }: { result?: { rows: ActivityDetails[] } } = await service.post(
				'/proposal/activityConfig/pageList',
				{
					pageNum: 1,
					pageSize: 100
				}
			)

			this.activityList = result
				? result.rows?.map((activity) => {
						return {
							value: activity.activityId,
							label: activity.activityName
						}
					})
				: []
		}
	}
})
