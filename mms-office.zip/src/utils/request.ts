import axios, { type AxiosInstance, type InternalAxiosRequestConfig, AxiosError } from 'axios'
import NProgress from 'nprogress'
import * as digi from '@digiplus/digi-iframyee'

const service: AxiosInstance = axios.create({
	/**
	 * DO NOT edit this configuration unless necessary
	 * To override this configuration, use the relevant .env files and restart your local server
	 */
	baseURL: import.meta.env.VITE_PROXY_PATH || import.meta.env.VITE_BASE_URL,
	timeout: 30000
})

NProgress.configure({
	showSpinner: false
})

service.defaults.headers.common = {
	Accept: 'application/json'
}

service.interceptors.request.use(
	(request: InternalAxiosRequestConfig) => {
		NProgress.start()
		const token: string | null = digi.getToken()

		console.log(token, '<--- TOKEN')

		// const {
		// 	headers: { isToken }
		// } = request

		if (token) {
			const omsInfo: any = digi.getOMSinfo()
			request.headers['Authorization'] = 'Bearer ' + token
			request.headers['System-Identity'] = omsInfo.systemIdentity
			request.headers['System-ID'] = omsInfo.systemId

			request.headers['Cookie'] = `SERVERID=3;pig-access-token=${token}`
		}

		return request
	},
	(error: AxiosError) => {
		return Promise.reject(error)
	}
)

export type MktBaseResponse = {
	errorCode?: number | null
	errorMessage?: string | null
	result?:
		| {
				records?: []
		  }
		| any
	success?: boolean
}
const downloadFile = (response: any) => {
	try {
		const { headers, data } = response
		const contentDisposition = headers['content-disposition']
		const matches = contentDisposition.match(/filename=(?<fileName>.+)/)
		const fileName = matches && matches.groups.fileName
		const link = document.createElement('a')
		// 创建下载的链接
		const href = window.URL.createObjectURL(data || 'file.xlsx')
		link.href = href
		// 下载后文件名
		link.download = decodeURI(fileName)
		document.body.appendChild(link)
		link.click()
		link.remove()
	} catch (e) {
		console.log('error download file --->', e)
	}
}

service.interceptors.response.use(
	(response) => {
		NProgress.done()
		const { data }: { data: MktBaseResponse } = response
		const status = Number(response.status) || 200

		// console.log('request.ts ---> response', response)

		if (status !== 200 || data.errorCode) {
			ElMessage({
				message: data.errorMessage || 'Request error. Please try again',
				type: 'error'
			})
			// throw Promise.reject(new Error(response.data.errorMessage))
			// new AxiosError(
			// 	data.errorMessage || 'Request error. Please try again',
			// 	response.status.toString()
			// )

			return Promise.reject(data.errorMessage || 'Request error. Please try again')
		}

		console.log(
			'download data --->',
			response.headers['content-disposition']?.match(/^attachment/)
		)
		if (
			Object(response.data).constructor.name == 'Blob' ||
			response.headers['content-disposition']?.match(/^attachment/)
		) {
			downloadFile(response)
			return
		}
		return response.data
	},
	(error: AxiosError) => {
		NProgress.done()
		console.log('request.ts ---> response error', error)

		ElMessage({
			message: error.message || 'Something went wrong. Please try again',
			type: 'error'
		})

		return Promise.reject('Server error. Please contact administrator. (' + error.message + ')')
	}
)

export { service }
