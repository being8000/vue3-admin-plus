import Cookies from 'js-cookie'

const tokenKey: string = 'ap-admin-access-token'
const refreshTokenKey: string = 'ap-admin-refresh-token'

const getToken = () => Cookies.get(tokenKey)

const setToken = (token: string) => Cookies.set(tokenKey, token)

const removeToken = () => Cookies.remove(tokenKey)

const getRefreshToken = () => Cookies.get(refreshTokenKey)

const setRefreshToken = (token: string) => Cookies.set(refreshTokenKey, token)

export { getToken, setToken, removeToken, getRefreshToken, setRefreshToken }
