const appKey: string = import.meta.env.VITE_STORAGE_KEY

export const STORAGE_TYPES = {
	Local: localStorage,
	Session: sessionStorage
}

export const setItem = (key: string, data: unknown, storageType: Storage = STORAGE_TYPES.Local) => {
	try {
		storageType.setItem(appKey + key, JSON.stringify(data))
	} catch (e) {
		console.log(e)
	}
}

export const getItem = (key: string, storageType: Storage = STORAGE_TYPES.Local) => {
	try {
		const data: string | null = storageType.getItem(appKey + key) || ''

		const parsedData = data ? JSON.parse(data) : undefined

		return parsedData
	} catch (e) {
		console.log(e)
	}
}

export const deleteItem = (key: string, storageType: Storage = STORAGE_TYPES.Local) => {
	try {
		storageType.removeItem(appKey + key)
		return true
	} catch (e) {
		console.log(e)
	}
}
