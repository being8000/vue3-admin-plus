import {
	ElAlert,
	ElMessage,
	ElMessageBox,
	ElNotification,
	ElPopover,
	ElOverlay
} from 'element-plus'

export const useElementPlus = (app: any) => {
	app.use(ElMessageBox)
		.use(ElNotification)
		.use(ElMessage)
		.use(ElAlert)
		.use(ElPopover)
		.use(ElOverlay)
}
