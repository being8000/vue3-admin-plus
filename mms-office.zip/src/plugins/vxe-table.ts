import { App } from 'vue'
import {
	VXETable,
	config as VXETableConfig,
	Filter,
	Column,
	Edit,
	Icon,
	Table,
	Pager,
	Grid,
	Select,
	Form,
	Button,
	Input,
	Option,
	Tooltip,
	Modal,
	Toolbar,
	Export
} from 'vxe-table'

import VXETablePluginElement from 'vxe-table-plugin-element'
import VXETablePluginExportXLSX from 'vxe-table-plugin-export-xlsx'
import ExcelJS from 'exceljs'
import { ElTag, ElCheckbox, ElDatePicker, ElInput, ElSelectV2, ElText } from 'element-plus'
import moment from 'moment'

const useVxeTable = (app: App): void => {
	const { t } = i18n.global

	VXETableConfig({
		i18n: (key, args) => t(key, args),
		translate(key, args) {
			// Only translate keys starting with "table."
			if (key && key.indexOf('table.') > -1) {
				// const regex = /table\.\w+/g
				// return key.replace(regex, (match) => {
				// 	// Check if the match is in the translations object
				// 	return t(match, args) // Return the translation or the original match if not found
				// })

				return t(key, args)
			}
			return key
		},
		// size: 'small',
		pager: {
			// perfect: true,
			loading: true,
			pageSize: 20,
			pageSizes: [10, 20, 30, 40, 50, 100],
			layouts: [
				'Sizes',
				'PrevJump',
				'PrevPage',
				'Number',
				'NextPage',
				'NextJump',
				'FullJump',
				'Total'
			]
		},
		grid: {
			size: 'mini',
			formConfig: {
				className: 'el-form',
				vertical: true
			},
			columnConfig: {
				isHover: true,
				resizable: true,
				isCurrent: true
			},
			rowConfig: {
				isHover: true,
				isCurrent: true
			},
			toolbarConfig: {
				refresh: true,
				size: 'medium'
			},
			pagerConfig: {
				enabled: true,
				size: 'medium'
			},
			proxyConfig: {
				autoLoad: true,
				form: true,
				filter: true,
				props: {
					result: 'result.records',
					message: 'errorMessage',
					total: 'result.total'
				},
				message: true,
				beforeItem: null,
				beforeColumn: null,
				beforeQuery: null,
				afterQuery: null,
				beforeDelete: null,
				afterDelete: null,
				beforeSave: null,
				afterSave: null
			}
		},

		table: {
			// stripe: true,
			minHeight: 800,
			size: 'mini',
			round: true,
			autoResize: true,
			rowClassName: 'el-table__row',
			cellClassName: 'el-table__cell',
			filterConfig: {
				remote: true
			},
			syncResize: true,
			// columnConfig: {
			// 	minWidth: 100
			// },
			border: true,
			loading: false,
			showFooter: false,
			keepSource: true,
			height: '90%',
			rowConfig: {
				isHover: true
			},
			customConfig: {
				storage: true
			},
			tooltipConfig: {
				enterable: true
			},
			exportConfig: {
				modes: ['current', 'all'],
				types: ['csv', 'html', 'xml', 'txt']
			}
		},
		form: {
			preventSubmit: false,
			span: 3,
			size: 'small'
		},
		select: {
			multiCharOverflow: -1,
			clearable: true
		}
	})

	VXETable.renderer.add('$elInput', {
		renderItemContent(renderOpts, params) {
			const { data, field, item } = params
			const { attrs } = renderOpts

			return h(ElInput, {
				modelValue: data[field],
				'onUpdate:modelValue': (val: unknown) => (data[field] = val),
				placeholder:
					attrs?.placeholder ??
					i18n.global.t('table.InputPrefix', {
						field: t(item.title).toLowerCase()
					})
			})
		}
	})

	VXETable.renderer.add('$elSelect', {
		renderItemContent(renderOpts, params) {
			const { data, field } = params
			const { attrs, props, options } = renderOpts
			return h(
				ElSelectV2,
				{
					modelValue: data[field],
					'onUpdate:modelValue': (val: unknown) => (data[field] = val),
					collapseTags: true,
					clearable: true,
					collapseTagsTooltip: true,
					tagType: 'primary',
					options: options ?? [],
					...props,
					...attrs
				},
				!props?.noHeader
					? {
							header: () => {
								return h(ElCheckbox, {
									modelValue:
										data[field]?.length === options?.length || !data[field],
									'onUpdate:modelValue': (val) => {
										if (val) {
											data[field] = options?.map(
												(option: { value: unknown }) => option.value
											)
										} else {
											data[field] = []
										}
									},
									label: t('All')
								})
							}
						}
					: {}
			)
		}
	})

	VXETable.renderer.add('$spacer', {
		renderItemContent() {
			return h('div', { class: 'flex-grow' })
		}
	})

	VXETable.renderer.add('$elDateRange', {
		renderItemContent(renderOpts, params) {
			const { data, field } = params
			const { attrs, props } = renderOpts

			return h(ElDatePicker, {
				modelValue: data[field],
				type: 'datetimerange',
				valueFormat: 'YYYY-MM-DD HH:mm:ss',
				dateFormat: 'YYYY-MM-DD HH:mm:ss',
				timeFormat: 'HH:mm:ss',
				defaultTime: [
					new Date().setHours(0, 0, 0, 0),
					new Date().setHours(23, 59, 59, 59)
				] as any,
				startPlaceholder: t('Start Time'),
				endPlaceholder: t('End Time'),
				'onUpdate:modelValue': (val: unknown) => {
					data[field] = val

					if (val instanceof Array && props && props.startKey && props.endKey) {
						data[props.startKey] = val[0]
						data[props.endKey] = val[1]
					}
				},
				// placeholder:
				// 	attrs?.placeholder ??
				// 	t('table.SelectPrefix', {
				// 		field: t(item.title).toLowerCase()
				// 	}),
				props,
				...attrs
			})
		}
	})

	VXETable.formats.add('$optionFormatter', {
		cellFormatMethod({ cellValue, column: { filters } }, options = null, labelKey = 'label') {
			if (typeof cellValue === 'string' && cellValue.includes(',')) {
				const values = cellValue.split(',')
				const list: string[] = []

				values.forEach((listValue) => {
					list.push(
						(options || filters).find(
							(item: { value: unknown }) => item.value === listValue
						)?.[labelKey] || listValue
					)
				})
				return list
			} else {
				return (
					(options || filters).find(
						(item: { value: unknown }) => item.value === cellValue
					)?.[labelKey] || cellValue
				)
			}
		}
	})

	VXETable.formats.add('$timeFormatter', {
		cellFormatMethod({ cellValue }, _options = null, _labelKey = 'label') {
			return moment(cellValue).format('YYYY-MM-DD HH:mm:ss').toString()
		}
	})

	VXETable.renderer.add('$elTag', {
		renderDefault(renderOpts, params) {
			const { row, column } = params
			const { props, attrs } = renderOpts

			if (!row[column.field]) {
				return ''
			}

			const cellValue = row[column.field]
			let values =
				typeof cellValue === 'string' && cellValue.includes(',')
					? cellValue.split(',')
					: cellValue instanceof Array && cellValue.length > 1
						? [...cellValue]
						: [cellValue]
			values = values.filter((item) => item != '')
			const list: any[] = []

			const columnFormatter = column.formatter as Array<Record<any, any>>
			const columnOptions =
				(columnFormatter[1] as {
					value: any
					label: unknown
				}[]) || null

			values.forEach((listValue) => {
				const optionIndex = columnOptions.findIndex((item) => item.value === listValue)
				const tag = h(
					ElTag,
					{
						type:
							(props?.optionTagStyles instanceof Array
								? props?.optionTagStyles[optionIndex]
								: props?.optionTagStyles.find(
										(item: { value: any }) => item.value == listValue
									)) ||
							props?.type ||
							'primary',
						disableTransitions: true,
						...props,
						...attrs
					},
					{
						default: () => {
							if (columnOptions) {
								return columnOptions.find((item) => item.value == listValue)?.label
							}

							return row[column.field]
						}
					}
				)
				list.push(tag)
			})

			return h(
				'div',
				{
					className: 'flex gap-2',
					style:
						(column?.align === 'center'
							? 'justify-content: center;'
							: 'justify-content: start;') + 'flex-wrap: wrap;'
				},
				list
			)
		}
	})

	VXETable.renderer.add('$elText', {
		renderDefault(renderOpts, params) {
			const { row, column } = params
			const { props, attrs } = renderOpts

			const columnFormatter = toRaw(column.formatter as Array<Record<any, any>>)
			const columnOptions =
				(columnFormatter[1] as {
					value: any
					label: unknown
				}[]) || null

			const optionIndex = columnOptions.findIndex((item) => item.value === row[column.field])

			return h(
				ElText,
				{
					size: 'small',
					type:
						(props?.optionTagStyles instanceof Array
							? props?.optionTagStyles[optionIndex]
							: props?.optionTagStyles.find(
									(item: { value: any }) => item.value == row[column.field]
								)) ||
						props?.type ||
						'primary',
					...props,
					...attrs
				},
				{
					default: () => {
						if (columnOptions) {
							return columnOptions.find((item) => item.value == row[column.field])
								?.label
						}

						return row[column.field]
					}
				}
			)
		}
	})

	app.use(Filter)
		.use(Column)
		.use(Edit)
		.use(Icon)
		.use(Table)
		.use(Pager)
		.use(Grid)
		.use(Select)
		.use(Form)
		.use(Button)
		.use(Input)
		.use(Option)
		.use(Tooltip)
		.use(Modal)
		.use(Toolbar)
		.use(Export)

	VXETable.use(VXETablePluginElement)
	VXETable.use(VXETablePluginExportXLSX, {
		ExcelJS
	})
}

// function dataTypeFormatter(val: unknown, dataType: unknown = null, separator: string = ','): any {
// 	if (dataType && val) {
// 		if (dataType === 'number') {
// 			return val ? Number(val) : null
// 		}

// 		if (dataType === 'string') {
// 			if (val instanceof Object) {
// 				return Object.values(val).join(separator)
// 			} else if (val instanceof Array) {
// 				return val.join(separator)
// 			} else {
// 				return val ? String(val) : null
// 			}
// 		}

// 		if (dataType === 'array') {
// 			return val ? String(val).split(separator) : []
// 		}
// 	} else {
// 		return val
// 	}
// }

export { useVxeTable, VXETable }
