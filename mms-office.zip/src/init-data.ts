import { useCommonStore } from '@/stores'

export default function initData() {
	const commonStore = useCommonStore()
	commonStore.fetchPlatforms()
}
