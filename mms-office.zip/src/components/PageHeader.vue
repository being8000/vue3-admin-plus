<template>
	<div class="flex items-center gap-2 mb-2">
		<el-link
			:underline="false"
			type="primary"
			size="large"
			@click="$router.back()"
			v-if="$route.meta.back">
			<el-icon :size="20"><icon-tabler-arrow-left /></el-icon>
		</el-link>
		<h3 class="my-0">
			{{ $t(pageTitle) }}
		</h3>
		<small class="gap-2 flex" v-if="$route.meta.showTag || $route.params[tagKey]">
			<el-tag>{{ $route.params[tagKey] }}</el-tag>
		</small>
	</div>
</template>

<script lang="ts" setup name="PageHeader">
import { AppRouteRecordRaw } from '@/router/MainRoutes'

const route = useRoute() as AppRouteRecordRaw

const pageTitle = computed(() => route.meta.title || '')
const tagKey = computed(() => route.meta.tagKey || 'id')
</script>
