<template>
	<div class="section-header">
		<h4 class="my-3">{{ title }}</h4>
		<slot name="right"></slot>
	</div>
</template>

<script setup lang="ts" name="SectionHeader">
defineProps({
	title: {
		type: String,
		required: true
	}
})
</script>

<style scoped>
.section-header {
	display: flex;
	align-items: center;
	justify-content: space-between;
}
</style>
