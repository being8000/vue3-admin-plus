import { AuditStatus, Product } from '~/types'
import { Proposal } from '../types'
import { VxeGridPropTypes } from 'vxe-table'
import { ElMessage } from 'element-plus'

const productList = mapEnumToOptions(Product, { encloseValue: true })
const commonStore = useCommonStore()

export const formConfig: VxeGridPropTypes.FormConfig = {
	items: [
		{
			field: 'product',
			title: 'table.Product',
			itemRender: {
				name: '$elSelect',
				options: productList,
				props: {
					multiple: true,
					maxCollapseTags: 2
				}
			},
			span: 5
		},
		{
			field: 'voucherName',
			title: 'table.VoucherName',
			itemRender: { name: '$elInput' }
		},
		{
			field: 'account',
			title: 'table.Account',
			itemRender: { name: '$elInput' }
		},
		{
			field: 'creator',
			title: 'table.CreatedBy',
			itemRender: { name: '$elInput' }
		},
		{
			field: 'createTime',
			title: 'table.CreateTime',
			itemRender: {
				name: '$elDateRange',
				props: { startKey: 'createTimeFrom', endKey: 'createTimeTo' }
			},
			span: 5
		},
		{
			field: 'auditTime',
			title: 'table.AuditTime',
			itemRender: {
				name: '$elDateRange',
				props: { startKey: 'auditTimeFrom', endKey: 'auditTimeTo' }
			},
			span: 5
		},
		{
			field: 'activityId',
			title: 'table.EventName',
			itemRender: {
				name: '$elSelect',
				options: commonStore.activityList,
				props: {
					noHeader: true,
					filterable: true
				}
			},
			span: 4
		},

		{
			field: 'auditStatus',
			title: 'table.AuditStatus',
			itemRender: {
				name: '$elSelect',
				options: mapEnumToOptions(AuditStatus),
				props: {
					multiple: true,
					maxCollapseTags: 3
				}
			},
			span: 4
		},
		{
			title: ' ',
			align: 'center',
			itemRender: {
				name: '$buttons',
				children: [
					{
						props: {
							type: 'submit',
							content: 'table.Search',
							status: 'primary',
							icon: 'vxe-icon-search'
						}
					},
					{ props: { type: 'reset', content: 'table.Reset' } }
				]
			}
		}
	]
}

export const columns: VxeGridPropTypes.Columns<Proposal> = [
	// { type: 'checkbox', width: 60, align: 'center' }, TODO - ASAP implement multiple audit
	{ field: 'proposalId', title: 'ID', width: 150, align: 'center' },
	{
		field: 'tenant',
		title: 'table.Product',
		formatter: ['$optionFormatter', mapEnumToOptions(Product, {}, undefined, true)],
		cellRender: {
			name: '$elTag',
			props: {
				optionTagStyles: ['', 'warning', 'success', 'danger']
			}
		},
		width: 180
	},
	{ field: 'activityName', title: 'table.VoucherName', width: 120 },
	{ field: 'bornCredit', title: 'table.Amount' },
	{ field: 'loginName', title: 'table.Account' },
	{ field: 'creator', title: 'table.CreatedBy' },
	{ field: 'createTime', title: 'table.CreateTime' },
	{ field: 'auditor', title: 'table.Auditor' },
	{ field: 'auditTime', title: 'table.AuditTime' },
	{
		field: 'auditStatus',
		title: 'table.AuditStatus',
		align: 'center',
		formatter: ['$optionFormatter', mapEnumToOptions(AuditStatus)],
		cellRender: {
			name: '$elTag',
			props: {
				optionTagStyles: ['warning', 'success', 'danger']
			}
		}
	},
	{
		field: 'operations',
		title: 'table.Operations',
		align: 'center',
		fixed: 'right',
		width: 220,
		cellRender: {
			name: '$buttons',
			children: [
				{
					props: {
						content: 'table.Approve',
						status: 'success',
						icon: 'vxe-icon-check',
						size: 'mini'
					},
					events: {
						click: ({ row }: { row: Proposal }) => {
							handleApproveReject(row, AuditStatus.APPROVED, 'Approve')
						}
					}
				},
				{
					props: {
						type: 'button',
						content: 'table.Reject',
						status: 'danger',
						icon: 'vxe-icon-close',
						size: 'mini'
					},
					events: {
						click: ({ row }: { row: Proposal }) => {
							handleApproveReject(row, AuditStatus.REJECTED, 'Reject')
						}
					}
				}
			]
		}
	}
]

const handleApproveReject = (row: Proposal, auditStatus: AuditStatus, type: string) => {
	const payload = {
		activityId: row.activityId,
		auditStatus,
		proposalIdList: [row.proposalId]
	}

	ElMessageBox.confirm(
		i18n.global.t('ConfirmMessage', {
			type: i18n.global.t('table.' + type).toLowerCase()
		}),
		i18n.global.t('Please confirm'),
		{
			confirmButtonText: i18n.global.t('Confirm'),
			cancelButtonText: i18n.global.t('Cancel'),
			type: 'warning',
			confirmButtonClass: 'el-button--success'
		}
	).then(() => {
		service.post('/proposal/audit', payload).then(() => {
			row.auditStatus = auditStatus

			ElMessage.success(
				'Proposal status updated: ' + i18n.global.t('table.' + type).toLowerCase()
			)
		})
	})
}
