<template>
	<vxe-grid v-bind="gridOptions" ref="xGrid">
		<template #menu_buttons>
			<el-tooltip
				:disabled="xGrid?.reactData.formData.activityId"
				content="Please query an event name above first">
				<vxe-button
					:disabled="!xGrid?.reactData.formData.activityId"
					size="mini"
					@click="() => handleBulkApprovalReject(AuditStatus.APPROVED, 'Approve')"
					icon="vxe-icon-check"
					status="success"
					class="el-button--plain">
					{{ $t('Bulk Approve') }}
				</vxe-button>
			</el-tooltip>

			<vxe-button
				:disabled="!xGrid?.reactData.formData.activityId"
				size="mini"
				@click="() => handleBulkApprovalReject(AuditStatus.REJECTED, 'Reject')"
				icon="vxe-icon-close"
				status="danger">
				{{ $t('Reject all') }}
			</vxe-button>

			<!-- <el-tooltip
				size="small"
				:disabled="xGrid?.reactData.formData.activityId"
				content=""> -->
			<!-- <el-icon class="ml-2 mr-1" style="color: var(--el-color-info)">
				<icon-ep-question-filled />
			</el-icon> -->
			<el-text size="small" tag="i" class="mx-2 text-gray">
				Bulk review will update all records with pending status
			</el-text>

			<!-- </el-tooltip> -->
		</template>

		<template #tools_buttons>
			<vxe-button
				circle
				@click="handleDownload"
				:loading="isDownloading"
				icon="vxe-icon-download"></vxe-button>
		</template>

		<!-- <template #operations="{ row, $rowIndex }">
			<template v-for="(button, key) in operationButtons">
				<vxe-button
					v-if="button.show ? button.show(row) : true"
					:key="'operation-' + $rowIndex + '-' + key"
					:icon="button.icon"
					:content="button.content"
					:size="button.size"
					:status="button.status"
					:style="{ width: button.width || 'auto' }"
					@click="
						button.onClick ? button.onClick(row, $rowIndex) : undefined
					"></vxe-button>
			</template>
		</template> -->
	</vxe-grid>
</template>

<script setup lang="ts" name="Proposals">
import type { Proposal } from '@/views/event-management/types'
import { columns, formConfig } from './options'
import { AuditStatus } from '~/types'
import { Activity } from '../events/types'
import { VxeGridInstance } from 'vxe-table'

const xGrid = ref<VxeGridInstance<Activity>>()
const isDownloading = ref(false)
const commonStore = useCommonStore()

const handleDownload = () => {
	isDownloading.value = true
	const data = {
		...cleanQuery(xGrid.value?.reactData.formData),
		...omit(xGrid.value?.reactData.tablePage, ['total'])
	}

	return service({
		url: `/proposal/export`,
		method: 'post',
		data,
		timeout: 1000 * 60 * 30,
		responseType: 'blob'
	})
		.then(() => {
			ElMessage.success('Export successful')
		})
		.finally(() => {
			isDownloading.value = false
		})
}

const gridOptions = reactive<VxeGridProps<Proposal>>({
	border: true,
	loading: false,
	showFooter: false,
	columns,
	formConfig,
	keepSource: true,
	align: 'center',
	filterConfig: {
		remote: true
	},
	pagerConfig: {
		enabled: true
	},
	toolbarConfig: {
		export: false,
		enabled: true,
		slots: {
			buttons: 'menu_buttons',
			tools: 'tools_buttons'
		}
	},

	// exportConfig: {
	// 	modes: ['all', 'current', 'selected'],
	// 	types: ['xlsx', 'csv'],
	// 	message: true,
	// 	remote: true,
	// 	exportMethod({ $grid }) {
	// 		const data = {
	// 			...cleanQuery($grid?.reactData.formData),
	// 			...omit($grid?.reactData.tablePage, ['total'])
	// 		}

	// 		return service({
	// 			url: `/proposal/export`,
	// 			method: 'post',
	// 			data,
	// 			timeout: 1000 * 60 * 30,
	// 			responseType: 'blob'
	// 		})
	// 	},
	// 	afterExportMethod() {
	// 		ElMessage.success('Download success')
	// 	}
	// },
	proxyConfig: {
		enabled: true,
		ajax: {
			query: async ({ page, form, filters, sorts }) => {
				console.log('form --->', form)
				console.log('filters--->', filters)
				console.log('sorts--->', sorts)

				const payload = {
					current: page.currentPage,
					size: page.pageSize,
					...cleanQuery(form)
				}

				const response = await service.post('/proposal/queryProposalList', payload)

				return response
			}
		}
	}
})

const handleBulkApprovalReject = (auditStatus: AuditStatus, type: string) => {
	const payload = {
		...xGrid.value?.reactData.formData,
		auditStatus
	}

	ElMessageBox.confirm(
		i18n.global.t('ConfirmMessageAll', {
			type: i18n.global.t('table.' + type).toLowerCase()
		}),
		i18n.global.t('Please confirm'),
		{
			confirmButtonText: i18n.global.t('Confirm'),
			cancelButtonText: i18n.global.t('Cancel'),
			type: 'warning',
			confirmButtonClass: 'el-button--success'
		}
	).then(() => {
		service.post('/proposal/oneKeyAuditProposal', payload).then(() => {
			xGrid.value?.commitProxy('refresh')
		})
	})
}

onMounted(() => {
	commonStore.fetchActivity()
})
</script>
