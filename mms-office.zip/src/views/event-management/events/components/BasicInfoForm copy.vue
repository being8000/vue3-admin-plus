<template>
	<section>
		<section-header class="section-header" title="Basic Information" />
		<el-card class="mb-3" shadow="never">
			<el-form label-width="auto" :model="basicInfoForm">
				<el-form-item label="Event Name">
					<el-input v-model="basicInfoForm.name" />
				</el-form-item>

				<el-form-item label="Event Name">
					<el-date-picker
						type="datetimerange"
						v-model="basicInfoForm.time"
						start-placeholder="Start date"
						end-placeholder="End date" />
				</el-form-item>

				<el-form-item label="Product">
					<el-select-v2
						v-model="basicInfoForm.product"
						:options="mapEnumToOptions(Product)" />
				</el-form-item>

				<el-form-item label="Description">
					<el-input type="textarea" v-model="basicInfoForm.description" />
				</el-form-item>
			</el-form>
		</el-card>
	</section>
</template>

<script setup lang="ts" name="BasicInfoForm">
import { Product } from '~/types'
import { mapEnumToOptions } from '@/composables/use-helpers'

const basicInfoForm = ref({
	name: '',
	time: '',
	product: '',
	description: ''
})
</script>
