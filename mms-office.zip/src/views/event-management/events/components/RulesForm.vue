<template>
	<section>
		<section-header class="section-header" title="Rules" />
		<el-card class="mb-3" shadow="never">
			<el-form-item label="Budget" class="w-100">
				<!-- <el-col :span="6">
						<el-select v-model="modelValue.creditConfigListReq[0].rightsType" disabled>
							<el-option label="Bet" value="Bet" />
						</el-select>
					</el-col> -->
				<el-input-number
					style="width: unset"
					class="w-full flex-1"
					v-if="modelValue.creditConfigListReq"
					v-model="modelValue.creditConfigListReq![0].rightsCredit"
					:min="0"
					:max="10000000000"
					:step="1000"
					:value-on-clear="null"
					:precision="2"
					:placeholder="$t('table.InputPrefix', { field: $t('Budget').toLowerCase() })"
					controls-position="right" />
			</el-form-item>

			<el-form-item label="Game Platforms" prop="gamePlatformList" class="mt-6">
				<el-select-v2
					v-model="modelValue.platformIdList_temp"
					:empty-values="[null, undefined]"
					:value-on-clear="() => undefined"
					collapse-tags
					collapse-tags-tooltip
					filterable
					multiple
					tag-type="warning"
					:max-collapse-tags="6"
					:options="commonStore.platforms"
					@update:model-value="
						(val: string[]) => {
							// if (modelValue.activityId) {
							// 	const platforms = commonStore.platforms?.filter((item) =>
							// 		val?.includes(item.value as any)
							// 	)

							// 	modelValue.platformIdList = platforms.map((platform) => ({
							// 		platformId: platform.value
							// 	}))
							// } else {
							modelValue.platformIdList = val
							// }
						}
					"
					clearable />
			</el-form-item>
		</el-card>
	</section>
</template>

<script setup lang="ts" name="VoucherRulesForm">
import { ActivityDetails } from '@/views/event-management/events/types'

const modelValue = defineModel<Partial<ActivityDetails>>({ required: true })
const commonStore = useCommonStore()
</script>

<style lang="scss" scoped>
.voucher-types-container {
	.el-radio.w-full {
		margin: 0;

		.el-row {
			.el-col:last-child.is-guttered {
				padding-right: 0 !important;
			}
		}
	}

	:deep(.el-radio__label) {
		width: 100%;
	}
}
</style>
