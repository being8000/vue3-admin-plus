<template>
	<section>
		<section-header class="section-header" title="Basic Information" />
		<el-card class="mb-3" shadow="never">
			<el-form-item :label="$t('Activity Name')" prop="activityName">
				<el-input v-model="modelValue.activityName" />
			</el-form-item>

			<el-form-item :label="$t('Activity Time')" prop="activityTime" style="max-width: 600px">
				<el-date-picker
					type="datetimerange"
					v-model="modelValue.activityTime"
					@update:model-value="
						(val) => {
							modelValue.startTime = val[0]
							modelValue.endTime = val[1]
						}
					"
					value-format="YYYY-MM-DD HH:mm:ss"
					end-placeholder="End time"
					start-placeholder="Start time"
					:default-time="
						[
							new Date().setHours(0, 0, 0, 0),
							new Date().setHours(23, 59, 59, 59)
						] as any
					"
					:onUpdate:modelValue="
						(val: any) => {
							modelValue.endTime = val[1]
							modelValue.startTime = val[0]
						}
					"
					placeholder="Select date" />
			</el-form-item>

			<el-form-item label="Product" prop="tenantList">
				<el-select-v2
					:empty-values="[undefined, null]"
					tag-type="primary"
					v-model="modelValue.tenantList"
					@update:model-value="
						(val: Product[]) => {
							modelValue.tenantList = val
						}
					"
					:value-on-clear="() => undefined"
					multiple
					clearable
					filterable
					:options="commonStore.products">
					<template #header>
						<el-checkbox
							:modelValue="
								modelValue.tenantList?.length === products?.length ||
								!modelValue.tenantList
							"
							@update:model-value="
								(val) => {
									if (val) {
										modelValue.tenantList = products?.map(({ value }) => value)
									} else {
										modelValue.tenantList = []
									}
								}
							">
							{{ $t('All') }}
						</el-checkbox>
					</template>
				</el-select-v2>
			</el-form-item>

			<el-form-item label="Description">
				<el-input
					type="textarea"
					v-model="modelValue.activityDesc"
					show-word-limit
					:maxlength="200" />
			</el-form-item>
		</el-card>
	</section>
</template>

<script setup lang="ts" name="BasicInfoForm">
import { Product } from '~/types'
import { ActivityDetails } from '@/views/event-management/events/types'
import { mapEnumToOptions } from '@/composables/use-helpers'

const modelValue = defineModel<Partial<ActivityDetails>>({ required: true })
const products = mapEnumToOptions(Product)
const commonStore = useCommonStore()

// const handleOnUpdateProductList = (val: any) => {
// 	if (val) {
// 		modelValue.value.tenantList = products?.map((option: { value: Product }) => option.value)
// 	} else {
// 		modelValue.value.tenantList = undefined
// 	}

// 	return !val
// }
</script>
