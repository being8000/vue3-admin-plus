<template>
	<section>
		<section-header class="section-header" title="Scene Selection">
			<template #right>
				<el-button circle type="info" plain @click="addScene">
					<icon-tabler-plus />
				</el-button>
			</template>
		</section-header>

		<el-form
			v-for="(scene, index) in modelValue.sceneList"
			:model="scene"
			:rules="rules"
			label-width="200"
			:key="'form-scene-' + scene.sceneId">
			<el-card class="mb-3" shadow="never">
				<template #header>
					<el-button
						class="float-right"
						circle
						type="danger"
						text
						@click="confirmSceneDelete(index)">
						<icon-tabler-trash />
					</el-button>

					<!-- TODO on 2nd phase 
						<el-radio-group label="Mode" v-model="scene.mode">
							<el-radio :value="SceneMode.UPLOAD">File upload</el-radio>
							<el-radio :value="SceneMode.AUDIENCE">Audience Selection</el-radio>
						</el-radio-group>
					-->

					<!-- TODO on 2nd phase - move this below header -->
					<el-form-item prop="senderTimesLimit" class="m-0!" label-class="items-center">
						<template #label>
							<div class="flex items-center">
								<span class="pr-1">{{ $t('Deduplication') }}</span>
								<el-tooltip placement="bottom" :content="$t('DeduplicationInfo')">
									<el-icon style="color: var(--el-color-info)">
										<icon-ep-question-filled />
									</el-icon>
								</el-tooltip>
							</div>
						</template>
						<el-radio-group v-model="scene.senderTimesLimit">
							<el-radio :value="DedupeMode.YES" label="Yes" />
							<el-radio :value="DedupeMode.NO" label="No" />
						</el-radio-group>
					</el-form-item>
				</template>

				<el-form-item label="Upload" class="w-full">
					<el-upload
						class="flex w-full absolute"
						:headers="requestHeaders"
						ref="upload"
						:limit="1"
						accept=".xlsx"
						:on-exceed="handleExceed"
						with-credentials
						@error="handleUploadError"
						:action="`${baseUploadUrl}/crowd/upload`"
						@success="
							(response) =>
								onUploadSuccess(response, scene.sceneId, modelValue.activityId)
						">
						<template #trigger>
							<el-button
								plain
								type="info"
								:icon="UploadFilled"
								:disabled="
									!(
										modelValue.efficientStatus === ActivityStatus.NORMAL &&
										modelValue.auditStatus === AuditStatus.APPROVED
									)
								">
								Browse File
							</el-button>
						</template>
					</el-upload>

					<!-- FOR UPLOAD TESTING 
						<el-button
							:disabled="
								!(
									modelValue.efficientStatus === ActivityStatus.NORMAL &&
									modelValue.auditStatus === AuditStatus.APPROVED
								)
							"
							@click="
								onUploadSuccess(null, '1783062947046686720', '1783062946069413889')
							">
							Test Start
						</el-button>
						<el-button
							:disabled="
								!(
									modelValue.efficientStatus === ActivityStatus.NORMAL &&
									modelValue.auditStatus === AuditStatus.APPROVED
								)
							"
							@click="checkUploadStatus('validateTask-1783740068306853888')">
							Check status
						</el-button>
						-->
				</el-form-item>

				<!-- TODO on 2nd phase 
					<el-form-item class="form-item-animated-container">
						<transition name="slide-up">
							<el-form-item
								v-if="scene.mode == SceneMode.UPLOAD"
								label="Upload"
								class="w-full">
								<el-upload
									class="flex w-full absolute"
									ref="upload"
									:limit="1"
									:on-exceed="handleExceed"
									:auto-upload="false">
									<template #trigger>
										<el-button plain type="info" :icon="UploadFilled">
											Browse File
										</el-button>
									</template>
								</el-upload>
							</el-form-item>

							<el-form-item v-else label="Target Audience" class="w-full absolute">
								<el-select-v2
									v-model="scene.auditWay"
									:options="[{ value: 'All', label: 'All' }]" />
							</el-form-item>
						</transition>
					</el-form-item>
				-->

				<!-- @update:model-value="
							(val) => {
								scene.sceneRightsRelationList?.push(val)
							}
						" -->

				<el-form-item
					prop=""
					:label="modelValue.activityId ? 'Linked' : 'Link' + ' Vouchers'">
					<el-select-v2
						:options="vouchersList || []"
						v-model="scene.sceneRightsRelationList_temp"
						@update:model-value="
							(val: string[]) => {
								const voucher = vouchersList?.filter((item: RightsConfigList) =>
									val.includes(item.rightsConfigId as string)
								)

								scene.sceneRightsRelationList = voucher
							}
						"
						:props="{
							value: 'rightsConfigId',
							label: 'rightsConfigName'
						}"
						filterable
						multiple
						clearable
						collapse-tags
						collapse-tags-tooltip
						:max-collapse-tags="5"></el-select-v2>
				</el-form-item>

				<el-form-item label="Notification Channel">
					<el-col :span="14" class="p-0!">
						<el-radio-group v-model="scene.notifyChannel">
							<el-radio value="" label="None" />
							<el-radio
								:disabled="(modelValue.tenantList?.length || 0) > 1"
								v-for="channel in mapEnumToOptions(
									NotificationChannel,
									null,
									false
								)"
								:value="channel.value"
								:label="channel.label" />
						</el-radio-group>
					</el-col>
					<el-col :span="10">
						<el-button
							v-if="(modelValue.tenantList?.length || 0) <= 1 && scene.notifyChannel"
							size="small"
							text
							type="info"
							:underline="false"
							@click="openEditMessage(scene)">
							Edit Message
						</el-button>
					</el-col>
				</el-form-item>

				<el-form-item prop="notifyWay" label="Timing of Distribution">
					<el-radio-group v-model="scene.notifyWay">
						<el-radio
							v-for="channel in mapEnumToOptions(DistributionTiming)"
							:value="channel.value"
							:label="channel.label" />
					</el-radio-group>
				</el-form-item>

				<el-form-item
					prop="notifyTime"
					v-if="scene.notifyWay === DistributionTiming.FIXED"
					:required="scene.notifyWay === DistributionTiming.FIXED"
					label="Distribution Time">
					<el-date-picker
						type="datetime"
						v-model="scene.notifyTime"
						placeholder="Choose Time" />
				</el-form-item>

				<el-form-item prop="receiveWay" label="Distribution Method">
					<el-radio-group v-model="scene.receiveWay">
						<el-radio
							v-for="channel in mapEnumToOptions(DistributionMethod)"
							:value="channel.value"
							:label="channel.label" />
					</el-radio-group>
				</el-form-item>
			</el-card>
		</el-form>
	</section>

	<el-dialog
		v-model="uploadStatusDialog"
		title="Target Group"
		width="500"
		destroy-on-close
		@closed="onCloseUploadDialog"
		:close-on-click-modal="false"
		:close-on-press-escape="false">
		<el-form label-width="200px" label-position="left" :loading="isValidating">
			<section-header title="Validation Result" />
			<el-card shadow="never">
				<el-form-item
					class="mb-2!"
					v-for="(validationResult, resultKey) in pick(targetGroupData.summaryDto, [
						'total',
						'failed',
						'succeed'
					])"
					:label="summaryDtoLabels[resultKey]"
					v-key="'validationResult' + resultKey"
					:class="{
						'text-danger': resultKey === 'failed' && (validationResult || 0) > 0
					}">
					{{ validationResult }}
				</el-form-item>
			</el-card>

			<section-header title="Details">
				<template #right>
					<el-link
						type="info"
						:icon="Download"
						:underline="false"
						:loading="isDownloading"
						@click="handleDownload">
						<span class="pl-1">Download</span>
					</el-link>
				</template>
			</section-header>
			<el-card shadow="never">
				<el-form-item
					class="mb-2!"
					v-for="(summary, summaryKey) in omit(targetGroupData.summaryDto, [
						'total',
						'failed',
						'succeed'
					])"
					:label="summaryDtoLabels[summaryKey]"
					v-key="'summary' + summaryKey">
					{{ summary }}
				</el-form-item>
			</el-card>
		</el-form>

		<template #footer>
			<div class="mb-2">
				<!-- <el-text
					size="small"
					v-if="
						targetGroupData.crowdValidateTaskStatus !==
						CrowdValidateTaskStatus.FINISH_SUCCESS
					"
					type="warning">
					Please re-validate
				</el-text> -->
				<el-text
					size="small"
					type="warning"
					v-if="(targetGroupData.summaryDto?.succeed || 0) < 1 && !isValidating">
					There are no successful result. Please close this and upload again
				</el-text>
			</div>

			<!-- <el-button class="float-left" @click="() => checkUploadStatus()">Re-validate</el-button> -->

			<el-button @click="uploadStatusDialog = false">
				{{
					targetGroupData.crowdValidateTaskStatus ===
					CrowdValidateTaskStatus.FINISH_SUCCESS
						? 'Close'
						: 'Cancel'
				}}
			</el-button>
			<el-button
				:disabled="
					!(
						targetGroupData.crowdValidateTaskStatus ===
							CrowdValidateTaskStatus.FINISH_SUCCESS &&
						(targetGroupData.summaryDto?.succeed || 0) > 0
					)
				"
				type="success"
				@click="submitUpload"
				:loading="isValidating">
				{{ isValidating ? 'Validating' : 'Submit' }}
			</el-button>
		</template>
	</el-dialog>
</template>

<script setup lang="ts" name="SceneSelectionForm">
import { Download } from '@element-plus/icons-vue'
import { ElInput, ElMessage, genFileId } from 'element-plus'
import type { FormRules, UploadInstance, UploadProps, UploadRawFile } from 'element-plus'
import { UploadFilled } from '@element-plus/icons-vue'
import SectionHeader from '@/components/SectionHeader.vue'
import { mapEnumToOptions } from '@/composables/use-helpers'
import {
	ActivityDetails,
	Scene,
	ActivityStatus,
	SceneVO,
	DedupeMode,
	DistributionTiming,
	DistributionMethod,
	NotificationChannel,
	RightsConfigList
} from '@/views/event-management/events/types'
import { AuditStatus } from '~/types'
import { MktBaseResponse } from '@/utils/request'
import { pick, omit } from 'lodash'

const modelValue = defineModel<Partial<ActivityDetails>>({
	required: true
})

const summaryDtoLabels: Record<string, string> = {
	validAccount: 'Valid Account',
	duplicateAccount: 'Duplicate Account',
	invalidAccount: 'Invalid Account',
	blackList: 'Black List',
	duplicateClaim: 'Duplicate Claim',
	total: 'Total',
	succeed: 'Succeeded',
	failed: 'Failed'
}

const requestHeaders = computed(() => {
	return {
		Authorization: 'Bearer ' + localStorage.getItem('OMS_TOKEN')
	}
})

const upload = ref<UploadInstance>()
const activeTask = ref({
	validateTaskId: undefined,
	activityId: undefined,
	sceneId: undefined,
	validateFilePath: undefined
})
const rules = reactive<FormRules<ActivityDetails & Scene>>({
	senderTimesLimit: [{ required: true, message: 'Please select' }],
	notifyWay: [{ required: true, message: 'Please select' }],
	receiveWay: [{ required: true, message: 'Please select' }]
})

const baseUploadUrl = service.defaults.baseURL

const handleExceed: UploadProps['onExceed'] = (files) => {
	if (upload.value) {
		/** @ts-ignore */
		upload.value[0]!.clearFiles()
		const file = files[0] as UploadRawFile
		file.uid = genFileId()
		/** @ts-ignore */
		upload.value[0]!.handleStart(file)
		/** @ts-ignore */
		upload.value[0]!.submit()
	}
}

const submitUpload = async () => {
	const { success } = (await service.post('/proposal/create', {
		...targetGroupData.value,
		...activeTask.value
	})) as MktBaseResponse

	if (success) {
		activeTask.value = {
			validateTaskId: undefined,
			activityId: undefined,
			sceneId: undefined,
			validateFilePath: undefined
		}
		ElMessage.success('Successfully submitted')
	}
}

watch(
	() => modelValue.value.tenantList,
	(tenantList) => {
		if (tenantList && tenantList.length > 1) {
			modelValue.value.sceneList?.forEach((scene) => (scene.notifyChannel = ''))
		}
	},
	{
		immediate: true
	}
)

const confirmSceneDelete = (index: number) => {
	ElMessageBox.confirm('Are you sure you want to delete this scene?', 'Confirm', {
		type: 'warning',
		confirmButtonText: 'Delete',
		confirmButtonClass: 'el-button--danger'
	}).then(() => {
		if (modelValue.value.sceneList && modelValue.value.sceneList[index]) {
			modelValue.value.sceneList.splice(index, 1)
		}

		ElMessage.success('Deleted scene')
	})
}

const openEditMessage = (scene: Scene) => {
	const originalMessage = scene.notifyTemplateContent

	ElMessageBox.confirm(
		() =>
			h('div', null, [
				h('p', 'Please enter the template content'),
				h(ElInput, {
					type: 'textarea',
					class: 'mt-2',
					modelValue: scene.notifyTemplateContent,
					'onUpdate:modelValue': (val: string) => {
						scene.notifyTemplateContent = val
					},
					maxlength: 140,
					showWordLimit: true
				})
			]),
		'Edit Message',
		{
			cancelButtonText: 'Cancel',
			confirmButtonText: 'Save',
			customClass: 'message-box-edit',
			inputValidator: (val) => {
				if (!val && originalMessage !== val) {
					return 'Message is required'
				}
				if (val && val.length > 140) {
					return 'Content should not exceed 140 characters in l'
				}
				return true
			},
			beforeClose: (action, _instance, done) => {
				if (
					action !== 'confirm' &&
					scene.notifyTemplateContent &&
					originalMessage !== scene.notifyTemplateContent
				) {
					return ElMessageBox.confirm(
						'Are you sure you want to close? Changes will not be saved',
						'Confirm',
						{
							buttonSize: 'small',
							type: 'warning',
							confirmButtonClass: 'el-button--danger'
						}
					)
						.then(() => {
							scene.notifyTemplateContent = originalMessage
							return done()
						})
						.catch(() => {
							return false
						})
				}
				done()
			}
		}
	)
}

const addScene = () => {
	modelValue.value.sceneList?.push(new SceneVO({}))
}
enum CrowdValidateTaskStatus {
	NOT_STARTED = 'notStarted',
	VALIDATING = 'validating',
	FINISH_SUCCESS = 'finishSuccess',
	FINISH_FAILURE = 'finishFailure',
	SUBMIT_SUCCESS = 'submitSuccess',
	SUBMIT_FAILURE = 'submitFailure'
}

const uploadStatusDialog = ref(false)

let intervalQuery: string | number | NodeJS.Timeout | undefined
const isValidating = ref<boolean>(false)

const onUploadSuccess = async (response: any, sceneId: any, activityId: any) => {
	if (!response.success) {
		ElMessage.error(
			response.errMessage ||
				'Something went wrong uploading the file. Please contact administrator'
		)
		return
	}

	uploadStatusDialog.value = true

	console.log('onUploadSuccess ---->', response)

	const { validateTaskId, validateFilePath } = response.result

	const payload = {
		validateTaskId,
		validateFilePath,
		activityId,
		sceneId
	}

	activeTask.value = payload

	targetGroupData.value = {
		...payload
	}

	isValidating.value = true

	const { success: validateSuccess } = (await service.post(
		'/crowd/validate',
		payload
	)) as MktBaseResponse

	if (validateSuccess) {
		checkUploadStatus()
		intervalQuery = setInterval(checkUploadStatus, 5000)
	}
}

class TargetGroupSummary {
	crowdValidateTaskStatus?: CrowdValidateTaskStatus
	activityId?: string
	validateTaskId?: string
	validateFilePath?: string
	sceneId?: string
	summaryDto: {
		validAccount: number
		duplicateAccount: number
		invalidAccount: number
		blackList: number
		duplicateClaim: number
		total: number
		succeed: number
		failed: number
	}

	constructor(targetGroup: Record<any, any>) {
		this.crowdValidateTaskStatus = targetGroup.crowdValidateTaskStatus
		this.activityId = targetGroup.activityId
		this.validateTaskId = targetGroup.validateTaskId
		this.validateFilePath = targetGroup.validateFilePath
		this.sceneId = targetGroup.sceneId
		this.summaryDto = {
			validAccount: targetGroup.summaryDto?.validAccount || 0,
			duplicateAccount: targetGroup.summaryDto?.duplicateAccount || 0,
			invalidAccount: targetGroup.summaryDto?.invalidAccount || 0,
			blackList: targetGroup.summaryDto?.blackList || 0,
			duplicateClaim: targetGroup.summaryDto?.duplicateClaim || 0,
			total: targetGroup.summaryDto?.total || 0,
			succeed: targetGroup.summaryDto?.succeed || 0,
			failed: targetGroup.summaryDto?.failed || 0
		}
	}
}

const targetGroupData = ref<Partial<TargetGroupSummary>>(new TargetGroupSummary({}))

const checkUploadStatus = async () => {
	const { success, result } = (await service.get('/crowd/queryValidateResult', {
		params: {
			validateTaskId: activeTask.value.validateTaskId
		}
	})) as MktBaseResponse

	if (
		result.crowdValidateTaskStatus === CrowdValidateTaskStatus.FINISH_SUCCESS ||
		result.crowdValidateTaskStatus.FINISH_FAILURE
	) {
		isValidating.value = false
		clearInterval(intervalQuery)
	}

	if (success && result.crowdValidateTaskStatus !== CrowdValidateTaskStatus.NOT_STARTED) {
		targetGroupData.value = new TargetGroupSummary({ ...result, ...activeTask.value })
	} else {
		targetGroupData.value = new TargetGroupSummary({ ...activeTask.value })
	}
}

const isDownloading = ref<boolean>(false)

const handleDownload = () => {
	isDownloading.value = true
	const data = {
		validateTaskId: activeTask.value.validateTaskId
	}

	return service({
		url: `/crowd/downloadDetail`,
		method: 'post',
		data,
		timeout: 1000 * 60 * 30,
		responseType: 'blob'
	})
		.then(() => {
			ElMessage.success('Export successful')
		})
		.finally(() => {
			isDownloading.value = false
		})
}

const handleUploadError = (_error: Error) => {
	ElMessage.error(
		'Upload failed. Please try again. If error persists, please contact administrator'
	)
}

const onCloseUploadDialog = () => {
	targetGroupData.value = new TargetGroupSummary({})
	clearInterval(intervalQuery)
}

const vouchersList = inject<RightsConfigList[]>('vouchersList')
</script>

<style lang="scss">
.flex {
	.el-upload-list,
	.el-upload-list__item {
		margin: 0;
		// width: 100%;
	}

	.el-upload-list {
		flex: 1;
	}
}

.slide-up-enter-active,
.slide-up-leave-active {
	transition: all 0.25s ease-out;
}
.slide-up-enter-from {
	opacity: 0;
	transform: translateY(30px);
}
.slide-up-leave-to {
	opacity: 0;
	transform: translateY(-30px);
}

.form-item-animated-container {
	position: relative;
	height: 32px;
}
</style>
