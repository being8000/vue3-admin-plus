<template>
	<el-tabs v-model="activeTab" class="form-tabs">
		<el-tab-pane label="Details" name="details">
			<el-scrollbar>
				<el-form ref="formRef" label-width="auto" :model="form" :rules="rules">
					<basic-info-form v-model="form" />

					<rules-form v-model="form" />

					<scene-selection-form v-model="form" />
				</el-form>
			</el-scrollbar>
		</el-tab-pane>
		<el-tab-pane label="Audit Report" name="audit-report" v-if="form.activityId">
			<audit-record-form
				:id="form.activityId"
				param-key="activityId"
				fetch-url="/activity/activityConfig/auditList"
				:version-id="form.version" />
		</el-tab-pane>
	</el-tabs>
</template>
<script setup lang="ts" name="DetailsForm">
import { FormInstance, FormRules } from 'element-plus'
import { ActivityDetails, ActivityFormVO, Scene } from '@/views/event-management/events/types'
import BasicInfoForm from './BasicInfoForm.vue'
import RulesForm from './RulesForm.vue'
import AuditRecordForm from './AuditRecordForm.vue'
import SceneSelectionForm from './SceneSelectionForm.vue'

const activeTab = ref('details')

const rules = reactive<FormRules<ActivityDetails & Scene>>({
	activityName: [{ required: true, message: 'Event name is required', trigger: 'blur' }],
	activityTime: [{ required: true, message: 'Event time is required' }],
	tenantList: [{ required: true, message: 'Product is required', trigger: 'change' }],
	sceneList: [
		{
			validator(_rule, value, callback, _source, _options) {
				if (!value.length) {
					callback(new Error('Scene should include at least 1 setting'))
				} else {
					callback()
				}
			},
			message: 'Please create at least one scene'
		}
	]
})

const formRef = ref<FormInstance>()
const activeRow = inject<any>('activeRow')
const form = reactive<Partial<ActivityDetails>>({})
const emits = defineEmits<{
	close: []
}>()

watch(
	activeRow,
	async (newFormData?: ActivityDetails) => {
		if (newFormData?.activityId) {
			const { success, result } = (await service.post(
				'/activity/activityConfig/getByActivityId',
				{
					activityId: newFormData?.activityId
				}
			)) as MktBaseResponse

			console.log('/activity/activityConfig/getByActivityId result --->', result)

			if (success && result) {
				Object.assign(
					form,
					new ActivityFormVO({
						...form,
						...result
					})
				)
			}
		} else {
			Object.assign(form, new ActivityFormVO({}))
			if (activeTab.value != 'details') activeTab.value = 'details'
		}

		if (!formRef.value) return
		formRef.value.clearValidate()
	},
	{ immediate: true }
)

const handleSubmit = async () => {
	if (!formRef.value) return

	formRef.value
		.validate(async (valid) => {
			if (valid) {
				let payload: any = {}
				let message: string = ''
				let isSuccess: boolean | undefined

				if (form.id) {
					payload = new ActivityFormVO(form).clean(['activityTime'])
					message = 'Event modified successfully'
					const { success } = (await service.post(
						'/activity/activityConfig/update',
						payload
					)) as MktBaseResponse
					isSuccess = success
				} else {
					payload = new ActivityFormVO(form).clean([
						'activityTime',
						'id',
						'activityId',
						'platformIdList_temp'
					])
					message = 'Event created successfully'
					const { success } = (await service.post(
						'/activity/activityConfig/add',
						payload
					)) as MktBaseResponse

					isSuccess = success
				}

				if (isSuccess) {
					ElMessage.success(message)
					emits('close')
				} else {
					ElMessage.success('Operation failed. Please contact administrator')
				}
			} else {
				console.log('error submit!')
				return false
			}
		})
		.catch((e) => console.log(e))
}

defineExpose({
	handleSubmit
})

provide('formRef', formRef.value)
provide('form', form)
</script>
