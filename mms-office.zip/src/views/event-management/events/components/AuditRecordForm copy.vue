<template>
	<section>
		<section-header class="section-header" title="Audit Records" />
		<el-scrollbar>
			<el-card
				v-for="audit in auditRecords"
				class="mb-3 audit-record-card"
				shadow="never"
				:key="`audit-record-${audit.id}-event-${$route.params.id}`">
				<el-steps finish-status="success" :name="audit.id" :align-center="true">
					<el-step
						:class="{ 'is-loading': !audit.submitTime }"
						:icon="SuccessFilled"
						:status="audit.submitTime ? 'success' : 'wait'">
						<template #title>
							<span>Submit</span>
							<template v-if="audit.submitTime">
								<el-text
									size="small"
									class="block"
									v-if="audit.submitBy"
									tooltip="Submitted by">
									by: {{ audit.submitBy }}
								</el-text>
								<el-text size="small" class="block" v-if="audit.submitTime">
									{{ audit.submitTime }}
								</el-text>
							</template>
						</template>
					</el-step>
					<el-step
						:class="{ 'is-loading': !audit.auditTime }"
						:icon="audit.auditTime ? SuccessFilled : Loading"
						:status="audit.auditTime ? 'success' : 'wait'">
						<template #title>
							<span>Audit</span>
							<template v-if="audit.auditTime">
								<el-text size="small" class="block">
									by: {{ audit.auditBy }}
								</el-text>
								<el-text size="small" class="block">
									{{ audit.auditTime }}
								</el-text>
							</template>
						</template>
					</el-step>
					<el-step
						:class="{ 'is-loading': !audit.auditTime }"
						:status="
							audit.submitTime && audit.auditTime
								? stepsStatus[audit.auditStatus].status
								: 'wait'
						"
						:title="stepsStatus[audit.auditStatus].label"
						:icon="stepsStatus[audit.auditStatus].icon" />
				</el-steps>
			</el-card>

			<div class="w-full text-center">
				<el-link type="info" :underline="false">Load more</el-link>

				<!-- <el-button-group class="float-right">
				<el-button text :icon="ArrowLeft">Previous</el-button>
				<el-button text>
					Next
					<el-icon class="el-icon--right"><ArrowRight /></el-icon>
				</el-button>
			</el-button-group> -->
			</div>
		</el-scrollbar>
	</section>
</template>

<script setup lang="ts" name="AuditRecordForm">
import { AuditStatus } from '~/types'
import { Loading, SuccessFilled, CircleCloseFilled } from '@element-plus/icons-vue'
import { EpPropMergeType } from 'element-plus/es/utils/vue/props/types'

const auditRecords = [
	{
		id: 1,
		auditStatus: AuditStatus.PENDING,
		submitBy: 'Vincent',
		submitTime: '2024-02-18 18:04:22'
	},
	{
		id: 2,
		auditStatus: AuditStatus.APPROVED,
		submitBy: 'Vincent',
		submitTime: '2024-02-18 18:04:22',
		auditBy: 'Cindee',
		auditTime: '2024-02-18 18:04:22'
	},
	{
		id: 3,
		auditStatus: AuditStatus.REJECTED,
		submitBy: 'Vincent',
		submitTime: '2024-02-18 18:04:22',
		auditBy: 'Cindee',
		auditTime: '2024-02-18 18:04:22'
	},
	{
		id: 3,
		auditStatus: AuditStatus.PENDING,
		submitBy: 'John',
		submitTime: '2024-02-18 18:04:22',
		auditBy: 'Cindee',
		auditTime: null
	}
]

type StepsStatus = {
	status: EpPropMergeType<
		StringConstructor,
		'' | 'wait' | 'success' | 'error' | 'finish' | 'process',
		unknown
	>
	label: string
	icon: Component
}

const stepsStatus: Record<any, StepsStatus> = {
	[AuditStatus.PENDING]: {
		status: 'wait',
		label: 'Pending',
		icon: Loading
	},
	[AuditStatus.APPROVED]: {
		status: 'success',
		label: 'Approved',
		icon: SuccessFilled
	},
	[AuditStatus.REJECTED]: {
		status: 'error',
		label: 'Rejected',
		icon: CircleCloseFilled
	}
}
</script>

<style lang="scss" scoped>
.audit-record-card {
	.is-loading {
		:deep(.is-wait .el-icon) {
			animation: rotating 2s linear infinite;
		}
	}
}

.el-text {
	line-height: 2em;
}

:deep(.el-step__icon.is-icon) {
	background: var(--el-bg-color-overlay);
	transition: background-color 0.3s;
}
</style>
