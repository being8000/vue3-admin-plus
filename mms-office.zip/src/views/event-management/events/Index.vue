<template>
	<vxe-grid v-bind="gridOptions" ref="xGrid">
		<template #toolbar_buttons>
			<vxe-button @click="() => openDrawer()" icon="vxe-icon-add">
				{{ $t('Create') }}
			</vxe-button>
		</template>

		<template #operations="{ row, $rowIndex }">
			<template v-for="(button, key) in operationButtons">
				<vxe-button
					v-if="button.show ? button.show(row) : true"
					:key="'operation-' + $rowIndex + '-' + key"
					:icon="button.icon"
					:content="button.content"
					:size="button.size"
					:status="button.status"
					:style="{ width: button.width || 'auto' }"
					@click="
						button.onClick ? button.onClick(row, $rowIndex) : undefined
					"></vxe-button>
			</template>
		</template>
	</vxe-grid>

	<el-drawer v-model="drawer" direction="rtl" size="780px" class="form-drawer">
		<template #header>
			<!-- <el-text tag="strong" size="large" type="primary">
				{{ activeRow.id ? 'View Voucher' : 'Create Voucher' }}
			</el-text> -->

			<page-header />
		</template>
		<template #default>
			<details-form ref="detailsForm" @close="drawer = false" />
		</template>
		<template #footer>
			<div class="mb-2" v-if="activeRow">
				<el-text
					type="warning"
					v-if="activeRow.efficientStatus === ActivityStatus.SUSPENDED">
					This event is currently
					<el-tag size="small" type="danger">Suspended</el-tag>
					. To enable editing, please resume this event
				</el-text>
			</div>
			<div style="flex: auto">
				<el-button size="large" @click="drawer = false" style="min-width: 150px">
					Cancel
				</el-button>
				<el-button
					v-if="activeRow.id && activeRow.efficientStatus === ActivityStatus.NORMAL"
					:disabled="activeRow.efficientStatus === ActivityStatus.SUSPENDED"
					size="large"
					type="primary"
					@click="submitForm"
					style="min-width: 150px">
					Update
				</el-button>
				<el-button
					v-else-if="!activeRow.id"
					:disabled="activeRow.efficientStatus === ActivityStatus.SUSPENDED"
					size="large"
					type="primary"
					@click="submitForm"
					style="min-width: 150px">
					Submit
				</el-button>
			</div>
		</template>
	</el-drawer>
</template>

<script setup lang="ts" name="VouchersIndex">
import {
	ActivityDetails,
	ActivityStatus,
	type Activity
} from '@/views/event-management/events/types'
import { columns, formConfig } from './options'
import { VxeButtonProps, VxeGridInstance } from 'vxe-table'
import { MktBaseResponse } from '@/utils/request'
import DetailsForm from './components/DetailsForm.vue'
import PageHeader from '@/components/PageHeader.vue'
import { AuditStatus, VoucherType } from '~/types'
import { Voucher, VoucherStatus } from '@/views/voucher-management/types'

/**
 * Developer note: Event is typed as Activity
 */

type OperationButtonProps<T> = VxeButtonProps & {
	width?: string | number
	show?: (row: T) => boolean
	onClick?: (row: T, $rowIndex: number) => void
}

const drawer = ref(false)
const detailsForm = ref()

const activeRow = ref<any>({})
provide('activeRow', activeRow)

const xGrid = ref<VxeGridInstance<Activity>>()

const operationButtons: OperationButtonProps<ActivityDetails>[] = [
	{
		name: 'view',
		icon: 'vxe-icon-edit',
		content: 'Edit',
		status: 'info',
		size: 'mini',
		onClick: (row) => openDrawer(row)
	},
	{
		name: 'resume',
		icon: 'vxe-icon-caret-right',
		content: 'table.Resume',
		status: 'success',
		size: 'mini',
		width: '90px',
		show: (row) => [ActivityStatus.NORMAL].includes(row.efficientStatus),
		onClick(row) {
			toggleStatus(row.activityId, ActivityStatus.SUSPENDED, row.version, 'Resume').then(
				() => {
					row.efficientStatus = ActivityStatus.SUSPENDED
				}
			)
		}
	},
	{
		name: 'suspend',
		icon: 'vxe-icon-error-circle',
		content: 'table.Suspend',
		status: 'danger',
		size: 'mini',
		width: '90px',
		show: (row) => [ActivityStatus.SUSPENDED].includes(row.efficientStatus),
		onClick: (row) => {
			toggleStatus(row.activityId, ActivityStatus.NORMAL, row.version, 'Suspend').then(() => {
				row.efficientStatus = ActivityStatus.NORMAL
			})
		}
	}
]
const gridOptions = reactive<VxeGridProps<Activity>>({
	border: true,
	loading: false,
	showFooter: false,
	columns,
	formConfig,
	keepSource: true,
	align: 'center',
	filterConfig: {
		remote: true
	},
	pagerConfig: {
		enabled: true
	},
	toolbarConfig: {
		enabled: true,
		slots: {
			buttons: 'toolbar_buttons'
		}
	},
	exportConfig: {
		modes: ['all', 'current', 'selected'],
		types: ['xlsx', 'csv', 'html'],
		message: true
	},
	proxyConfig: {
		// autoLoad: false, // TODO: remove after testing
		enabled: true,
		props: {
			result: 'result.rows',
			message: 'errorMessage',
			total: 'result.total'
		},
		ajax: {
			query: async ({ page, form, filters, sorts }) => {
				console.log('form --->', form)
				console.log('filters--->', filters)
				console.log('sorts--->', sorts)

				const payload = {
					pageNum: page.currentPage,
					pageSize: page.pageSize,
					...cleanQuery(form)
				}

				const response = await service.post('/activity/activityConfig/pageList', payload)

				return response
			}
		}
	}
})

const openDrawer = (row?: Activity) => {
	activeRow.value = row && row.id ? row : {}
	drawer.value = true
}

const toggleStatus = (
	activityId: ActivityDetails['activityId'],
	status: ActivityDetails['efficientStatus'],
	version: ActivityDetails['version'],
	type: string
) => {
	const payload = {
		activityId,
		status,
		version
	}

	return ElMessageBox.confirm(
		i18n.global.t('ConfirmMessage', {
			type: i18n.global.t('table.' + type).toLowerCase()
		}),
		i18n.global.t('Please confirm'),
		{
			confirmButtonText: i18n.global.t('Confirm'),
			cancelButtonText: i18n.global.t('Cancel'),
			type: 'warning',
			confirmButtonClass: type == 'Resume' ? 'el-button--success' : 'el-button--danger'
		}
	).then((_confirm) => {
		service.post('/activity/activityConfig/switchStatus', payload).then(() => {
			ElMessage({
				message: 'Event status updated successfully',
				type: 'success'
			})
		})
	})
}

const submitForm = () => {
	if (!detailsForm.value) return
	detailsForm.value.handleSubmit()
}

const vouchersList = ref<Voucher[] | never[]>([])

provide('vouchersList', vouchersList)

onMounted(() => {
	service
		.post('/activity/queryVoucherConfig', {
			current: 1,
			voucherTypes: [VoucherType.REBATE],
			voucherStatus: VoucherStatus.NORMAL,
			auditStatus: AuditStatus.APPROVED
		})
		.then((response) => {
			const { success, result } = response as unknown as MktBaseResponse

			if (success && result.records) {
				vouchersList.value =
					result.records.map((option: Voucher) => ({
						rightsConfigName: option.voucherName,
						rightsType: option.voucherType,
						rightsConfigId: option.voucherId
					})) || []

				console.log('vouchersList ---->', vouchersList.value)
			}
		})
})
</script>
