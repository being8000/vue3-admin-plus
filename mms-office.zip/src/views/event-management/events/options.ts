import { AuditStatus, Product } from '~/types'
import { Activity, ActivityStatus } from '@/views/event-management/events/types'
import { VxeGridPropTypes } from 'vxe-table'

const productList = mapEnumToOptions(Product, { encloseValue: true })
const commonStore = useCommonStore()

export const formConfig: VxeGridPropTypes.FormConfig = {
	span: 3,
	items: [
		{
			field: 'tenantList',
			title: 'table.Product',
			itemRender: {
				name: '$elSelect',
				options: productList,
				props: {
					multiple: true,
					maxCollapseTags: 2
				}
			},
			span: 4
		},
		{
			field: 'platformIdList',
			title: 'table.GamePlatform',
			itemRender: {
				name: '$elSelect',
				options: commonStore.platforms,
				props: {
					multiple: true,
					filterable: true
				}
			}
		},
		{
			field: 'activityName',
			title: 'table.EventName',
			itemRender: { name: '$elInput' }
		},
		{
			field: 'creator',
			title: 'table.CreatedBy',
			itemRender: { name: '$elInput' },
			span: 4
		},
		{
			field: 'auditor',
			title: 'table.Auditor',
			itemRender: { name: '$elInput' },
			span: 4
		},
		{
			itemRender: {
				name: '$spacer'
			},
			span: 6
		},
		{
			field: 'createTime_temp',
			title: 'table.CreateTime',
			itemRender: {
				name: '$elDateRange',
				props: { startKey: 'createTimeBegin', endKey: 'createTimeEnd' }
			},
			span: 5
		},
		{
			field: 'updateTime_temp',
			title: 'table.UpdateTime',
			itemRender: {
				name: '$elDateRange',
				props: { startKey: 'updateTimeBegin', endKey: 'updateTimeEnd' }
			},
			span: 5
		},

		{
			field: 'efficientStatus',
			title: 'table.EventStatus',
			itemRender: {
				name: '$elSelect',
				options: mapEnumToOptions(ActivityStatus),
				props: {
					noHeader: true,
					collapseTags: false
				}
			}
		},
		{
			field: 'auditStatus',
			title: 'table.AuditStatus',
			itemRender: {
				name: '$elSelect',
				options: mapEnumToOptions(AuditStatus),
				props: {
					multiple: true,
					maxCollapseTags: 3
				}
			},
			span: 4
		},
		{
			span: 3,
			title: ' ',
			align: 'center',
			itemRender: {
				name: '$buttons',
				children: [
					{
						props: {
							type: 'submit',
							content: 'table.Search',
							status: 'primary',
							icon: 'vxe-icon-search'
						}
					},
					{ props: { type: 'reset', content: 'table.Reset' } }
				]
			}
		}
	]
}

export const columns: VxeGridPropTypes.Columns<Activity> = [
	{ field: 'id', title: 'ID', width: 150, align: 'center' },
	{ field: 'activityName', title: 'table.EventName' },
	{
		field: 'tenants',
		title: 'table.Product',
		formatter: ['$optionFormatter', mapEnumToOptions(Product, {}, undefined, true)],
		cellRender: {
			name: '$elTag',
			props: {
				optionTagStyles: ['', 'warning', 'success', 'danger']
			}
		},
		width: 180
	},
	{
		field: 'platformIds',
		title: 'table.GamePlatform',
		formatter: ['$optionFormatter', commonStore.platforms],
		minWidth: 20
	},
	{ field: 'createBy', title: 'table.CreatedBy' },
	{ field: 'createTime', title: 'table.CreateTime', minWidth: 20 },
	{
		field: 'auditStatus',
		title: 'table.AuditStatus',
		align: 'center',
		formatter: ['$optionFormatter', mapEnumToOptions(AuditStatus)],
		cellRender: {
			name: '$elText',
			props: {
				optionTagStyles: ['warning', 'success', 'danger']
			}
		}
	},
	{ field: 'auditor', title: 'table.Auditor', formatter: ({ cellValue }) => cellValue ?? '--' },
	{ field: 'updateTime', title: 'table.UpdateTime', minWidth: 20 },
	{
		field: 'efficientStatus',
		title: 'table.EventStatus',
		align: 'center',
		cellRender: {
			name: '$elTag',
			props: {
				optionTagStyles: ['danger', 'success']
			}
		},
		formatter: ['$optionFormatter', mapEnumToOptions(ActivityStatus)]
	},
	{
		field: 'operations',
		title: 'table.Operations',
		align: 'center',
		fixed: 'right',
		width: 200,
		slots: { default: 'operations' }
	}
]
