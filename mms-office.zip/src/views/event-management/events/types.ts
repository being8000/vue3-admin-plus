import { AuditStatus, MktBaseData, MktBaseForm, Product, VoucherType, WithTemp } from '~/types'
import { DateModelType } from 'element-plus'
import { Voucher } from '@/views/voucher-management/types'
import { EpPropMergeType } from 'element-plus/es/utils'

/**
 * TODO - For phase 2, ability to select target group(audience)
 */
export enum SceneMode {
	UPLOAD = 1,
	AUDIENCE
}

/**
 * @params senderTimesLimit
 * @field 是否去重 / Deduplication
 * @description 判断逻辑同一用户是否可重复发放
 * @description Determine whether the same logical user can issue repeatedly
 */
export enum DedupeMode {
	NO = 0,
	YES = 1
}

/**
 * @params notifyWay
 * @field 优惠发放时机 / Timing of Distribution
 * @description 优惠通知发放时机
 * @description Discount notification timing
 */
export enum DistributionTiming {
	/** @description Real-time notification 实时通知 */
	IMMEDIATE = 'real',
	/** @description Timed notification 定时通知 */
	FIXED = 'timing'
}

/**
 * @params receiveWay
 * @description 领取方式
 * @description Distribution Method
 */
export enum DistributionMethod {
	/**
	 * 自动发放
	 * @description 为直接发送至用户
	 * @description To send directly to users
	 */
	DIRECTLY = 'directly',
	/**
	 * 登录发放
	 * @description 为用户登陆后发送至用户
	 * @description Sent to the user after logging in
	 */
	LOGIN = 'login',
	/**
	 * 点击发放
	 * @description 为用户点击预设的图片后，发送至用户
	 * @description After clicking the preset picture for the user, send it to the user
	 */
	CLICK = 'click'
}

export enum NotificationChannel {
	SMS = 'sms',
	'In-site' = 'message'
}

export enum ActivityStatus {
	SUSPENDED = 'disable',
	NORMAL = 'enable'
}

export type StepsStatus = {
	status: EpPropMergeType<
		StringConstructor,
		'' | 'wait' | 'success' | 'error' | 'finish' | 'process',
		unknown
	>
	label: string
	icon: Component
}

export type Activity = MktBaseData & {
	activityName: string
	activityDesc: string
	/**
	 * @alias tenantList
	 * @description Product 产品线
	 */
	tenants?: string | string[]
	tenantList?: Product[] | Array<{ tenant: string }>
	startTime: string | Date
	endTime: string | Date
	/**
	 * @alias gamePlatformList
	 * @description Game Platform
	 */
	platformIdList?:
		| string[]
		| Array<{
				platformId: string
		  }>
	platformIds?: string
}

export type ActivityDetails = Activity & {
	id: string | number
	activityId: string | number
	/**
	 *  @alias activityStatus
	 * 	@description Activity status
	 *  @description 活动状态
	 */
	efficientStatus: ActivityStatus
	auditStatus?: AuditStatus
	version?: string | number
	creator: string
	updateBy: string

	creditConfigListReq: CreditConfigReg[]
	sceneList: Scene[]
	// Temp data
	activityTime: string | number | Date | [DateModelType, DateModelType] | [string, string]
	platformIdList_temp?: string[]
	tenantList_temp?: string[]
}

export type Scene = {
	sceneId: string | number
	sceneDesc: string
	crowId?: string
	auditWay?: SceneMode
	receiveWay: string
	notifyChannel: string
	notifyWay: DistributionTiming
	notifyTemplateContent?: string
	notifyTemplateId?: string
	notifyTime?: string | Date
	senderTimesLimit: number
	senderCycle?: string
	sceneRightsRelationList?: Array<RightsConfigList>
	sceneRightsRelationList_temp?: Array<RightsConfigList>
} & WithTemp

export type CreditConfigReg =
	| {
			rightsType?: string
			rightsCredit?: number
	  }
	| never

export class ActivityFormVO extends MktBaseForm {
	activityName: ActivityDetails['activityName']
	activityDesc: ActivityDetails['activityDesc']
	startTime: ActivityDetails['startTime']
	endTime: ActivityDetails['endTime']
	platformIdList?: ActivityDetails['platformIdList']
	/**
	 * @alias productList
	 * @description Product 产品线
	 */
	tenantList?: ActivityDetails['tenantList']
	creditConfigListReq: ActivityDetails['creditConfigListReq']
	sceneList: ActivityDetails['sceneList']
	id: ActivityDetails['id']
	activityId: ActivityDetails['activityId']
	/**
	 *  @alias activityStatus
	 * 	@description Activity status
	 *  @description 活动状态
	 */
	efficientStatus?: ActivityStatus
	auditStatus: AuditStatus
	version: string | number
	creator: string
	updateBy: string

	// Temp data
	activityTime: string | number | Date | [DateModelType, DateModelType] | [string, string]
	platformIdList_temp: ActivityDetails['platformIdList']
	// form?: Record<any, any>

	constructor(activity: ActivityDetails | Record<any, any>) {
		super()

		// this.form = activity
		this.id = activity.id
		this.activityId = activity.activityId
		this.efficientStatus = activity.efficientStatus
		this.auditStatus = activity.auditStatus
		this.activityDesc = activity.activityDesc

		this.activityTime = [activity.startTime, activity.endTime]
		this.startTime = activity.startTime
		this.endTime = activity.endTime
		this.activityName = activity.activityName
		this.tenantList = activity.tenantList
		this.platformIdList = activity.platformIdList
		this.platformIdList_temp = activity.platformIdList
		this.version = activity.version
		this.creator = activity.creator || 'chris'
		this.updateBy = activity.updateBy || 'chris'
		this.activityTime = [activity.startTime, activity.endTime]
		this.creditConfigListReq =
			activity.creditConfigListReq && activity.creditConfigListReq.length
				? activity.creditConfigListReq
				: [
						{
							activityId: activity.activityId,
							rightsType: VoucherType.REBATE,
							rightsCredit: null
						}
					]
		this.sceneList =
			activity.sceneList && activity.sceneList.length
				? activity.sceneList.map((element: Scene) => new SceneVO(element))
				: [new SceneVO({})]
	}
}

export class SceneVO {
	sceneId: string | number
	sceneDesc: string
	crowId?: string
	auditWay?: SceneMode
	receiveWay: string
	notifyChannel: string
	notifyWay: DistributionTiming
	notifyTemplateContent?: string
	notifyTemplateId?: string
	notifyTime?: string | Date
	senderTimesLimit: number
	senderCycle?: string
	sceneRightsRelationList?: Array<RightsConfigList>
	sceneRightsRelationList_temp?: Array<RightsConfigList>

	constructor(scene: Scene | Record<any, any>) {
		this.sceneId = scene.sceneId
		this.sceneDesc = scene.sceneDesc
		this.crowId = scene.crowId
		this.auditWay = scene.auditWay
		this.receiveWay = scene.receiveWay
		this.notifyWay = scene.notifyWay
		this.notifyChannel = scene.notifyChannel
		this.notifyTemplateContent = scene.notifyTemplateContent
		this.notifyTemplateId = scene.notifyTemplateId
		this.notifyTime = scene.notifyTime
		this.senderTimesLimit = scene.senderTimesLimit
		this.senderCycle = scene.senderCycle

		this.sceneRightsRelationList =
			scene.sceneRightsRelationList && scene.sceneRightsRelationList[0].rightsConfigId
				? scene.sceneRightsRelationList?.map(
						(element: RightsConfigList) => new RightsConfigList(element)
					)
				: undefined
		this.sceneRightsRelationList_temp = scene.sceneRightsRelationList
			? scene.sceneRightsRelationList.map(
					(element: RightsConfigList) => element.rightsConfigId
				)
			: undefined
	}
}

export class RightsConfigList {
	id?: string | number
	activityId?: string
	sceneId?: string
	rightsType?: VoucherType
	rightsConfigName?: string
	rightsConfigId?: Voucher['voucherId']

	constructor(item: RightsConfigList) {
		this.id = item.id
		this.activityId = item.activityId
		this.sceneId = item.sceneId
		this.rightsType = item.rightsType
		this.rightsConfigName = item.rightsConfigName
		this.rightsConfigId = item.rightsConfigId
	}
}

// export class Collection<T> {
// 	collection: Array<T>
// 	constructor(list: Array<T>, fields: string[] = []) {
// 		this.collection = list.map(() => )
// 	}
// }
