import { AuditStatus, VoucherType, MktBaseData, Product } from '~/types'

export type GameScopes = {
	gamePlatform: {
		id: number | string
		name: string
	}
	gameKind: {
		id: number | string
		name: string
	}
	gameName: {
		id: number | string
		name: string
	}
}

export type Proposal = MktBaseData & {
	proposalId: string | number
	activityId: string | number

	/** @alias product */
	product: Product | Product[]

	activityName: string
	voucherName: string
	voucherType: VoucherType

	/** @alias amount */
	bornCredit: string | number

	/** @alias account */
	loginName: string

	creator: string
	createTime: Date | string
	auditor: string
	auditTime: string | Date
	auditStatus: AuditStatus
}
