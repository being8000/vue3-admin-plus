<template>
	{{ t('Dashboard') }}
	<h1>Welcome, {{ loginName }}~</h1>
</template>

<script setup lang="ts" name="dashboard">
import { useUserStore } from '@/stores'
// Alternatively, you can also use $t('key.name') directly on the template. Check README.md
const { t } = useI18n()

const userStore = useUserStore()
const loginName = computed(() => {
	return userStore.user.name
})
</script>
