// /queryVoucherAuditByVhoucerId
// parameter:
// {
//     "voucherId":"1780779564577787904",
//      "size":"4",
//     "current":"1"
// }

/**
 * 
 * @interface /queryVoucherConfig
 * @method POST
 *
 * @description 查询优惠分列表
 * @description Query discount list
 *
 * @param {Date | string} createStartTime
 * @param {Date | string} createEndTime
 * @param {string} status
 * @param {string} product - PG | AP | BP | GP
 * @param {string} gamePlatforms
 * @param {number} size - Number of records per page
 * @param {number} current - Current page number
 *
 * @example
 * {
        "createStartTime":"2024-04-01",
        "createEndTime":"2024-04-30",
        "status":"enable",
        "product":"PG",
        "gamePlatforms":"079",
        "size":2,
        "current":1
    }
 * 
 * @returns
 * "records": [
      {
        "id": 0,
        "voucherId": "string",
        "voucherName": "string",
        "voucherDesc": "string",
        "startTime": "2024-04-19T03:00:06.894Z",
        "endTime": "2024-04-19T03:00:06.894Z",
        "auditStatus": "string",
        "efficientStatus": "string",
        "lastAuditId": "string",
        "voucherType": "string",
        "betCredit": 0,
        "tryPlayCredit": 0,
        "tryPlayLeastBetCredit": 0,
        "rebateCredit": 0,
        "rebateLeastBetCredit": 0,
        "createTime": "2024-04-19T03:00:06.894Z",
        "updateTime": "2024-04-19T03:00:06.894Z",
        "createBy": "string",
        "updateBy": "string",
        "auditor": "string",
        "version": 0,
        "products": "string",
        "tenant": "string",
        "gamePlatforms": "string",
        "platformId": "string"
      }
    ],
 */

/**
 * @description 优惠分开关控制,启用<->禁用
 * @description Discount switch control, enable <-> disable
 *
 * @param {number | string} voucherId
 * @param {string} efficientStatus
 *
 * @method POST
 * /voucherSwitchControl
 *
 */
