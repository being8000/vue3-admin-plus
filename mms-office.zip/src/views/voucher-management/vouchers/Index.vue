<template>
	<vxe-grid v-bind="gridOptions" ref="xGrid">
		<template #toolbar_buttons>
			<vxe-button @click="() => openDrawer()" icon="vxe-icon-add">
				{{ $t('Create') }}
			</vxe-button>
		</template>

		<template #operations="{ row, $rowIndex }">
			<template v-for="(button, key) in operationButtons">
				<vxe-button
					v-if="button.show ? button.show(row) : true"
					:key="'operation-' + $rowIndex + '-' + key"
					:icon="button.icon"
					:content="button.content"
					:size="button.size"
					:status="button.status"
					:style="{ width: button.width || 'auto' }"
					@click="
						button.onClick ? button.onClick(row, $rowIndex) : undefined
					"></vxe-button>
			</template>
		</template>
	</vxe-grid>

	<el-drawer v-model="drawer" direction="rtl" size="780px">
		<template #header>
			<!-- <el-text tag="strong" size="large" type="primary">
				{{ activeRow.id ? 'View Voucher' : 'Create Voucher' }}
			</el-text> -->

			<page-header />
		</template>
		<template #default>
			<details-form ref="detailsForm" @close="drawer = false" />
		</template>
		<template #footer>
			<div class="mb-2" v-if="activeRow">
				<el-text type="warning" v-if="activeRow.voucherStatus === VoucherStatus.SUSPENDED">
					This voucher is currently
					<el-tag size="small" type="danger">Suspended</el-tag>
					. To enable editing, please resume this voucher
				</el-text>
			</div>
			<div style="flex: auto">
				<el-button size="large" @click="drawer = false" style="min-width: 150px">
					Cancel
				</el-button>
				<el-button
					v-if="activeRow.id && activeRow.voucherStatus === VoucherStatus.NORMAL"
					:disabled="activeRow.voucherStatus === VoucherStatus.SUSPENDED"
					size="large"
					type="primary"
					@click="submitForm"
					style="min-width: 150px">
					Update
				</el-button>
				<el-button
					v-else-if="!activeRow.id"
					:disabled="activeRow.voucherStatus === VoucherStatus.SUSPENDED"
					size="large"
					type="primary"
					@click="submitForm"
					style="min-width: 150px">
					Submit
				</el-button>
			</div>
		</template>
	</el-drawer>
</template>

<script setup lang="ts" name="VouchersIndex">
import { VoucherDetails, VoucherStatus, type Voucher } from '@/views/voucher-management/types'
import { columns, formConfig } from './options'
import { VxeButtonProps, VxeGridInstance } from 'vxe-table'
import { MktBaseResponse } from '@/utils/request'
import DetailsForm from './components/DetailsForm.vue'
import PageHeader from '@/components/PageHeader.vue'
import { VoucherType } from '~/types'

type OperationButtonProps<T> = VxeButtonProps & {
	width?: string | number
	show?: (row: T) => boolean
	onClick?: (row: T, $rowIndex: number) => void
}

const drawer = ref(false)
const detailsForm = ref()

const activeRow = ref<any>({})
provide('activeRow', activeRow)

const xGrid = ref<VxeGridInstance<Voucher>>()

const operationButtons: OperationButtonProps<VoucherDetails>[] = [
	{
		name: 'view',
		icon: 'vxe-icon-edit',
		content: 'table.Edit',
		status: 'info',
		size: 'mini',
		onClick: (row) => openDrawer(row)
	},
	{
		name: 'resume',
		icon: 'vxe-icon-caret-right',
		content: 'table.Resume',
		status: 'success',
		size: 'mini',
		width: '90px',
		show: (row) => [VoucherStatus.NORMAL].includes(row.voucherStatus),
		onClick(row) {
			toggleStatus(row.id, VoucherStatus.SUSPENDED, row.version, 'Resume').then(
				(response) => {
					console.log(response)
					row.voucherStatus = VoucherStatus.SUSPENDED
				}
			)
		}
	},
	{
		name: 'suspend',
		icon: 'vxe-icon-error-circle',
		content: 'table.Suspend',
		status: 'danger',
		size: 'mini',
		width: '90px',
		show: (row) => [VoucherStatus.SUSPENDED].includes(row.voucherStatus),
		onClick: (row) => {
			toggleStatus(row.id, VoucherStatus.NORMAL, row.version, 'Suspend').then((response) => {
				console.log(response)
				row.voucherStatus = VoucherStatus.NORMAL
			})
		}
	}
]
const gridOptions = reactive<VxeGridProps<Voucher>>({
	border: true,
	loading: false,
	showFooter: false,
	columns,
	formConfig,
	// keepSource: true,
	filterConfig: {
		remote: true
	},
	pagerConfig: {
		enabled: true
	},
	toolbarConfig: {
		enabled: true,
		slots: {
			buttons: 'toolbar_buttons'
		}
	},
	exportConfig: {
		modes: ['all', 'current', 'selected'],
		types: ['xlsx', 'csv', 'html'],
		message: true
	},
	proxyConfig: {
		enabled: true,
		ajax: {
			query: async ({ page, form, filters, sorts }) => {
				console.log('form --->', form)
				console.log('filters--->', filters)
				console.log('sorts--->', sorts)

				const payload = {
					current: page.currentPage,
					size: page.pageSize,
					...cleanQuery({ ...form, voucherTypes: [VoucherType.REBATE] })
				}

				const response = await service.post('/queryVoucherConfig', payload)

				return response
			}
		}
	}
})

const openDrawer = (row?: VoucherDetails) => {
	activeRow.value = row && row.id ? row : {}
	drawer.value = true
}

const toggleStatus = (
	id: VoucherDetails['voucherId'],
	voucherStatus: VoucherStatus,
	versionId: VoucherDetails['versionId'],
	type: string
) => {
	const payload = {
		id,
		voucherStatus,
		versionId
	}

	return ElMessageBox.confirm(
		i18n.global.t('ConfirmMessage', {
			type: i18n.global.t('table.' + type).toLowerCase()
		}),
		i18n.global.t('Please confirm'),
		{
			confirmButtonText: i18n.global.t('Confirm'),
			cancelButtonText: i18n.global.t('Cancel'),
			type: 'warning',
			confirmButtonClass: type == 'Resume' ? 'el-button--success' : 'el-button--danger'
		}
	).then((_confirm) => {
		service.post('/voucherSwitchControl', payload).then((response) => {
			const { success } = response as MktBaseResponse
			if (success) {
				ElMessage({
					message: 'Voucher status updated successfully',
					type: 'success'
				})
			}
		})
	})
}

const submitForm = () => {
	if (!detailsForm.value) return
	detailsForm.value.handleSubmit()
}
</script>
