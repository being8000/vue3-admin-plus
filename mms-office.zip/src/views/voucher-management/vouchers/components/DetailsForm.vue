<template>
	<el-tabs v-model="activeTab" class="demo-tabs">
		<el-tab-pane label="Details" name="details">
			<!-- <div id="form-details"></div> -->
			<el-form ref="formRef" label-width="auto" :model="form" :rules="rules">
				<basic-info-form v-model="form" />

				<rules-form v-model="form" />
			</el-form>
		</el-tab-pane>

		<el-tab-pane label="Audit Report" name="audit-report" v-if="form.voucherId">
			<audit-record-form :voucher-id="form.voucherId" :version-id="form.versionId" />
		</el-tab-pane>
	</el-tabs>
</template>
<script setup lang="ts" name="DetailsForm">
import { FormInstance, FormRules } from 'element-plus'
import { Voucher, VoucherDetails, VoucherFormVO } from '../../types'
import BasicInfoForm from './BasicInfoForm.vue'
import RulesForm from './RulesForm.vue'
import AuditRecordForm from './AuditRecordForm.vue'
import { MktBaseResponse } from '@/utils/request'

const activeTab = ref('details')

const rules = reactive<FormRules>({
	voucherName: [{ required: true, message: 'Please input the name', trigger: 'blur' }],
	// gamePlatforms: [
	// 	{ required: true, message: 'Please select at least 1 game platform', trigger: 'change' }
	// ],
	// productList: [
	// 	{ required: true, message: 'Please select at least one product', trigger: 'blur' }
	// ],
	voucherType: [{ required: true, message: 'Please select a voucher type', trigger: 'change' }]
})

const formRef = ref<FormInstance>()
const activeRow = inject<any>('activeRow')
const form = reactive<Partial<VoucherDetails>>({
	updateBy: 'roger',
	creator: 'roger'
})

const emits = defineEmits<{
	close: []
}>()

watch(
	activeRow,
	(newFormData?: Voucher) => {
		if (newFormData?.id) {
			Object.assign(
				form,
				new VoucherFormVO({
					...form,
					...newFormData
				})
			)
		} else {
			Object.assign(form, new VoucherFormVO({}))
			if (activeTab.value != 'details') activeTab.value = 'details'
		}

		if (!formRef.value) return
		formRef.value.clearValidate()
		// activeTab.value = 'details'
	},
	{ immediate: true }
)

const handleSubmit = () => {
	if (!formRef.value) return
	formRef.value.validate((valid) => {
		if (valid) {
			let payload: any = {}

			if (form.id) {
				payload = new VoucherFormVO(form).clean()
				console.log(payload)
				service.post('/modifyVoucher', payload).then((res) => {
					const { success }: { success?: boolean } = res as MktBaseResponse
					if (success) {
						ElMessage.success('Voucher modified successfully')
						emits('close')
					} else {
						ElMessage.success('Update failed. Please contact administrator')
					}
				})
			} else {
				payload = new VoucherFormVO(form).clean()
				console.log(payload)
				service.post('/createVoucher', payload).then((res) => {
					const { success }: { success?: boolean } = res as MktBaseResponse
					if (success) {
						ElMessage.success('Voucher created successfully')
						emits('close')
					} else {
						ElMessage.success('Update failed. Please contact administrator')
					}
				})
			}
		} else {
			console.log('error submit!')
			return false
		}
	})
}

defineExpose({
	handleSubmit
})

provide('formRef', formRef.value)
provide('form', form)
</script>
