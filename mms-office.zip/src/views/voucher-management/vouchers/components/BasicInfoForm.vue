<template>
	<section>
		<section-header class="section-header" title="Basic Information" />
		<el-card class="mb-3" shadow="never">
			<el-form-item label="Voucher Name" prop="voucherName">
				<el-input v-model="modelValue.voucherName" />
			</el-form-item>

			<el-form-item label="Expiry Date" prop="endTime" style="max-width: 600px">
				<el-date-picker
					type="datetimerange"
					v-model="modelValue.expiryTime"
					@update:model-value="
						(val) => {
							modelValue.startTime = val[0]
							modelValue.endTime = val[1]
						}
					"
					value-format="YYYY-MM-DD HH:mm:ss"
					end-placeholder="End time"
					start-placeholder="Start time"
					:default-time="
						[
							new Date().setHours(0, 0, 0, 0),
							new Date().setHours(23, 59, 59, 59)
						] as any
					"
					:onUpdate:modelValue="
						(val: any) => {
							modelValue.endTime = val[1]
							modelValue.startTime = val[0]
						}
					"
					placeholder="Select date" />
			</el-form-item>

			<el-form-item label="Product" prop="productList">
				<el-select-v2
					:empty-values="[undefined, null]"
					tag-type="primary"
					v-model="modelValue.productList"
					:value-on-clear="() => undefined"
					multiple
					clearable
					filterable
					:options="mapEnumToOptions(Product, { encloseValue: true })">
					<template #header>
						<el-checkbox
							:modelValue="
								modelValue.productList?.length === products?.length || false
							"
							:onUpdate:modelValue="handleOnUpdateProductList">
							{{ $t('All') }}
						</el-checkbox>
					</template>
				</el-select-v2>
			</el-form-item>
		</el-card>
	</section>
</template>

<script setup lang="ts" name="BasicInfoForm">
import { Product } from '~/types'
import { mapEnumToOptions } from '@/composables/use-helpers'
import { VoucherDetails } from '@/views/voucher-management/types'

const modelValue = defineModel<Partial<VoucherDetails>>({ required: true })
const products = mapEnumToOptions(Product)

const handleOnUpdateProductList = (val: any) => {
	if (val) {
		modelValue.value.productList = products?.map((option: { value: Product }) => option.value)
	} else {
		modelValue.value.productList = undefined
	}

	return !val
}
</script>
