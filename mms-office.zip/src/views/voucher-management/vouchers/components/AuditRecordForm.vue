<template>
	<el-scrollbar>
		<el-card
			size="small"
			v-for="audit in auditRecords"
			class="mb-3 audit-record-card"
			shadow="never"
			:key="`audit-record-${audit.id}-event-${$route.params.id}`"
			badge="1">
			<el-steps finish-status="success" :name="audit.id" :align-center="true">
				<el-step
					:class="{ 'is-loading': !audit.createTime }"
					:icon="SuccessFilled"
					:status="audit.createTime ? 'success' : 'wait'">
					<template #title>
						<span>Submit</span>
						<template v-if="audit.createBy">
							<el-text
								size="small"
								class="block"
								v-if="audit.createBy"
								tooltip="Submitted by">
								by: {{ audit.createBy }}
							</el-text>
							<el-text size="small" class="block" v-if="audit.createTime">
								{{ $filters.toDate(audit.createTime) }}
							</el-text>
						</template>
					</template>
				</el-step>
				<el-step
					:class="{ 'is-loading': audit.auditStatus === AuditStatus.PENDING }"
					:icon="audit.auditStatus !== AuditStatus.PENDING ? SuccessFilled : Loading"
					:status="audit.auditStatus !== AuditStatus.PENDING ? 'success' : 'wait'">
					<template #title>
						<span>Audit</span>
						<template v-if="audit.auditor">
							<el-text size="small" class="block">by: {{ audit.auditor }}</el-text>
							<el-text
								size="small"
								class="block"
								v-if="audit.auditStatus !== AuditStatus.PENDING">
								{{ $filters.toDate(audit.updateTime) }}
							</el-text>
						</template>
					</template>
				</el-step>
				<el-step
					:class="{ 'is-loading': audit.auditStatus === AuditStatus.PENDING }"
					:status="
						audit.createTime && audit.updateTime
							? stepsStatus[audit.auditStatus].status
							: 'wait'
					"
					:title="stepsStatus[audit.auditStatus].label"
					:icon="stepsStatus[audit.auditStatus].icon">
					<!-- <template #title>
						<div>{{ stepsStatus[audit.auditStatus].label }}</div>
						<div>
							<el-text>Please click to audit</el-text>
						</div>
						<template v-if="audit.updateTime">
							<el-button type="success" plain>Approve</el-button>
							<el-button type="danger" plain>Reject</el-button>
						</template>
					</template> -->
				</el-step>
			</el-steps>

			<template #footer v-if="audit.auditStatus === AuditStatus.PENDING">
				<div class="flex justify-end">
					<el-button
						type="success"
						plain
						@click="handleAuditReview(audit, AuditStatus.APPROVED)">
						Approve
					</el-button>
					<el-button
						type="danger"
						plain
						@click="handleAuditReview(audit, AuditStatus.REJECTED)">
						Reject
					</el-button>
				</div>
			</template>
		</el-card>

		<div class="w-full text-center">
			<el-link
				type="info"
				:underline="false"
				@click="handleLoadMore"
				v-if="pageData.pages && pageData.pages > pageData.current">
				Load more
			</el-link>
		</div>
	</el-scrollbar>
</template>

<script setup lang="ts" name="AuditRecordForm">
import { AuditStatus } from '~/types'
import { Loading, SuccessFilled, CircleCloseFilled } from '@element-plus/icons-vue'
import { EpPropMergeType } from 'element-plus/es/utils/vue/props/types'
import { AuditRecord } from '~/types'
import { MktBaseResponse } from '@/utils/request'

const props = defineProps<{
	voucherId: string | number
	versionId?: string | number
}>()

const pageData = reactive<{ current: number; size?: number; total?: number; pages?: number }>({
	current: 1,
	size: 4
})

const auditRecords = ref<AuditRecord[]>([])

type StepsStatus = {
	status: EpPropMergeType<
		StringConstructor,
		'' | 'wait' | 'success' | 'error' | 'finish' | 'process',
		unknown
	>
	label: string
	icon: Component
}

const stepsStatus: Record<any, StepsStatus> = {
	[AuditStatus.PENDING]: {
		status: 'wait',
		label: 'Pending',
		icon: Loading
	},
	[AuditStatus.APPROVED]: {
		status: 'success',
		label: 'Approved',
		icon: SuccessFilled
	},
	[AuditStatus.REJECTED]: {
		status: 'error',
		label: 'Rejected',
		icon: CircleCloseFilled
	}
}

const getList = async (
	payload = { voucherId: props.voucherId, current: pageData.current, size: pageData.size }
) => {
	const { result } = (await service.post(
		'/queryVoucherAuditByVhoucerId',
		payload
	)) as MktBaseResponse

	if (result) {
		console.log('queryVoucherAuditByVhoucerId --->', result)
		Object.assign(pageData, pick(result, ['current', 'size', 'pages']))

		return result.records
	} else {
		return []
	}
}

watch(
	() => props.voucherId,
	async (voucherId?: string | number) => {
		if (voucherId) {
			const payload = { voucherId, current: 1, size: pageData.size }
			auditRecords.value = await getList(payload)
		}
	},
	{
		immediate: true
	}
)

const handleLoadMore = async () => {
	const payload = {
		voucherId: props.voucherId,
		size: pageData.size,
		current: pageData.current + 1
	}
	const newRecords = await getList(payload)

	console.log(newRecords)

	if (newRecords.length) {
		auditRecords.value = [...auditRecords.value, ...newRecords]
	}
}

const handleAuditReview = async (audit: AuditRecord, auditStatus: AuditStatus) => {
	console.log(audit)
	const payload = {
		...pick(audit, ['id', 'auditId']),
		auditStatus,
		voucherId: props.voucherId,
		versionId: props.versionId
	}

	const { success }: { success?: boolean } = await service.post('/voucherReview', payload)

	if (success) {
		audit.auditStatus = auditStatus
		ElMessage.success('Audit success')
	}
}
</script>

<style lang="scss" scoped>
.audit-record-card {
	.is-loading {
		:deep(.is-wait .el-icon) {
			animation: rotating 2s linear infinite;
		}
	}

	:deep(.el-card__footer) {
		padding: 8px;
	}
}

.el-text {
	line-height: 2em;
}

:deep(.el-step__icon.is-icon) {
	background: var(--el-bg-color-overlay);
	transition: background-color 0.3s;
}
</style>
