<template>
	<section>
		<section-header class="section-header" title="Rules" />
		<el-card class="mb-3" shadow="never">
			<div>
				<el-form-item prop="voucherType">
					<el-text>{{ $t('Voucher Type') }}</el-text>
				</el-form-item>

				<el-radio-group
					v-model="modelValue.voucherType"
					class="w-full gap-6 voucher-types-container mt-3"
					@change="handleChangeVoucherType">
					<template
						v-for="voucherType in Object.values(VoucherType)"
						:key="voucherType + '-radio'">
						<el-radio
							:value="voucherType"
							class="w-full"
							:disabled="voucherType !== VoucherType.REBATE">
							<el-row class="w-full items-center m-0!" :gutter="24">
								<el-col :span="3">
									{{ $t('voucherType', [$t(voucherType)]) }}
								</el-col>
								<el-col :span="11">
									<el-form-item
										label="Amount"
										:prop="
											amountKeyByBet[voucherType] as unknown as
												| 'betCredit'
												| 'rebateCredit'
												| 'tryPlayCredit'
										"
										class="mb-0!"
										:required="modelValue.voucherType === voucherType"
										:show-message="false">
										<el-input-number
											:disabled="modelValue.voucherType !== voucherType"
											style="width: unset"
											class="w-full flex-1"
											v-model="
												modelValue[
													amountKeyByBet[voucherType] as unknown as
														| 'betCredit'
														| 'rebateCredit'
														| 'tryPlayCredit'
												]
											"
											:min="0"
											:max="10000000000"
											:step="1000"
											:empty-values="[null, undefined, 0, '', 0.0]"
											:value-on-clear="undefined"
											:placeholder="
												modelValue.voucherType === voucherType
													? 'Enter amount'
													: ''
											"
											:precision="2"
											controls-position="right" />
									</el-form-item>
								</el-col>

								<el-col :span="10">
									<el-form-item
										:prop="
											amountLeastKeyByBet[voucherType] as unknown as
												| 'betCredit'
												| 'rebateCredit'
												| 'tryPlayCredit'
										"
										label="Minimum Turnover"
										class="mb-0!"
										v-if="
											[VoucherType.REBATE, VoucherType.TURNOVER].includes(
												voucherType as VoucherType
											)
										">
										<el-input-number
											:disabled="modelValue.voucherType !== voucherType"
											style="width: unset"
											class="w-full flex-1"
											v-model="
												modelValue[
													amountLeastKeyByBet[voucherType] as unknown as
														| 'rebateLeastBetCredit'
														| 'tryPlayLeastBetCredit'
												] as number
											"
											:placeholder="
												modelValue.voucherType === voucherType
													? 'Unlimited'
													: ''
											"
											:min="0"
											:max="10000000000"
											:step="1000"
											:empty-values="[null, undefined, 0, '', 0.0]"
											:value-on-clear="undefined"
											:precision="2"
											controls-position="right" />
									</el-form-item>
								</el-col>
							</el-row>
						</el-radio>
					</template>
				</el-radio-group>
			</div>

			<el-form-item label="Game Platforms" prop="gamePlatformList" class="mt-6">
				<el-select-v2
					v-model="modelValue.gamePlatformList"
					:empty-values="[null, undefined]"
					:value-on-clear="() => undefined"
					collapse-tags
					collapse-tags-tooltip
					filterable
					multiple
					tag-type="warning"
					:max-collapse-tags="6"
					:options="commonStore.platforms"
					clearable />
			</el-form-item>
		</el-card>
	</section>
</template>

<script setup lang="ts" name="VoucherRulesForm">
import { VoucherType } from '~/types'
import { amountKeyByBet, amountLeastKeyByBet } from '@/views/voucher-management/vouchers/options'
import { VoucherDetails } from '@/views/voucher-management/types'
import { FormInstance } from 'element-plus'

const modelValue = defineModel<Partial<VoucherDetails>>({ required: true })
const formRef = inject<FormInstance>('formRef')

const commonStore = useCommonStore()

const handleChangeVoucherType = (_value: unknown) => {
	// handleClearValidate(
	// 	[
	// 		'betCredit',
	// 		'rebateCredit',
	// 		'tryPlayCredit',
	// 		'rebateLeastBetCredit',
	// 		'tryPlayLeastBetCredit'
	// 	],
	// 	formRef
	// )

	formRef?.clearValidate([
		'betCredit',
		'rebateCredit',
		'tryPlayCredit',
		'rebateLeastBetCredit',
		'tryPlayLeastBetCredit'
	])
}
</script>

<style lang="scss" scoped>
.voucher-types-container {
	.el-radio.w-full {
		margin: 0;

		.el-row {
			.el-col:last-child.is-guttered {
				padding-right: 0 !important;
			}
		}
	}

	:deep(.el-radio__label) {
		width: 100%;
	}
}
</style>
