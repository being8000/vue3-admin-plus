import { VoucherStatus } from '@/views/voucher-management/types'
import { AuditStatus, Product, VoucherType } from '~/types'

export const listDataVO = [
	{
		id: 10001,
		voucherName: 'ABC123',
		voucherDesc: 'Voucher Description 1',
		account: 'Account 1',
		createBy: 'Zoe',
		createTime: '2021-09-01 10:00:00',
		auditor: 'Tom',

		products: Product.PERYA_GAME,
		// scope: {
		// 	gamePlatform: {
		// 		id: 1,
		// 		name: 'Game Platform 1'
		// 	},
		// 	gameKind: {
		// 		id: 1,
		// 		name: 'Game Kind 1'
		// 	},
		// 	gameName: {
		// 		id: 1,
		// 		name: 'Game Name 1'
		// 	}
		// },
		startTime: '2021-09-01 10:00:00',
		endTime: '2021-09-01 11:00:00',
		auditStatus: AuditStatus.REJECTED,
		voucherStatus: VoucherStatus.NORMAL,
		lastAuditId: 10001,
		voucherType: VoucherType.BET,
		amount: 1000,
		updateBy: 'John',
		updateTime: '2021-09-01 11:00:00',
		tenant: 'Tenant 1',
		platformId: 'Platform 1',
		gamePlatforms: 'Game Platform 1'
	},
	{
		id: 10001,
		voucherName: 'ABC123',
		voucherDesc: 'Voucher Description 1',
		account: 'Account 1',
		createBy: 'Zoe',
		createTime: '2021-09-01 10:00:00',
		auditor: 'Tom',
		products: Product.PERYA_GAME,
		startTime: '2021-09-01 10:00:00',
		endTime: '2021-09-01 11:00:00',
		auditStatus: AuditStatus.REJECTED,
		voucherStatus: VoucherStatus.NORMAL,
		lastAuditId: 10001,
		voucherType: VoucherType.BET,
		amount: 1000,
		updateBy: 'John',
		updateTime: '2021-09-01 11:00:00',
		tenant: 'Tenant 1',
		platformId: 'Platform 1',
		gamePlatforms: 'Game Platform 1'
	},
	{
		id: 10001,
		voucherName: 'ABC123',
		voucherDesc: 'Voucher Description 1',
		account: 'Account 1',
		createBy: 'Zoe',
		createTime: '2021-09-01 10:00:00',
		auditor: 'Tom',
		products: Product.PERYA_GAME,
		startTime: '2021-09-01 10:00:00',
		endTime: '2021-09-01 11:00:00',
		auditStatus: AuditStatus.REJECTED,
		voucherStatus: VoucherStatus.NORMAL,
		lastAuditId: 10001,
		voucherType: VoucherType.BET,
		amount: 1000,
		updateBy: 'John',
		updateTime: '2021-09-01 11:00:00',
		tenant: 'Tenant 1',
		platformId: 'Platform 1',
		gamePlatforms: 'Game Platform 1'
	}
]
