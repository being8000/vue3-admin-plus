import { AuditStatus, Product, VoucherType } from '~/types'
import { Voucher, VoucherStatus } from '../types'
import { VxeGridPropTypes } from 'vxe-table'
import { useCommonStore } from '@/stores'

const commonStore = useCommonStore()

export const amountKeyByBet = {
	[VoucherType.BET]: 'betCredit',
	[VoucherType.REBATE]: 'rebateCredit',
	[VoucherType.TURNOVER]: 'tryPlayCredit'
}

export const amountLeastKeyByBet = {
	[VoucherType.BET]: undefined,
	[VoucherType.REBATE]: 'rebateLeastBetCredit',
	[VoucherType.TURNOVER]: 'tryPlayLeastBetCredit'
}

export const formConfig: VxeGridPropTypes.FormConfig = {
	span: 3,
	rules: {
		// voucherName: [
		// 	{
		// 		required: true,
		// 		message: 'table.Required'
		// 	}
		// ]
	},
	items: [
		{
			field: 'productList',
			title: 'table.Product',
			itemRender: {
				name: '$elSelect',
				options: mapEnumToOptions(Product, { encloseValue: true }),
				props: {
					multiple: true,
					maxCollapseTags: 2
				}
			},
			span: 5
		},
		{
			field: 'gamePlatformList',
			title: 'table.GamePlatform',
			itemRender: {
				name: '$elSelect',
				options: commonStore.platforms,
				props: {
					multiple: true,
					filterable: true
				}
			}
		},
		{
			field: 'voucherName',
			title: 'table.VoucherName',
			itemRender: { name: '$elInput' }
		},
		{
			field: 'createBy',
			title: 'table.CreatedBy',
			itemRender: { name: '$elInput' }
		},
		{
			field: 'auditor',
			title: 'table.Auditor',
			itemRender: { name: '$elInput' }
		},
		{
			field: 'voucherTypes',
			title: 'table.VoucherType',
			itemRender: {
				name: '$elSelect',
				// options: mapEnumToOptions(VoucherType), TODO - Phase 2 enable other types
				options: [{ value: VoucherType.REBATE, label: 'Rebate' }],
				props: {
					modelValue: VoucherType.REBATE,
					noHeader: true,
					disabled: true,
					multiple: false // TODO - Phase 2 - Set to true
				}
			}
		},
		{
			field: 'voucherStatus',
			title: 'table.VoucherStatus',
			itemRender: {
				name: '$elSelect',
				options: mapEnumToOptions(VoucherStatus),
				props: {
					noHeader: true
				}
			}
		},

		// {
		// 	itemRender: {
		// 		name: '$spacer'
		// 	},
		// 	span: 4
		// },
		{
			field: 'createdAt',
			title: 'table.CreateTime',
			itemRender: {
				name: '$elDateRange',
				props: { startKey: 'createStartTime', endKey: 'createEndTime' }
			},
			span: 5
		},
		{
			field: 'updateAt',
			title: 'table.UpdateTime',
			itemRender: {
				name: '$elDateRange',
				props: { startKey: 'updateStartTime', endKey: 'updateEndTime' }
			},
			span: 5
		},
		{
			field: 'auditStatus',
			title: 'table.AuditStatus',
			itemRender: {
				name: '$elSelect',
				options: mapEnumToOptions(AuditStatus),
				props: {
					multiple: true,
					maxCollapseTags: 3
				}
			},
			span: 4
		},
		{
			span: 3,
			title: ' ',
			align: 'center',
			itemRender: {
				name: '$buttons',
				children: [
					{
						props: {
							type: 'submit',
							content: 'table.Search',
							status: 'primary',
							icon: 'vxe-icon-search'
						}
					},
					{ props: { type: 'reset', content: 'table.Reset' } }
				]
			}
		}
	]
}

export const columns: VxeGridPropTypes.Columns<Voucher> = [
	// { type: 'seq', width: 60, align: 'center' },
	// { type: 'checkbox', width: 60, align: 'center' },
	{ field: 'voucherId', title: 'ID', width: 185, align: 'right', headerAlign: 'center' },
	{ field: 'voucherName', title: 'table.VoucherName', width: 150 },
	{
		field: 'products',
		title: 'table.Product',
		formatter: ['$optionFormatter', mapEnumToOptions(Product, {}, undefined, true)],
		cellRender: {
			name: '$elTag',
			props: {
				optionTagStyles: ['', 'warning', 'success', 'danger']
			}
		},
		width: 180
	},
	{
		field: 'amount',
		title: 'table.Amount',
		align: 'right',
		headerAlign: 'center',
		formatter({ row }: { row: Voucher }) {
			const key = amountKeyByBet[row.voucherType as VoucherType] as
				| 'betCredit'
				| 'tryPlayCredit'
				| 'rebateCredit'
			return row[key] || 0
		}
	},
	{
		field: 'voucherType',
		title: 'table.VoucherType',
		align: 'center',
		formatter: ['$optionFormatter', mapEnumToOptions(VoucherType)]
		// cellRender: {
		// 	name: '$elTag',
		// 	props: {
		// 		optionTagStyles: ['warning', 'success', 'danger']
		// 	}
		// }
	},
	// {
	// 	title: 'table.GameScope',
	// 	align: 'center',
	// 	children: [
	// 		{ field: 'scope.gamePlatform.name', title: 'table.GamePlatform' },
	// 		{ field: 'scope.gameKind.name', title: 'table.GameType' },
	// 		{ field: 'scope.gameName.name', title: 'table.GameName' }
	// 	]
	// },
	{ field: 'gamePlatforms', title: 'table.GameScope' },
	{ field: 'createBy', title: 'table.CreatedBy' },
	{ field: 'createTime', title: 'table.CreateTime', minWidth: 40, formatter: '$timeFormatter' },
	{
		field: 'endTime',
		title: 'table.ExpirationTime',
		minWidth: 40,
		formatter: '$timeFormatter'
	},
	{ field: 'auditor', title: 'table.Auditor' },
	{
		field: 'auditStatus',
		title: 'table.AuditStatus',
		align: 'center',
		formatter: ['$optionFormatter', mapEnumToOptions(AuditStatus)],
		cellRender: {
			name: '$elText',
			props: {
				optionTagStyles: ['warning', 'success', 'danger']
			}
		}
	},
	{ field: 'updateTime', title: 'table.UpdateTime', minWidth: 40, formatter: '$timeFormatter' },
	{
		field: 'voucherStatus',
		title: 'table.VoucherStatus',
		align: 'center',
		cellRender: {
			name: '$elTag',
			props: {
				optionTagStyles: ['danger', 'success']
			}
		},
		formatter: ['$optionFormatter', mapEnumToOptions(VoucherStatus)],
		width: 110
	},
	{
		field: 'operations',
		title: 'table.Operations',
		align: 'center',
		fixed: 'right',
		width: 200,
		slots: { default: 'operations' }
	}
]
