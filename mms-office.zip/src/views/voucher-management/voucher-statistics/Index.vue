<template>
	<el-row :gutter="12" class="mb-2">
		<el-col :span="4" v-for="(summary, index) in statistics" :key="`summary-${index}`">
			<el-card shadow="always">
				<div class="text-center">
					<el-statistic
						:suffix="summary.suffix"
						group-separator=","
						:precision="2"
						:value="summary.value"
						:title="$t(summary.title)"></el-statistic>
				</div>
			</el-card>
		</el-col>
	</el-row>

	<vxe-grid ref="xGrid" v-bind="gridOptions">
		<template #slot_export>
			<el-button size="small" :icon="Download" :loading="isDownloading" @click="download">
				Download Report
			</el-button>
		</template>
		<template #voucherConfigName="{ data }">
			<el-select
				v-model="data.voucherNameConfigId"
				filterable
				remote
				reserve-keyword
				clearable
				placeholder="请输入"
				:remote-method="fetchVouchers"
				:loading="vOption.loading">
				<el-option
					v-for="item in vOption.data"
					:key="item.value"
					:label="item.label"
					:value="item.value" />
			</el-select>
		</template>
		<template #activityConfigName="{ data }">
			<el-select
				v-model="data.activityNameConfigId"
				filterable
				remote
				clearable
				reserve-keyword
				placeholder="请输入"
				:remote-method="fetchActivity"
				:loading="aOption.loading">
				<el-option
					v-for="item in aOption.data"
					:key="item.value"
					:label="item.label"
					:value="item.value" />
			</el-select>
		</template>
	</vxe-grid>
</template>

<script setup lang="ts" name="VoucherStatistics">
import { report } from '@/api/report'
import { columns, formConfig } from './options'
import { VoucherSummary, type VoucherStatistics } from '@/views/voucher-management/types'
import { Download } from '@element-plus/icons-vue'
import { VxeGridInstance } from 'vxe-table'
const { options: vOption, fetchVouchers } = useReportVoucherOptions()
const { options: aOption, fetchActivity } = useActivityOptions()
const isDownloading = ref(false)
const xGrid = ref({} as VxeGridInstance)
const download = () => {
	isDownloading.value = true
	const { formData: form, tablePage: page } = xGrid.value.reactData
	const params = {
		pageIndex: page.currentPage,
		pageSize: page.pageSize,
		...form,
		claimedTime: undefined,
		createTime: undefined,
		usedTime: undefined
	}
	report
		.excelDownload(params)
		.then((el) => {
			console.log(el)
		})
		.finally(() => {
			isDownloading.value = false
		})
}
const statistics = shallowRef<VoucherSummary[]>([])
const queryStatistics = (params: any) => {
	report.statistics(params).then((res: any) => {
		const data = res.result
		statistics.value = [
			{ title: 'Total Amount', value: data.totalAmount || 0 },
			{ title: 'Claimed Amount', value: data.claimedAmount || 0 },
			{ title: 'Claimed Ratio', value: data.claimedRate || 0, suffix: '%' },
			{ title: 'Used Amount', value: data.usedAmount || 0 },
			{ title: 'Used Ratio', value: data.usedRate || 0, suffix: '%' },
			{ title: 'Expired Amount', value: data.expiredAmount || 0 }
		]
	})
}

const gridOptions = reactive<VxeGridProps<VoucherStatistics>>({
	id: 'voucher-statistics',
	columns,
	filterConfig: {
		remote: true
	},
	formConfig,
	toolbarConfig: {
		enabled: true,
		refresh: false,
		export: false,
		slots: {
			tools: 'slot_export'
		}
	},
	pagerConfig: {
		enabled: true
	},
	exportConfig: {
		// 导出配置项
		remote: true
	},
	proxyConfig: {
		form: true,
		filter: true,
		props: {
			result: 'records',
			total: 'total'
		},
		ajax: {
			query: ({ page, form, filters, sorts }) => {
				console.log('form --->', form)
				console.log('filters--->', filters)
				console.log('sorts--->', sorts)

				const params = {
					pageIndex: page.currentPage,
					pageSize: page.pageSize,
					...form,
					claimedTime: undefined,
					createTime: undefined,
					usedTime: undefined
				}
				queryStatistics(params)
				return report.list(params).then((res: any) => {
					return res.result
				})
				// return getList(page.currentPage, page.pageSize, form, listDataVO)
			}
		}
	}
})
</script>
