import { VoucherDistributionStatus, type VoucherStatistics } from '@/views/voucher-management/types'
import { VxeGridPropTypes } from 'vxe-table'
import { Product, VoucherType } from '~/types'

const productList = mapEnumToOptions(Product, { encloseValue: true })

export const formConfig: VxeGridPropTypes.FormConfig = {
	items: [
		{
			field: 'product',
			title: 'table.Product',
			itemRender: {
				name: '$elSelect',
				options: productList,
				props: {
					clearable: true,
					multiple: true
				}
			},
			span: 3
		},
		{
			field: 'voucherConfigId',
			title: 'ID',
			itemRender: { name: '$elInput' }
		},
		{
			field: 'voucherConfigName',
			title: 'table.VoucherName',
			// itemRender: { name: '$input' }
			itemRender: {},
			slots: { default: 'voucherConfigName' }
		},
		{
			field: 'activityConfigName',
			title: 'table.EventName',
			slots: { default: 'activityConfigName' }
		},
		{
			field: 'voucherType',
			title: 'table.VoucherType',
			itemRender: {
				name: '$elSelect',
				// options: mapEnumToOptions(VoucherType), TODO - Phase 2 enable other types
				options: [{ value: VoucherType.REBATE, label: 'Rebate' }],
				props: {
					modelValue: VoucherType.REBATE,
					noHeader: true,
					disabled: true,
					multiple: false // TODO - Phase 2 - Set to true
				}
			}
		},

		{
			field: 'account',
			title: 'table.Account',
			itemRender: { name: '$elInput' }
		},
		{
			field: 'billNo',
			title: 'table.BillNumber',
			itemRender: { name: '$elInput' }
		},
		{
			field: 'voucherStatus',
			title: 'table.VoucherDistributionStatus',
			itemRender: {
				name: '$elSelect',
				options: mapEnumToOptions(VoucherDistributionStatus),
				props: {
					multiple: true,
					clearable: true,
					maxCollapseTags: 2
				}
			}
		},
		{
			field: 'createTime',
			title: 'table.DistributionTime',
			itemRender: {
				name: '$elDateRange',
				props: {
					startKey: 'createStartTime',
					endKey: 'createEndTime'
				}
			},
			span: 5
		},
		{
			field: 'claimedTime',
			title: 'table.ReceptionTime',
			itemRender: {
				name: '$elDateRange',
				props: {
					startKey: 'claimedStartTime',
					endKey: 'claimedEndTime'
				}
			},
			span: 5
		},
		{
			field: 'usedTime',
			title: 'table.SettlementTime',
			itemRender: {
				name: '$elDateRange',
				props: {
					startKey: 'usedStartTime',
					endKey: 'usedEndTime'
				}
			},
			span: 5
		},
		{
			span: 3,
			title: ' ',
			align: 'center',
			itemRender: {
				name: '$buttons',
				children: [
					{
						props: {
							type: 'submit',
							content: 'table.Search',
							status: 'primary',
							icon: 'vxe-icon-search'
						}
					},
					{ props: { type: 'reset', content: 'table.Reset' } }
				]
			}
		}
	]
}

export const columns: VxeGridPropTypes.Columns<VoucherStatistics> = [
	{ field: 'voucherConfigId', title: 'ID', width: 150, align: 'center' },
	{
		field: 'voucherConfigName',
		title: 'table.VoucherName',
		showOverflow: 'tooltip',
		minWidth: 150
	},
	{
		field: 'voucherType',
		title: 'table.VoucherType',
		width: 100,
		align: 'center',
		showOverflow: 'tooltip'
	},
	{ field: 'amount', title: 'table.Amount', align: 'right', headerAlign: 'center', width: 150 },
	{
		field: 'activityConfigName',
		title: 'table.EventName',
		showOverflow: 'tooltip',
		minWidth: 120
	},
	{
		field: 'voucherStatus',
		title: 'table.VoucherDistributionStatus',
		align: 'center',
		cellRender: {
			name: '$elText',
			props: {
				optionTagStyles: ['danger', 'success']
			}
		},
		formatter: ['$optionFormatter', mapEnumToOptions(VoucherDistributionStatus)],
		width: 130
	},
	{ field: 'account', title: 'table.Account', width: 120, align: 'center' },
	{ field: 'createTime', title: 'table.DistributionTime', width: 160 },
	{ field: 'claimedTime', title: 'table.ReceptionTime', width: 160 },
	{ field: 'usedTime', title: 'table.SettlementTime', width: 160 },
	{ field: 'expireTime', title: 'table.ExpirationTime', width: 160 },
	{
		field: 'billNoList',
		title: 'table.BillNumber',
		fixed: 'right',
		width: 160,
		showOverflow: false,
		formatter: ({ cellValue }) => {
			if (cellValue && cellValue.length) {
				return cellValue.join(', ')
			} else {
				return '--'
			}
		}
	}
]
