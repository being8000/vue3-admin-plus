import { VoucherSummary } from '@/views/voucher-management/types'

export const voucherSummaryVO: VoucherSummary[] = [
	{ title: 'Total Amount', value: 10000 },
	{ title: 'Claimed Amount', value: 980000 },
	{ title: 'Claimed Ratio', value: 10, suffix: '%' },
	{ title: 'Used Amount', value: 1800000 },
	{ title: 'Used Ratio', value: 10, suffix: '%' },
	{ title: 'Expired Amount', value: 1800000 }
]
