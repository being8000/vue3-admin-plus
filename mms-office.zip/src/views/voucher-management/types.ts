import { DateModelType } from 'element-plus'
import { AuditStatus, MktBaseData, MktBaseForm, Product, VoucherType, WithTemp } from '~/types'

export type VoucherSummary = {
	title: string
	value: any
	suffix?: string
}

// 优惠分状态
export enum VoucherStatus {
	SUSPENDED = 'disable',
	NORMAL = 'enable'
}

// 优惠分发放状态
export enum VoucherDistributionStatus {
	SENT = 'Sent',
	CLAIMED = 'Claimed',
	USED = 'Used',
	EXPIRED = 'Expired'
}

export type VoucherStatistics = MktBaseData & {
	activityConfigName: string // 活动名称
	voucherConfigName: string // 优惠分名称
	voucherConfigId: string // 优惠分编号
	voucherType: VoucherType // 优惠分类型,示例值(Bet)
	voucherStatus: VoucherStatus // 优惠分状态,示例值(Sent)
	account: string // 用户
	amount: string | number // 数量
	createTime: Date | string // distributionTime 提案创建时间
	claimedTime: Date | string // receptionTime 领取时间
	usedTime: Date | string // settlementTime 结算时间
	expireTime: Date | string // expirationTime 过期时间
	billNo: string | number // 注单号
	billNoList: any[]
}

/**
 * @interface Voucher
 * @description 优惠分 | Voucher Record
 * @example
 * {
        "id": 0,
        "voucherId": "string",
        "voucherName": "string",
        "voucherDesc": "string",
        "startTime": "2024-04-19T03:00:06.894Z",
        "endTime": "2024-04-19T03:00:06.894Z",
        "auditStatus": "string",
        "efficientStatus": "string",
        "lastAuditId": "string",
        "voucherType": "string",
        "betCredit": 0,
        "tryPlayCredit": 0,
        "tryPlayLeastBetCredit": 0,
        "rebateCredit": 0,
        "rebateLeastBetCredit": 0,
        "createTime": "2024-04-19T03:00:06.894Z",
        "updateTime": "2024-04-19T03:00:06.894Z",
        "createBy": "string",
        "updateBy": "string",
        "auditor": "string",
        "version": 0,
        "products": "string",
        "tenant": "string",
        "gamePlatforms": "string",
        "platformId": "string"
      }
 */
export type Voucher = MktBaseData & {
	voucherId: string | number
	voucherName: string
	voucherDesc: string
	startTime: string | number | Date
	endTime: string | number | Date
	auditStatus: AuditStatus
	voucherStatus: VoucherStatus
	lastAuditId: number | string
	voucherType: string
	auditor: string
	products: string
	tenant: string
	platformId: string
	gamePlatforms?: string | []
	productList: Product | Product[]
	/** Voucher amount - Depends on the voucherType */
	amount: number
	betCredit?: Voucher['amount']
	tryPlayCredit?: Voucher['amount']
	rebateCredit?: Voucher['amount']
	rebateLeastBetCredit?: Voucher['amount']
	tryPlayLeastBetCredit?: Voucher['amount']
	version?: number
} & WithTemp

export type VoucherDetails = Pick<
	Voucher,
	'voucherName' | 'voucherType' | 'version' | 'id' | 'voucherStatus'
> & {
	voucherId?: string | number
	betCredit?: Voucher['amount']
	tryPlayCredit?: Voucher['amount']
	rebateCredit?: Voucher['amount']
	rebateLeastBetCredit?: Voucher['amount']
	tryPlayLeastBetCredit?: Voucher['amount']
	expiryTime: string | number | Date | [DateModelType, DateModelType] | [string, string]
	startTime: string | number | Date
	endTime: string | number | Date
	gamePlatformList: [] | string
	productList?: string | Product[]
	products: string
	creator: string
	updateBy: string
	versionId: Voucher['version']
} & WithTemp
export class VoucherFormVO extends MktBaseForm {
	id?: VoucherDetails['id']
	voucherId: VoucherDetails['voucherId']
	voucherName?: VoucherDetails['voucherName']
	voucherType?: VoucherDetails['voucherType']
	productList: VoucherDetails['productList']
	betCredit: VoucherDetails['betCredit']
	tryPlayCredit: VoucherDetails['tryPlayCredit']
	rebateCredit: VoucherDetails['rebateCredit']
	rebateLeastBetCredit: VoucherDetails['rebateLeastBetCredit']
	tryPlayLeastBetCredit: VoucherDetails['tryPlayLeastBetCredit']
	gamePlatformList?: VoucherDetails['gamePlatformList']
	creator: VoucherDetails['creator']
	updateBy: VoucherDetails['updateBy']
	startTime?: VoucherDetails['startTime']
	endTime?: VoucherDetails['endTime']
	voucherStatus?: VoucherDetails['voucherStatus']
	versionId: VoucherDetails['version']
	products: any
	gamePlatforms: any

	// Temp data
	expiryTime: string | number | Date | [DateModelType, DateModelType] | [string, string]

	constructor(voucher: Record<any, any>) {
		super()

		if (voucher.id) {
			this.id = voucher.id
			this.voucherId = voucher.voucherId
			this.voucherStatus = voucher.voucherStatus
		}
		this.versionId = voucher.versionId || voucher.version || undefined

		this.startTime = voucher.startTime
		this.endTime = voucher.endTime
		this.voucherName = voucher.voucherName
		this.voucherType = voucher.voucherType
		this.productList =
			voucher.products && !voucher.productList
				? (voucher.products.split(',') as Product[])
				: voucher.productList
		this.products = undefined
		this.gamePlatformList =
			voucher.gamePlatforms && !voucher.gamePlatformList
				? voucher.gamePlatforms.split(',')
				: voucher.gamePlatformList
		this.gamePlatforms = undefined

		this.betCredit = voucher.betCredit || undefined
		this.tryPlayCredit = voucher.tryPlayCredit || undefined
		this.rebateCredit = voucher.rebateCredit || undefined
		this.rebateLeastBetCredit = voucher.rebateLeastBetCredit || undefined
		this.tryPlayLeastBetCredit = voucher.tryPlayLeastBetCredit || undefined

		this.creator = voucher.creator || 'roger'
		this.updateBy = voucher.updateBy || 'roger'
		this.expiryTime = [voucher.startTime, voucher.endTime]
	}
}
