type GoogleBindInfo = {
	loginName?: string | null
}

type RequestData = Record<any, any>

export const getGoogleBindInfo = (data: GoogleBindInfo) => {
	const url = `/office/user/queryGoogleAuthBindInfo`
	return request({
		url,
		method: 'post',
		data
	})
}

export const userLogin = (data: RequestData) => {
	const url = `/office/user/login`
	return request({
		url,
		method: 'post',
		data
	})
}

export const createGoogleAuthKey = (data: RequestData) => {
	const url = '/office/user/createGoogleAuthKey'

	return request({
		url,
		method: 'post',
		data
	})
}
