<template>
	<div class="login-container">
		<main>
			<div class="login-header">
				<img class="logo" src="@/assets/logo.png" alt="DigiPlus" />
				<!-- TODO: <p class="title">{{ website.title }}</p> -->
				<p class="title">DigiPlus Admin Office</p>
			</div>
			<el-form
				ref="loginFormRef"
				class="login-form"
				status-icon
				:rules="loginRules"
				:model="loginForm"
				label-position="top"
				autocomplete="off">
				<el-form-item label="Username" prop="username">
					<el-input
						size="large"
						v-model="loginForm.username"
						autocomplete="off"
						placeholder="请输入用户名"
						@keyup.enter="handleLogin">
						<template #prefix>
							<i class="icon-yonghu"></i>
						</template>
					</el-input>
				</el-form-item>

				<el-form-item label="Password" prop="password">
					<el-input
						v-model="loginForm.password"
						size="large"
						type="password"
						autocomplete="off"
						show-password
						placeholder="请输入密码"
						@keyup.enter="handleLogin">
						<template #prefix>
							<i class="icon-mima"></i>
						</template>
					</el-input>
				</el-form-item>

				<!-- <el-form-item prop="code">
					<el-input
						v-model="loginForm.code"
						:maxlength="code.len"
						auto-complete="off"
						placeholder="请输入验证码"
						@keyup.enter.native="handleLogin">
						<template #prefix>
							<i class="icon-yanzhengma"></i>
						</template>
						<template #append>
							<div class="login-code">
								<span
									v-if="code.type === 'text'"
									class="login-code-img"
									@click="refreshCode">
									{{ code.value }}
								</span>
								<img v-else :src="code.src" class="login-code-img" @click="refreshCode" />
							</div>
						</template>
					</el-input>
				</el-form-item> -->

				<el-form-item>
					<el-button
						type="primary"
						size="large"
						class="login-submit"
						@click.prevent="handleLogin"
						:loading="isLoading">
						{{ $t('Login') }}
					</el-button>
				</el-form-item>
			</el-form>

			<div class="login-footer">
				<!-- TODO: <p>{{ website.version }}</p> -->
				<p>v2.0.0</p>
			</div>
		</main>
	</div>
</template>

<script lang="ts" setup name="login">
import { useUserStore } from '@/stores'
import type { FormInstance } from 'element-plus'

const userStore = useUserStore()
const router = useRouter()

const isLoading = ref<boolean>(false)

const loginFormRef = ref<FormInstance>()

type ILoginForm = {
	username: string | null
	password: string | null
	googleAuthOtp: string | null
}

const loginForm: ILoginForm = reactive({
	username: 'chris',
	password: 'a123456',
	googleAuthOtp: null
})

const loginRules: Record<string, Record<string, any>> = {
	username: [{ required: true, message: 'Please enter username', trigger: 'blur' }],
	password: [{ required: true, message: 'Please enter password', trigger: 'blur' }]
}

const handleLogin = (): void => {
	loginFormRef.value?.validate((valid: boolean) => {
		if (valid) {
			isLoading.value = true
			/*
				TODO: Implement login logic
			*/

			const payload = {
				...loginForm
			}

			userStore
				.login(payload)
				.then(() => {
					try {
						elMessage('Logged in successfully', 'success')

						if (getItem('returnUrl')) {
							router.replace(getItem('returnUrl')).then(() => {
								deleteItem('returnUrl')
							})
						} else {
							router.push({ name: 'dashboard', replace: true })
						}
					} catch (e) {
						console.log(e)
					}
				})
				.finally(() => {
					setTimeout(() => {
						isLoading.value = true
					}, 300)
				})
		} else {
			return false
		}
	})
}

onMounted(() => {
	// refreshCode()
})
</script>

<style lang="scss" scoped>
.login {
	&-container {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		position: relative;
		display: flex;
		width: 100%;
		height: 100%;
		// background-color: #fff;

		main {
			display: flex;
			width: 400px;
			flex-direction: column;
			align-items: stretch;
			flex-wrap: nowrap;

			div {
				align-self: center;
			}
		}
	}

	&-header {
		text-align: center;
	}

	&-submit {
		margin: auto;
		width: 100%;
	}
}
</style>
