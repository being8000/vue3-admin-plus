import { App } from 'vue'
import router from '@/router'
import { createPinia } from 'pinia'
import { i18n } from '@/lang'
import { useVxeTable } from '@/plugins/vxe-table'
import { useElementPlus } from '@/plugins/element-plus'
import moment from 'moment'

export default function setupPlugins(app: App) {
	/**
	 * 3rd party plugins
	 *
	 * Add third-party plugins here
	 *
	 */

	const pinia = createPinia()
	app.use(pinia)

	// Update vue-i18n's locale whenever the Pinia store's language changes
	const commonStore = useCommonStore()
	commonStore.$subscribe((_mutation: any, state: { language: any }) => {
		i18n.global.locale.value = state.language
	})

	app.use(i18n)

	app.use(router)

	app.use(useElementPlus)

	app.use(useVxeTable)

	/**
	 * Global Properties
	 * Filters
	 */

	app.config.globalProperties.$moment = moment
	app.config.globalProperties.$filters = {
		toMoney(value: string | number, decimal?: boolean) {
			return '₱' + (decimal ? parseFloat(value.toString()) : Number(value))
		},
		toDate(value: string | Date, format: string = 'YYYY-MM-DD HH:mm:ss') {
			try {
				return moment(value).format(format)
			} catch (e) {
				return 'Invalid date'
			}
		}
	}
}
