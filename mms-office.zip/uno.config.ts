import {
	defineConfig,
	presetTypography,
	presetUno,
	presetWebFonts,
	transformerDirectives,
	transformerVariantGroup
} from 'unocss'

export default defineConfig({
	shortcuts: [
		// ...
	],
	theme: {
		colors: {
			primary: '#441b7d'
		}
	},
	presets: [
		presetUno(),
		presetTypography(),
		presetWebFonts({
			provider: 'google',
			fonts: {
				'Plus Jakarta Sans': 'Plus Jakarta Sans'
			}
		})
	],
	transformers: [transformerDirectives(), transformerVariantGroup()]
})
