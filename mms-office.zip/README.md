# Marketing (营销) office

# Frontend Admin Boilerplate

This repository uses:

-   Vue 3
-   TypeScript
-   Vite
-   Pinia
-   Vxetable

<br/>

# Table of Contents

1. [Environment Setup](#setup-local-environment)

2. [Coding Standards](#coding-standards)

    - [Naming conventions](#naming-conventions)

3. [Registering Global Components](#registering-global-components)

4. [Registering Plugins](#registering-plugins)

5. [How to Add and Use Icons](#how-to-add-and-use-icons)

6. [How to Add Translations (i18n)](#how-to-add-translations-i18n)

7. [Project Structure Guidelines](#project-structure-guidelines)

8. [Build and Preview Test Environments](#build-and-preview-test-environment)
    - [FAT](#i-fat)
    - [UAT](#ii-uat)
    - [PROD](#iii-build-for-prod)
9. [Deployment Guidelines for VueRouter `history` mode](#deployment-guidelines)
    - [nginx](#nginx)
    - [Apache](#apache)

<br/>

## Setup Local Environment

1.  Prerequisites
    -   Node >= 18
    -   [**Vue - Official: Language Support for Vue (VOLAR)**](https://marketplace.visualstudio.com/items?itemName=Vue.volar) VSCode Extension
    -   If using Vue Devtools, install version >= `6.6.1`
2.  **IMPORTANT!!!** : Disable or uninstall **Vetur**, and other **Volar** extensions
3.  Run `cp .env.example .env.local` or manually create a .env.local file and copy .env.example contents.
4.  Install dependencies
    ```
    npm ci
    ```
    NOTE: Do not use `npm i` if there is package-lock. If you didn't add any package/plugin, do not commit package-lock
5.  Run your local server

    ```
    npm run dev
    ```

    <br/>

## Coding Standards

-   #### Naming conventions:

    -   Use `camelCase` for variables, functions, and methods. For constants, use `UPPER_SNAKE_CASE`.
    -   Component file names should be in `PascalCase`
    -   Use `PascalCase` for TypeScript types and interfaces. Prefix interfaces with `I`
    -   When defining **props** and **emits**:

        -   A. Within the component's script, use `camelCase`

            -   **In TypeScript:**

                ```
                interface IUserProps {                          <--- Interface name prefix with I
                    userProfile: {
                        name: string
                        age: number
                    },
                    userName: string
                }

                const props = withDefaults(defineProps<IUserProps>(), {
                    userProfile: () => ({                                   <--- props
                        name: '',
                        age: 0
                    }),
                    userName: ''                                            <--- props
                })

                const emits = defineEmits(['updateProfile'])
                ```

            -   **or in standard syntax:**

                ```
                const props = defineProps({
                    userProfile:{
                        type: Object,
                        required: true,
                        default: () => ({
                            name: '',
                            age: 0
                        })
                    }
                })

                const emits = defineEmits(['updateProfile'])
                ```

        -   B. In templates (HTML), use `kebab-case`

            ```
            <UserProfile :user-profile="userData" @update-profile="handleProfileUpdate"/>
            ```

    -   Prefix functions with verbs, e.g., `fetchData`, `updateUser`, etc.
    -   Use nouns for reactive states and references, e.g., `userData`, `isLoading`, etc.
    -   For computed properties, consider prefixes like computed or calculated, or use adjectives that describe the state, e.g.) `formattedName`, `computedAverage`, `isEditable`, `sortedList`.

-   Use `type` by default until you need a specific feature of interfaces, like `extends`. `interface` should generally be used when declaration merging is necessary.
-   Wherever possible, explicitly define return types for functions to enhance readability and type checking. Use TypeScript's utility types (like `Record`, `Partial`, etc.) for more complex types. [Check TS utility types here](https://www.typescriptlang.org/docs/handbook/utility-types.html)

-   Avoid `any`. Minimize the use of the `any` type to enforce type safety. Use more specific types or generics.

-   Organize by functionality. Group related reactive states, computed properties, and functions together. You may separate these groups with comments or split them into different composables.
-   Use comments to document your code, especially for complex functions or reactive states that might not be immediately obvious to someone else (or to you when you come back to it in the future).

-   For complex logic or when the function's purpose isn't immediately clear, you may use **JSDoc** to document functions and their parameters.

-   Do not mix unrelated businesses/modules together.

-   Do not oversimplify or excessively split components and functions. Always prioritize maintainability.

-   Segment large modules with `<!------ Some comment ------>` to distinguish where a module starts and/or ends.

-   Always indent with proper spacing and add line break in between components/properties/objects for better code readability.

    -   #### In HTML

        ```
        <template>
            <el-form class="page-one-form quite-large-module">
                <el-form-item>
                    <el-input></el-input>
                </el-form-item>
                                                    <--- Line break
                <el-form-item>
                    <el-input></el-input>
                </el-form-item>
                                                    <--- Line break
                <el-form-item>
                    <el-input></el-input>
                </el-form-item>

                ...
                ...
            </el-form>

            <!---------- A SEGMENT TO BREAK RELATIVELY LARGE MODULES ---------->

            <el-form class="page-two-form another-large-module">
                ...
                ...
            </el-form>
        </tempalte>
        ```

    -   #### In stylesheets

        ```
        #element-id {
            ...
            ...
                            <--- Line break
            .lorem-ipsum {
                ...
            }
        }
                            <--- Line break
        .class-name-1 {
            ...
        }
        ```

    -   #### In script files

        ```
        import { moduleName } from '@/some/path'
        import type { FormInstance } from 'element-plus'
                                                            <--- Line break
        const someStore = useSomeStore()
        const anotherStore = useAnotherStore()
                                                            <--- Line break
        const formRef = ref<FormInstance>()
        const username = ref<string>('')
        const isLoading = ref<boolean>(false)
        ```

-   Always define the component's `name`
    #### Defining in `<script setup>` tag
    -   https://github.com/chenxch/unplugin-vue-setup-extend-plus
    ```
    <script setup lang="ts" name="HelloWorld">
        ...
    </script>
    ```
    #### Using `defineOptions` macro
    ```
    <script setup>
        ...
        defineOptions({
            name: 'HelloWorld',
            ...
        })
        ...
    </script>
    ```
-   By default, use arrow functions `() => {}`
    ```
    const incrementCounter = (): void => {
        ...
    }
    ```
-   In very large modules that has a lot of code, to better distinguish between variables and functions, define `functions` on regular syntax whenever applicable

    ```
        const counter = 'helloWorld'
        const anotherCounter = 'anotherWorld'

        function incrementCounter() {
            ...
        }
    ```

<br/>

## Registering Global Components

All global components should be registered in `./src/global-components.ts`, **NOT** in `main.ts`

-   `import componentName from '@/path/componentName.vue'`

-   register `app.component('ComponentName', componentName)`

<br/>

## Registering Plugins

All plugins should be added in `./src/plugins.ts`, **NOT** in `main.ts`

-   Follow the plugin's documentation for installation or implementation instructions

<br/>

## How to Add and Use Icons

Icons are already setup for auto import in `vite.config.ts`, no need to manually import them.

Icons sets readily available in this boilerplate are:

-   Element Plus
    -   https://element-plus.org/en-US/component/icon.html
    -   prefix: `ep`
-   Weather Icons
    -   https://erikflowers.github.io/weather-icons/
    -   prefix: `wi`
-   Tabler Icons:
    -   https://tabler.io/icons
    -   prefix: `tabler`

_To add more icon sets_

1. https://github.com/iconify/icon-sets/blob/HEAD/collections.md
2. Run `npm i -D @iconify-json/[icon set prefix]`
3. Add icon prefix in `vite.config.ts`, both in `AutoImport` and `Components`
    ```
    ...
    IconsResolver({
        prefix: 'icon',
        enabledCollections: ['ep', 'tabler', '<new icon prefix>']
    })
    ```

To use an icon `icon-{collection-prefix}-{icon-name}`

Example:

```
<el-icon>
    <icon-tabler-menu2/>
</el-icon>
```

### In router

1.  `import IconTablerLayoutDashboard from '~icons/tabler/layout-dashboard'` - ~/icons/`[collection-prefix]`/`[icon-name]`, it will automatically resolve

        Example:
        ```
        import IconTablerLayoutDashboard from '~icons/tabler/layout-dashboard'
        import IconMenu from '~icons/ep/menu'

        {
            name: 'dashboard',
            path: '/dashboard',
            component: () => import('@/views/Dashboard.vue'),
            meta: {
                title: 'Dashboard',
                icon: IconTablerLayoutDashboard
            }
        },
        ```

    <br/>

## How to Add Translations (i18n)

-   You may add translations at `./src/lang`

-   Ways to use:

    -   ### Using `useI18n()` function

        ```
        <template>
            <p>{{ t('key.name') }}</p>
        </template>
        ```

        ```
        <script setup>
        const { t } = useI18n()

        onMounted(() => console.log(t('key.name')))
        </script>
        ```

    -   ### Or using `$t`

        Defined in `./types/shims-vue.d.ts`

        ```
        <template>
            <p>{{ $t('key.name') }}</p>
        </template>
        ```

    <br/>

-   Implementing translations for vxe-table columns and data
    -   In `./src/lang/en` (English)and `./src/lang/zh` (Chinese)
    ```
        ...
        table: {
            ...
            'Hello World': 'Hello World'
        }
    ```

## Project Structure Guidelines

-   Shared components or utils should be placed in the top level directory `src/components`, `src/composables`, `src/utils`, etc.

    ```
    src/components
        ├── HelloWorld.vue
        ├── AnotherComponent.vue
        ├── Dialogs
            ├── index.vue
            ├── component-script.ts
    ```

-   Split code to isolate functions accordingly. Coupled functions and variables should be divided into its relevant directory as much as possible. Example:
    ```
    ├──views
        ├── users
        │   ├── components  // 用于user领域的非路由Vue组件。
        │   │   ├── UserFormModal.vue
        │   │   ├── UserForm.vue
        │   │   └── ...
        │   ├── dts  // 用于user枚举、接口和类的TypeScript定义。
        │   │   ├── user.types.ts // user相关TypeScript类型的示例文件。
        │   │   ├── user.enums.ts  // user相关枚举的示例文件。
        │   │   └── ...
        │   ├── services  // 用于API调用和其他TypeScript文件的目录。
        │   │   ├── user.api.ts // 与user领域相关的API调用。
        │   │   ├── user.service.ts // 与user领域相关的更复杂的操作或业务逻辑。
        │   │   ├── user.options.ts // datatable/plugin options
        │   │   └── ...
        │   ├── index.vue // user领域的主页面或入口。
        │   ├── Details.vue // user的一个子页面，例如详细信息页面。
        │   └── README.md // 本文件包含user领域的文档，包括变更记录、相关需求票据、错误报告和使用指南。
    ```
-   When creating reusable shared components, documentation should be provided
    `src/components`

    ```
    ├── RandomCustomDialog
        ├── index.vue
        ├── component-script.ts
        └── README.md            <---- Custom component's documentation
    ```

<br/>

## Build and Preview Test Environment

-   ### I. FAT

    Enter necessary details in `.env.fat` file

    ```
    npm run dev:fat
    ```

    **Build and preview:**

    ```
    npm run build:fat

    npm run preview
    ```

-   ### II. UAT

    Enter necessary details in `.env.uat` file

    ```
    npm run dev:uat
    ```

    **Build and preview:**

    ```
    npm run build:uat

    npm run preview
    ```

-   ### III. Build for PROD

    Enter necessary details in `.env` or `.env.production` file

    ```
    npm run build
    ```

<br/>

## Deployment Guidelines

-   Server configuration for router mode `history`
-   https://router.vuejs.org/guide/essentials/history-mode.html#Example-Server-Configurations
-   Note: The following examples assume you are serving your app from the root folder. If you deploy to a subfolder, you should use the publicPath option of Vue CLI and the related base property of the router. You also need to adjust the examples below to use the subfolder instead of the root folder (e.g. replacing RewriteBase / with RewriteBase /name-of-your-subfolder/).

    ### nginx

    ```
        location / {
            try_files $uri $uri/ /index.html;
        }
    ```

    ### Apache

    ```
    <IfModule mod_negotiation.c>
        Options -MultiViews
    </IfModule>

    <IfModule mod_rewrite.c>
        RewriteEngine On
        RewriteBase /
        RewriteRule ^index\.html$ - [L]
        RewriteCond %{REQUEST_FILENAME} !-f
        RewriteCond %{REQUEST_FILENAME} !-d
        RewriteRule . /index.html [L]
    </IfModule>
    ```

<br/>
