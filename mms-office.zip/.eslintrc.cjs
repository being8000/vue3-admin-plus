/* eslint-env node */
require('@rushstack/eslint-patch/modern-module-resolution')

module.exports = {
	root: false,
	extends: [
		'plugin:vue/vue3-essential',
		'eslint:recommended',
		'@vue/eslint-config-typescript/recommended',
		'@vue/eslint-config-prettier',
		'./eslintrc/.eslintrc-auto-import.json'
	],
	env: {
		'vue/setup-compiler-macros': true
	},
	rules: {
		'comma-dangle': 'off',
		'@typescript-eslint/comma-dangle': 'off',
		'prettier/prettier': ['error', { endOfLine: 'crlf' }],
		'javascript.validate.enable': 0,
		'import/named': 'off',
		'no-undef': 'off',
		'@typescript-eslint/no-explicit-any': 'off',
		'@typescript-eslint/ban-types': 'off',
		'@typescript-eslint/no-unused-vars': 'off',
		'vue/multi-word-component-names': 'off',
		'no-duplicate-variable': 'true'
		// 'no-unused-variable': { severity: 'warning' }
	},
	parserOptions: {
		project: './tsconfig.json'
	}
}
