declare global {
	interface LabelValue {
		label: any
		value: any
	}

	interface ApiResponse<T = any> {
		errorCode: string
		errorMessage: string
		result: T
		success: boolean
	}
}
