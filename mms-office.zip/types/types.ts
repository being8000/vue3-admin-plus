import moment from 'moment'

export enum AuditStatus {
	PENDING = 'pending',
	APPROVED = 'approved',
	REJECTED = 'rejected'
}

export enum Product {
	PERYA_GAME = 'PG',
	ARENA_PLUS = 'AP',
	BINGO_PLUS = 'BP',
	GAME_PLUS = 'GP'
}

export enum VoucherType {
	BET = 'Bet', //TODO - 2nd phase enable
	TURNOVER = 'Turnover', //TODO - 2nd phase enable
	REBATE = 'Rebate'
}

export type GamePlatform = {
	platformId: string | number
	platformName: string
}

export type MktBaseData = {
	/**
	 * Base type representing base table data.
	 *
	 *
	 * @param id
	 * @param voucherName - description
	 * @param {string} eventName - description
	 * @param {string} account - description
	 *
	 * @example
	 * // Example of creating a proposal.
	 * const proposal: ProposalVO = {
	 * 	id: 10001,
	 * 	voucherName: 'CCCC',
	 * 	account: 'Account 1',
	 * 	product: Product.PERYA_GAME,
	 *  createdBy: 'Zoe',
	 *  createdAt: '2021-09-01 10:00:00',
	 * 	updatedAt: '2021-09-01 11:00:00',
	 * };
	 */
	id?: number | string
	account: string
	product?: Product
	createBy?: string
	createTime?: Date | string
	updateBy?: string
	updateTime?: Date | string
}

export class MktBaseForm {
	clean(filters: string[] = ['_temp']) {
		return filters.length ? omit(this, [...filters, '_temp']) : this
	}
}

export type WithTemp = {
	temp?: Record<any, any>
}

export type AuditRecord = {
	id: number | string
	auditId: string
	auditStatus: AuditStatus
	createBy: string
	auditor?: string
	createTime?: string | Date
	updateTime?: string | Date
}

export class AuditRecordVO {
	id: number | string
	auditId: string
	auditStatus: AuditStatus
	createBy: string
	auditor?: string
	createTime?: string | Date
	updateTime?: string | Date

	constructor(audit: AuditRecordVO) {
		this.id = audit.id
		this.auditId = audit.auditId
		this.auditStatus = audit.auditStatus
		this.createBy = audit.createBy
		this.auditor = audit.auditor
		this.createTime = moment(audit.createTime).format('YYYY-MM-DD HH:mm:ss')
		this.updateTime = moment(audit.updateTime).format('YYYY-MM-DD HH:mm:ss')
	}
}
