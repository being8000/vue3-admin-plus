import { ComponentCustomProperties } from 'vue'
import { VueI18n } from 'vue-i18n'
import type { mapEnumToOptions } from '@/composables/use-helpers'

declare module '@vue/runtime-core' {
	interface ComponentCustomProperties {
		$t: VueI18n['t']
		$moment
		$filters
		mapEnumToOptions
	}
}
