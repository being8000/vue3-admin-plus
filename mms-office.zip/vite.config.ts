import { defineConfig, loadEnv } from 'vite'

import { fileURLToPath, URL } from 'node:url'

import vue from '@vitejs/plugin-vue'
import Icons from 'unplugin-icons/vite'
import IconsResolver from 'unplugin-icons/resolver'
import AutoImport from 'unplugin-auto-import/vite'
import Components from 'unplugin-vue-components/vite'
import { ElementPlusResolver } from 'unplugin-vue-components/resolvers'
import { createStyleImportPlugin, VxeTableResolve } from 'vite-plugin-style-import'

import UnoCSS from 'unocss/vite'
import svgLoader from 'vite-svg-loader'

/**
 * Documentation: https://github.com/chenxch/unplugin-vue-setup-extend-plus
 * Enable support for component options such as name, inheritAttrs in the <script setup> script
 * eg.) <script setup name="componentName" inheritAttrs="false">
 **/
import vueSetupExtend from 'unplugin-vue-setup-extend-plus/vite'

const autoImportPlugin = AutoImport({
	imports: [
		'vue',
		'vue-router',
		'pinia',
		{
			'@/utils/storage': ['getItem', 'setItem', 'deleteItem', 'STORAGE_TYPES'],
			'@/utils/request': ['service'],
			'@/stores': ['useCommonStore'],
			'@/lang': ['i18n'],
			'vue-i18n': ['useI18n'],
			'element-plus': ['ElMessage', 'ElMessageBox', 'ElNotification', 'ElAlert', 'ElPopover'],
			lodash: [
				'omit',
				'pick',
				'isEmpty',
				'startCase',
				'toLower',
				'isNil',
				'omitBy',
				'endsWith',
				'unset'
			]
		},
		{
			from: 'vxe-table/types/all',
			imports: ['VxeGridProps', 'VxePagerEvents'],
			type: true
		},
		{
			from: '@/utils/request',
			imports: ['MktBaseResponse'],
			type: true
		}
	],
	resolvers: [
		ElementPlusResolver({ importStyle: 'sass' }),
		IconsResolver({
			prefix: 'icon',
			enabledCollections: ['ep', 'tabler']
		})
	],
	dts: './types/auto-imports.d.ts',
	eslintrc: {
		filepath: './eslintrc/.eslintrc-auto-import.json',
		enabled: true
	},
	dirs: ['./src/composables/**']
})

autoImportPlugin.buildStart()

export default defineConfig(({ mode }) => {
	process.env = { ...process.env, ...loadEnv(mode, process.cwd()) }

	return {
		esbuild: {
			drop: mode === 'production' ? ['console'] : []
		},
		build: {
			chunkSizeWarningLimit: 1000,
			commonjsOptions: {
				transformMixedEsModules: true,
				include: [/node_modules/]
			},
			target: 'ES2020',
			rollupOptions: {
				output: {
					chunkFileNames: 'js/[name]-[hash].js',
					entryFileNames: 'js/[name]-[hash].js',
					assetFileNames: 'assets/[ext]/[name]-[hash].[ext]',
					manualChunks: {
						'vxe-table': ['vxe-table'],
						'vxe-table-plugin-element': ['vxe-table-plugin-element'],
						'vxe-table-plugin-export-xlsx': ['vxe-table-plugin-export-xlsx'],
						exceljs: ['exceljs']
					}
				}
			}
		},
		plugins: [
			vue(),
			UnoCSS(),
			autoImportPlugin,
			svgLoader({
				defaultImport: 'url'
			}),
			Components({
				extensions: ['vue', 'md'],
				// allow auto import and register components used in markdown
				include: [/\.vue$/, /\.vue\?vue/, /\.md$/, /\.ts$/],
				deep: true,
				resolvers: [
					ElementPlusResolver({
						importStyle: 'sass'
					}),
					IconsResolver({
						prefix: 'icon',
						enabledCollections: ['ep', 'tabler']
					})
				],
				dts: './types/components.d.ts'
			}),
			Icons({
				autoInstall: true,
				compiler: 'vue3'
			}),
			createStyleImportPlugin({
				resolves: [VxeTableResolve()],
				libs: [
					{
						libraryName: 'element-plus',
						esModule: true,
						ensureStyleFile: true,
						resolveStyle: (name) => {
							name = name.replace('el-', '')
							return `element-plus/theme-chalk/src/${name}.scss`
						}
					}
				]
			}),
			vueSetupExtend({})
		],
		server: {
			port: (process.env.VITE_PORT as unknown as number) || 8084,
			proxy: process.env.VITE_PROXY_PATH
				? {
						[process.env.VITE_PROXY_PATH as string]: {
							target: process.env.VITE_BASE_URL || '', // Roger
							changeOrigin: true,
							rewrite: (path) =>
								path.replace(RegExp(`^${process.env.VITE_PROXY_PATH}`), '')
						},
						...(mode === 'dev'
							? {
									[process.env.VITE_PROXY_PATH + '/activity']: {
										target: 'http://10.32.3.127:8084', // West
										changeOrigin: true,
										rewrite: (path) =>
											path.replace(
												RegExp(
													`^${process.env.VITE_PROXY_PATH + '/activity'}`
												),
												'/activity'
											)
									},
									[process.env.VITE_PROXY_PATH + '/proposal']: {
										target: 'http://10.32.3.72:8084', // Sunwall
										changeOrigin: true,
										rewrite: (path) =>
											path.replace(
												RegExp(
													`^${process.env.VITE_PROXY_PATH + '/proposal'}`
												),
												'/proposal'
											)
									},
									[process.env.VITE_PROXY_PATH + '/crowd']: {
										target: 'http://10.32.3.72:8084', // Sunwall
										changeOrigin: true,
										rewrite: (path) =>
											path.replace(
												RegExp(
													`^${process.env.VITE_PROXY_PATH + '/crowd'}`
												),
												'/crowd'
											)
									},
									[process.env.VITE_PROXY_PATH + '/report']: {
										target: 'http://10.32.3.160:8084', // Jesson
										changeOrigin: true,
										rewrite: (path) =>
											path.replace(
												RegExp(
													`^${process.env.VITE_PROXY_PATH}` + '/report'
												),
												'/report'
											)
									}
								}
							: undefined)
					}
				: {}
		},
		preview: {
			port: 8090
		},
		resolve: {
			alias: {
				'@': fileURLToPath(new URL('./src', import.meta.url)),
				'~': fileURLToPath(new URL('./types', import.meta.url))
			}
		},
		optimizeDeps: {
			entries: ['./src/**/*.vue']
		},
		css: {
			preprocessorOptions: {
				scss: {
					additionalData: `@use "@/styles/element/index.scss" as *;`
				}
			}
		}
	}
})
